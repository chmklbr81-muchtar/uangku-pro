"use client";

import { useState } from "react";

export interface OCRResult {
  date?: string;
  merchant?: string;
  total?: number;
  items?: { name: string; price: number; qty?: number }[];
  // @deprecated v8.x — field AI output belum dipetakan ke coaId (lihat audit OCR-13)
  category?: string;
  // @deprecated v8.x — confidence tidak digunakan di UX logic (no warning for "low") (audit OCR-23)
  confidence?: "high" | "medium" | "low";
  // @deprecated v8.x — notes tidak dibaca di handleScanResult (audit OCR-23)
  notes?: string;
}

// v8.1: Hook sekarang memanggil /api/ocr-receipt (Next.js API route)
// yang memakai z-ai-web-dev-sdk VLM (glm-4.6v) untuk membaca struk.
//
// Catatan: API route hanya tersedia saat dijalankan via `next dev` / `next start` /
// hosting Node. Pada build static export (Netlify/Capacitor), API route tidak ada.
// Fallback: tampilkan pesan informatif ke user.
export function useOCRReceipt() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<OCRResult | null>(null);
  const [error, setError] = useState<string>("");

  async function scanImage(file: File): Promise<OCRResult | null> {
    setLoading(true);
    setError("");
    setResult(null);

    // [v9.0 fix] OCR-04: UX jujur untuk pengguna APK — OCR butuh server publik terpisah
    // Capacitor native build tidak menyertakan Next.js API route, sehingga fetch ke
    // /api/ocr-receipt akan selalu gagal (404 / network error).
    // [v9.0 fix] M-x: typed Capacitor bridge shape — sebelumnya `(window as any).capacitor`.
    interface CapacitorBridge {
      isNative?: boolean;
      getPlatform?: () => string;
    }
    interface WindowWithCapacitor extends Window {
      capacitor?: CapacitorBridge;
    }
    const capacitorBridge =
      typeof window !== "undefined"
        ? (window as WindowWithCapacitor).capacitor
        : undefined;
    const isNative = !!capacitorBridge?.isNative;
    if (isNative) {
      setError(
        "OCR belum tersedia di APK. Hubungi developer untuk setup server OCR."
      );
      setLoading(false);
      return null;
    }

    try {
      const base64 = await fileToBase64(file);
      // Coba panggil API route (hanya jalan di lingkungan server Next.js)
      try {
        const res = await fetch("/api/ocr-receipt", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image: base64 }),
        });
        if (res.ok) {
          const data = await res.json();
          const parsed: OCRResult = data.data ?? {};
          // @deprecated v8.x — dead-code branch (audit OCR-02): Object.keys check selalu true
          // karena model selalu kembalikan minimal {confidence}. Empty-result di bawah dead.
          // TODO v9.x: ganti dengan validasi field konkret (merchant/total/items).
          if (parsed && Object.keys(parsed).length > 0) {
            setResult(parsed);
            return parsed;
          }
          // Empty result
          setError("Struk tidak terbaca jelas. Coba foto ulang dengan pencahayaan lebih baik.");
          return null;
        }
        // HTTP error
        const errBody = await res.json().catch(() => ({}));
        if (res.status === 404) {
          setError("API OCR tidak tersedia di hosting ini (perlu Next.js server).");
        } else {
          setError(errBody?.error ?? `OCR gagal (HTTP ${res.status})`);
        }
        return null;
      } catch (e: any) {
        // Network error / API not available
        setError(
          "OCR tidak bisa dipanggil di mode ini. Pastikan aplikasi dijalankan via Next.js dev/server, " +
          "atau gunakan input manual."
        );
        return null;
      }
    } catch (e: any) {
      setError(e?.message ?? "Gagal scan struk");
      return null;
    } finally {
      setLoading(false);
    }
  }

  return { loading, result, error, scanImage };
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const base64 = result.split(",")[1] ?? result;
      resolve(`data:${file.type || "image/jpeg"};base64,${base64}`);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
