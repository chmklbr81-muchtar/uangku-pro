"use client";

import { useCallback, useEffect, useState } from "react";
import type { AppData, Settings } from "@/lib/types";

// Hook untuk WebAuthn (biometric) dan auto-lock
// WebAuthn (Platform Authenticator) dipakai untuk fingerprint/Face Unlock
// v8.1: PIN hashing menggunakan PBKDF2-SHA256 (async) — lihat src/lib/security-utils.ts
// v9.0 fix C-3: PIN hash canonical disimpan di settings.pinHash (via setData),
//               bukan lagi di localStorage["uangku.pinHash"]. Legacy key tetap dibaca
//               untuk backward-compat.
export function useBiometric() {
  const [isAvailable, setIsAvailable] = useState(false);
  // [v9.0 fix] C1: default false — app harus terkunci saat pertama dibuka kalau
  // PIN/biometrik aktif. Sebelumnya true → LockScreen tidak pernah muncul.
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [lastActivity, setLastActivity] = useState(Date.now());

  // [v9.0 fix] C1: lock() otomatis dipanggil saat app mount kalau user punya PIN/biometrik.
  // Baca flag dari localStorage agar tidak bergantung pada settings React state (yang
  // belum tentu ter-loaded saat hook pertama kali jalan).
  useEffect(() => {
    if (typeof window === "undefined") return;
    const hasPin = !!localStorage.getItem("uangku.pinHash");
    const hasBiometric = !!localStorage.getItem("uangku.biometricCredId");
    if (hasPin || hasBiometric) {
      setIsUnlocked(false);
    } else {
      // User belum setup keamanan → langsung unlocked agar tidak terkunci permanen.
      setIsUnlocked(true);
    }
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!window.PublicKeyCredential) {
      setIsAvailable(false);
      return;
    }
    window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
      .then((available) => setIsAvailable(available === true))
      .catch(() => setIsAvailable(false));
  }, []);

  // Track activity untuk auto-lock
  useEffect(() => {
    if (typeof window === "undefined") return;
    const onActivity = () => setLastActivity(Date.now());
    const events = ["click", "touchstart", "keydown"];
    events.forEach((e) => window.addEventListener(e, onActivity, { passive: true }));
    return () => {
      events.forEach((e) => window.removeEventListener(e, onActivity));
    };
  }, []);

  // Auto-lock check
  useEffect(() => {
    if (typeof window === "undefined") return;
    const interval = setInterval(() => {
      const lockMinutes = Number(localStorage.getItem("uangku.autoLockMinutes") ?? "0");
      if (lockMinutes > 0 && isUnlocked) {
        const elapsed = (Date.now() - lastActivity) / 1000 / 60;
        if (elapsed >= lockMinutes) {
          setIsUnlocked(false);
        }
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [lastActivity, isUnlocked]);

  // WebAuthn registration (untuk setup biometric pertama kali)
  const register = useCallback(async () => {
    if (!window.PublicKeyCredential) {
      throw new Error("WebAuthn tidak didukung di browser ini");
    }
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);
    const userId = new Uint8Array(16);
    crypto.getRandomValues(userId);

    const publicKey: PublicKeyCredentialCreationOptions = {
      challenge,
      rp: { name: "Uangku Pro" },
      user: {
        id: userId,
        name: "Uangku Pro User",
        displayName: "User Uangku Pro",
      },
      pubKeyCredParams: [
        { type: "public-key", alg: -7 }, // ES256
        { type: "public-key", alg: -257 }, // RS256
      ],
      authenticatorSelection: {
        authenticatorAttachment: "platform",
        userVerification: "required",
      },
      timeout: 60000,
      attestation: "none",
    };

    const credential = (await navigator.credentials.create({
      publicKey,
    })) as PublicKeyCredential | null;
    if (!credential) throw new Error("Gagal mendaftarkan biometrik");

    // Simpan credential ID di localStorage
    const credId = btoa(
      String.fromCharCode(...new Uint8Array(credential.rawId))
    );
    localStorage.setItem("uangku.biometricCredId", credId);
    return credId;
  }, []);

  // WebAuthn authentication (untuk unlock)
  const authenticate = useCallback(async (): Promise<boolean> => {
    if (!window.PublicKeyCredential) {
      throw new Error("WebAuthn tidak didukung");
    }
    const credIdBase64 = localStorage.getItem("uangku.biometricCredId");
    if (!credIdBase64) {
      throw new Error("Biometrik belum terdaftar");
    }
    const binaryString = atob(credIdBase64);
    const allowCredId = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      allowCredId[i] = binaryString.charCodeAt(i);
    }
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);

    const publicKey: PublicKeyCredentialRequestOptions = {
      challenge,
      allowCredentials: [
        { type: "public-key", id: allowCredId, transports: ["internal"] },
      ],
      userVerification: "required",
      timeout: 60000,
    };

    try {
      const assertion = await navigator.credentials.get({ publicKey });
      if (assertion) {
        setIsUnlocked(true);
        setLastActivity(Date.now());
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, []);

  // PIN-based unlock (fallback kalau biometric gagal) — v8.1: async PBKDF2 verify
  // [v9.0 fix] C4: kalau PIN lama (simpleHash) berhasil diverifikasi, langsung
  // upgrade hash ke PBKDF2 dan persist ke localStorage + settings (via event).
  // [v9.0 fix] C-3: kalau `settings` diberikan caller, baca pinHash dari settings
  // (canonical source-of-truth) lebih dulu, lalu fallback ke localStorage legacy.
  const unlockWithPin = useCallback(
    async (pin: string, settings?: Settings): Promise<boolean> => {
      try {
        return await verifyPin(pin, settings);
      } catch {
        return false;
      }
    },
    []
  );

  const lock = useCallback(() => setIsUnlocked(false), []);

  return {
    isAvailable,
    isUnlocked,
    register,
    authenticate,
    unlockWithPin,
    lock,
  };
}

// [v9.0 fix] C-3: setPin — canonical PIN writer.
// Hash PIN via PBKDF2 (hashPin dari security-utils), tulis ke settings.pinHash
// via callback `setData`, lalu bersihkan legacy localStorage keys agar tidak
// ada dual source-of-truth. Pemanggil wajib menyediakan `setData` style updater
// (e.g. React setState callback yang menerima AppData lama & return AppData baru).
//
// Signature:
//   setPin(pin, currentData, setData) => Promise<AppData>
// Mengembalikan AppData baru (sudah dengan pinHash ter-update) supaya caller
// dapat langsung persist bila perlu.
export async function setPin(
  pin: string,
  currentData: AppData,
  setData: (updater: (prev: AppData) => AppData) => void
): Promise<AppData> {
  const { hashPin } = await import("@/lib/security-utils");
  const hash = await hashPin(pin);
  const nextSettings: Settings = {
    ...currentData.settings,
    pinEnabled: true,
    pinHash: hash,
  };
  const next: AppData = {
    ...currentData,
    settings: nextSettings,
  };
  setData(() => next);
  // [v9.0 fix] C-3: hapus legacy localStorage keys supaya tidak ada dual source.
  // PIN hash canonical sekarang hanya di settings.pinHash (yang ikut backup & sync).
  if (typeof window !== "undefined") {
    try {
      window.localStorage.removeItem("uangku.pinHash");
      window.localStorage.removeItem("uangku.pinHash.v2");
    } catch {
      /* noop */
    }
  }
  return next;
}

// [v9.0 fix] C-3: verifyPin — canonical PIN reader.
// Urutan baca:
//   1. settings.pinHash (canonical, di-export/backup/sync)
//   2. localStorage["uangku.pinHash"] (legacy, untuk user lama yang belum migrasi)
//   3. localStorage["uangku.pinHash.v2"] (legacy v2 key)
// Bila settings tidak diberikan (e.g. LockScreen belum punya context settings),
// langsung fallback ke localStorage.
export async function verifyPin(pin: string, settings?: Settings): Promise<boolean> {
  const candidates: string[] = [];
  if (settings?.pinHash) candidates.push(settings.pinHash);
  if (typeof window !== "undefined") {
    const ls1 = window.localStorage.getItem("uangku.pinHash");
    if (ls1) candidates.push(ls1);
    const ls2 = window.localStorage.getItem("uangku.pinHash.v2");
    if (ls2) candidates.push(ls2);
  }
  if (candidates.length === 0) return false;
  try {
    const { verifyPin: verifyPinCrypto } = await import("@/lib/security-utils");
    for (const stored of candidates) {
      const ok = await verifyPinCrypto(pin, stored);
      if (ok) return true;
    }
    return false;
  } catch {
    return false;
  }
}

// simpleHash — LEGACY, retained only for backward-compat reads of old PIN hashes.
// New PINs are stored with hashPin() + verified with verifyPin() (PBKDF2-SHA256).
// Importing code should migrate to the async verifyPin() API.
// @deprecated v8.x — tidak dipakai, dihapus di v9.1
export function simpleHash(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const chr = input.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0;
  }
  return String(hash);
}
