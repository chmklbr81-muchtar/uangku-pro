"use client";

import { useEffect, useMemo, useState, useRef } from "react";
import { type AppData, type Transaction, type Wallet, type COAAccount, type Budget, type SavingsGoal, type RecurringTransaction, type AppNotification, type Settings as SettingsType, type DebtLoan } from "@/lib/types";
import { loadData, saveData } from "@/lib/storage";
import {
  computeSummary,
  getMonthKey,
  getYear,
  todayISO,
  getUpcomingBills,
  getLowBalanceWallets,
  getBudgetUsage,
  genId,
  formatCurrency,
} from "@/lib/finance";
import { Dashboard } from "@/components/finance/dashboard";
import { TransactionsList } from "@/components/finance/transactions-list";
import { MtdYtdDashboard } from "@/components/finance/mtd-ytd-dashboard";
import { AddTransactionDialog } from "@/components/finance/add-transaction-dialog";
import { TransferDialog } from "@/components/finance/transfer-dialog";
import { COAManager } from "@/components/finance/coa-manager";
import { BudgetManager } from "@/components/finance/budget-manager";
import { SavingsGoalManager } from "@/components/finance/savings-goal";
import { RecurringManager } from "@/components/finance/recurring";
import { WalletManager } from "@/components/finance/wallet-manager";
import { ExportDialog } from "@/components/finance/export-dialog";
import { ImportDialog } from "@/components/finance/import-dialog";
import { NotificationCenter } from "@/components/finance/notification-center";
import { FinancialReports } from "@/components/finance/financial-reports";
import { DebtTracker } from "@/components/finance/debt-tracker";
import { LockScreen } from "@/components/finance/lock-screen";
import { SecuritySettingsPanel, CloudSettingsPanel } from "@/components/finance/settings-panels";
import { Onboarding } from "@/components/finance/onboarding";
import { AnalyticsDashboard } from "@/components/finance/analytics-dashboard";
import { SplitBillCalculator } from "@/components/finance/split-bill-calculator";
import { useBiometric } from "@/hooks/use-biometric";
import { logActivity, togglePrivacyBlur, shouldConfirmLargeTx } from "@/lib/security-utils";
import { learnFromTransaction, rebuildLearningFromHistory } from "@/lib/auto-categorize";
import { Button } from "@/components/ui/button";
import { Toaster } from "sonner";
import { toast } from "sonner";
import {
  LayoutDashboard,
  Receipt,
  PieChart,
  Folder,
  Settings,
  Plus,
  Wallet as WalletIcon,
  Bell,
  Download,
  Upload,
  Target,
  Repeat,
  X,
  ChevronDown,
  HandCoins,
  Lock,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Tab =
  | "dashboard"
  | "transactions"
  | "report"
  | "coa"
  | "more";

type MoreView =
  | "budget"
  | "savings"
  | "recurring"
  | "wallets"
  | "debts"
  | "akuntansi"
  | "analytics"
  | "splitbill"
  | "security"
  | "cloud"
  | "settings";

export default function Home() {
  // [v9.0 TODO] Refactor: extract state ke useReducer atau Zustand untuk kurangi useState count.
  // Saat ini Home() punya ~15+ useState yang mengelola data, UI dialog, tab, wallet, dll.
  // Konsolidasi ke reducer/store akan: (1) kurangi re-render, (2) traceability action,
  // (3) testability. Risiko refaktor terlalu besar untuk v9.0; target v9.1.
  const [data, setData] = useState<AppData | null>(null);
  const [tab, setTab] = useState<Tab>("dashboard");
  const [moreView, setMoreView] = useState<MoreView>("budget");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [walletSwitcherOpen, setWalletSwitcherOpen] = useState(false);
  const [activeWalletId, setActiveWalletId] = useState<string>("");

  // Biometric lock
  const { isAvailable: biometricAvailable, isUnlocked, authenticate, unlockWithPin } = useBiometric();

  // Onboarding: tampil saat first install (cek localStorage flag)
  const [showOnboarding, setShowOnboarding] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const seen = localStorage.getItem("uangku.onboardingSeen");
    if (!seen) {
      setShowOnboarding(true);
    }
  }, []);
  function finishOnboarding() {
    localStorage.setItem("uangku.onboardingSeen", "true");
    setShowOnboarding(false);
  }

  // Mount: load data
  useEffect(() => {
    const loaded = loadData();
    // [v9.0 fix] M1: log app_open DI SINI (sebelumnya ada useEffect terpisah
    // dengan `if (!data) return` yang tidak pernah fire karena data=null saat mount
    // pertama kali jalan). Sekarang log langsung setelah loadData() berhasil.
    // [v9.0 fix] T12F-5: tambahkan metadata platform (web/mobile) untuk analytics.
    const withAppOpen = loaded
      ? logActivity(loaded, "app_open", "Aplikasi dibuka", {
          ts: new Date().toISOString(),
          platform: typeof window !== "undefined" ? "web" : "mobile",
        })
      : loaded;
    setData(withAppOpen);

    // [v9.0 fix] Netlify badge cleanup hack DIHAPUS (~30 LOC: MutationObserver +
    // 2x setTimeout + 6x setProperty per element). Sekarang andalkan CSS hide
    // di globals.css (lihat blok `[v9.0 fix] Netlify badge hide (CSS-only)`).
    // Alasan: observer aktif sepanjang lifecycle app = overhead permanent;
    // setTimeout race dengan badge injection yang variable timing; JS approach
    // tidak lebih efektif dari CSS `display:none !important` + selector lebih luas.
  }, []);

  // Persist on change + Auto-push ke Supabase sync (kalau syncEnabled)
  const lastSyncPushRef = useRef<string>("");
  // [v9.0 fix] T-1.1: Auto-push pakai SmartSync granular (LWW per-item + soft-delete), bukan legacy overwrite.
  // T-1.1 / T-4.1: debounce dinaikkan dari 2s → 5s untuk kurangi spam API & race condition.
  useEffect(() => {
    if (data) {
      saveData(data);
      // Auto-push ke Supabase kalau sync aktif (debounced 5 detik)
      if (data.settings.syncEnabled && data.settings.supabaseUrl && data.settings.supabaseAnonKey) {
        const dataHash = JSON.stringify({
          t: data.transactions.length,
          w: data.wallets.length,
          b: data.budgets.length,
          s: data.savingsGoals.length,
          d: data.debts.length,
        });
        if (dataHash !== lastSyncPushRef.current) {
          lastSyncPushRef.current = dataHash;
          const timer = setTimeout(async () => {
            try {
              const { supabaseSmartSync, getStoredSession } = await import("@/lib/supabase-sync");
              const session = await getStoredSession();
              if (session) {
                const result = await supabaseSmartSync(
                  { url: data.settings.supabaseUrl!, anonKey: data.settings.supabaseAnonKey! },
                  data
                );
                // [v9.0 fix] T-4.1: jangan swallow error diam-diam — toast kalau sync gagal
                if (!result.success && result.error) {
                  console.warn("Auto-push SmartSync gagal:", result.error);
                  // Hindari spam toast: hanya tampilkan jika bukan error "Belum login"
                  if (!result.error.includes("Belum login")) {
                    toast.error(`Sync cloud gagal: ${result.error.slice(0, 80)}`);
                  }
                } else if (result.mergedData) {
                  // Merge hasil LWW kembali ke state lokal (hindari loop: cek hash)
                  const mergedHash = JSON.stringify({
                    t: result.mergedData.transactions.length,
                    w: result.mergedData.wallets.length,
                  });
                  if (mergedHash !== lastSyncPushRef.current) {
                    setData(result.mergedData);
                  }
                }
              }
            } catch (e) {
              console.warn("Auto-push SmartSync exception:", e);
              // [v9.0 fix] T-4.2: queue ke offline queue via SmartSync internal (lihat supabase-sync.ts)
            }
          }, 5000);
          return () => clearTimeout(timer);
        }
      }
    }
  }, [data]);

  // Listen event sync-complete untuk update data dari cloud
  useEffect(() => {
    const handler = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        setData(customEvent.detail);
      }
    };
    window.addEventListener("uangku-sync-complete", handler);
    return () => window.removeEventListener("uangku-sync-complete", handler);
  }, []);

  // [v9.0 fix] T-4.2: Proses offline sync queue saat app launch (jika online & sync aktif).
  // Queue diisi oleh supabaseSmartSync saat fetch gagal karena network error.
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!navigator.onLine) return;
    let cancelled = false;
    (async () => {
      try {
        const { processSyncQueue } = await import("@/lib/supabase-sync");
        await processSyncQueue();
      } catch (e) {
        if (!cancelled) console.warn("processSyncQueue gagal:", e);
      }
    })();
    // Re-process saat koneksi kembali online
    const onOnline = () => {
      (async () => {
        try {
          const { processSyncQueue } = await import("@/lib/supabase-sync");
          await processSyncQueue();
        } catch {}
      })();
    };
    window.addEventListener("online", onOnline);
    return () => {
      cancelled = true;
      window.removeEventListener("online", onOnline);
    };
  }, []);

  // Set active wallet default
  useEffect(() => {
    if (data && !activeWalletId && data.wallets.length > 0) {
      setActiveWalletId(data.wallets[0].id);
    }
  }, [data, activeWalletId]);

  const monthKey = getMonthKey(todayISO());
  const year = getYear(todayISO());
  // [v9.0 fix] T-1.2: turunkan visibleTransactions dari data.transactions (filter soft-deleted < 30 hari)
  // supaya summary, dashboard, dan render lainnya konsisten — transaksi yang baru di-soft-delete
  // tidak ikut dihitung di saldo / pemasukan / pengeluaran.
  const visibleTransactions = useMemo(() => {
    if (!data) return [];
    const SOFT_DELETE_WINDOW_MS = 30 * 24 * 60 * 60 * 1000;
    return data.transactions.filter((t) => {
      if (!t.deletedAt) return true;
      return Date.now() - new Date(t.deletedAt).getTime() >= SOFT_DELETE_WINDOW_MS;
    });
  }, [data]);
  // useMemo harus sebelum conditional return; guard via empty array saat data null
  const summary = useMemo(
    () =>
      data
        ? computeSummary(visibleTransactions, data.wallets, monthKey, year)
        : {
            totalIncome: 0,
            totalExpense: 0,
            totalTransfer: 0,
            balance: 0,
            mtdIncome: 0,
            mtdExpense: 0,
            mtdBalance: 0,
            mtdSavingsRate: 0,
            ytdIncome: 0,
            ytdExpense: 0,
            ytdBalance: 0,
            ytdSavingsRate: 0,
          },
    [visibleTransactions, data, monthKey, year]
  );

  // Generate notifications on mount and when data changes
  useEffect(() => {
    if (!data) return;
    generateNotificationsIfNeeded(data, setData);
  }, [data?.transactions.length, data?.recurring.length, data?.wallets.length, data?.budgets.length]);

  // Schedule daily reminder via setTimeout while app open
  useEffect(() => {
    if (!data?.settings.dailyReminderEnabled || !data?.settings.notificationsEnabled) return;
    const now = new Date();
    const target = new Date();
    target.setHours(data.settings.dailyReminderHour, 0, 0, 0);
    if (now > target) target.setDate(target.getDate() + 1);
    const ms = target.getTime() - now.getTime();
    const timer = setTimeout(() => {
      if ("Notification" in window && Notification.permission === "granted") {
        new Notification("Uangku Pro — Pengingat Harian", {
          body: "Sudah catat semua transaksi hari ini? 📝",
          icon: "/icon-192.png",
        });
      }
    }, ms);
    return () => clearTimeout(timer);
  }, [data?.settings.dailyReminderEnabled, data?.settings.dailyReminderHour, data?.settings.notificationsEnabled]);

  if (!data) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 animate-pulse rounded-full bg-[oklch(0.78_0.16_85/0.3)]" />
          <p className="text-sm text-muted-foreground">Memuat Uangku Pro...</p>
        </div>
      </div>
    );
  }

  // Onboarding tampil di atas semua (saat first install)
  if (showOnboarding) {
    return <Onboarding onFinish={finishOnboarding} />;
  }

  // Notif count for badge
  const upcomingBills = getUpcomingBills(data.recurring, 3);
  const lowWallets = getLowBalanceWallets(data.wallets, data.transactions);
  const budgetAlerts = getBudgetUsage(
    data.budgets,
    data.transactions,
    data.coa,
    monthKey
  ).filter((b) => b.percent >= (data.settings.budgetAlertThreshold ?? 80));
  const unreadNotifs = data.notifications.filter((n) => !n.read).length;
  const notifCount = upcomingBills.length + lowWallets.length + budgetAlerts.length + unreadNotifs;

  // === Handlers ===
  function handleSaveTx(tx: Transaction) {
    // v8.1: large transaction confirmation check
    if (data && shouldConfirmLargeTx(tx.amount, data.settings)) {
      const fmt = new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(tx.amount);
      // TODO v9.1: ganti confirm() native dengan AlertDialog shadcn untuk UX konsisten mobile.
      // [v9.0 fix] H3: wrap dalam try/catch karena window.confirm() bisa di-block
      // silently oleh browser ("Prevent this page from creating additional dialogs")
      // atau oleh WebView Capacitor — kalau gagal, default reject (return) agar aman.
      let confirmed = false;
      try {
        confirmed = confirm(`Konfirmasi transaksi besar\n\nJumlah: ${fmt}\nKategori: ${tx.category}\n\nLanjutkan?`);
      } catch {
        confirmed = false;
      }
      if (!confirmed) {
        return;
      }
    }
    const isEdit = data ? data.transactions.some((t) => t.id === tx.id) : false;
    // [v9.0 fix] T-1.2: stamp updatedAt supaya LWW merge di supabaseSmartSync pakai timestamp terbaru.
    const txStamped: Transaction = { ...tx, updatedAt: new Date().toISOString() };
    setData((d) => {
      if (!d) return d;
      const exists = d.transactions.some((t) => t.id === tx.id);
      const txs = exists
        ? d.transactions.map((t) => (t.id === tx.id ? txStamped : t))
        : [txStamped, ...d.transactions];
      // v8.1: activity log + learn from transaction
      let updated = { ...d, transactions: txs };
      updated = logActivity(
        updated,
        exists ? "tx_edit" : "tx_add",
        exists ? `Edit transaksi: ${tx.category} (${tx.type})` : `Tambah transaksi: ${tx.category} (${tx.type})`,
        { amount: tx.amount, type: tx.type, coaId: tx.coaId }
      );
      // v8.1: feed learning model
      try { learnFromTransaction(tx); } catch {}
      return updated;
    });
    setEditing(null);
    toast.success(
      isEdit
        ? "Transaksi diperbarui"
        : tx.type === "income"
        ? "Uang masuk dicatat"
        : tx.type === "transfer"
        ? "Transfer dicatat"
        : "Uang keluar dicatat"
    );
  }

  function handleDeleteTx(id: string) {
    const tx = data?.transactions.find((t) => t.id === id);
    const nowIso = new Date().toISOString();
    setData((d) => {
      if (!d) return d;
      // [v9.0 fix] T-1.2: Soft-delete (bukan hard filter) — tandai dengan deletedAt + updatedAt.
      // Item tetap di data.transactions selama 30 hari untuk propagate deletion via sync (LWW),
      // lalu di-purge oleh mergeCollection() di supabaseSmartSync. Display mem-filter via isSoftDeleted() di transactions-list.tsx & dashboard.tsx.
      let updated = {
        ...d,
        transactions: d.transactions.map((t) =>
          t.id === id
            ? { ...t, deletedAt: nowIso, updatedAt: nowIso }
            : t
        ),
      };
      // v8.1: activity log
      // [v9.0 fix] M1: sertakan `category` di metadata agar audit trail lengkap
      // (sebelumnya hanya { amount, id }).
      updated = logActivity(updated, "tx_delete", `Hapus transaksi: ${tx?.category ?? id}`, {
        id,
        amount: tx?.amount,
        category: tx?.category,
        softDelete: true,
        deletedAt: nowIso,
      });
      return updated;
    });
    setEditing(null);
    toast.success("Transaksi dihapus");
  }

  function handleTransfer(fromTx: Transaction, toTx: Transaction) {
    setData((d) => {
      if (!d) return d;
      let updated = {
        ...d,
        transactions: [fromTx, toTx, ...d.transactions],
      };
      // v8.1: activity log
      updated = logActivity(updated, "tx_add", `Transfer antar-dompet: ${fromTx.amount}`, { fromWallet: fromTx.walletId, toWallet: toTx.walletId });
      return updated;
    });
    toast.success("Transfer antar-dompet dicatat");
  }

  function handleImport(txs: Transaction[]) {
    // [v9.0 fix] M8: pindahkan side-effect rebuildLearningFromHistory keluar dari setData updater.
    // Sebelumnya, side-effect (mutasi learning store) dijalankan di dalam updater
    // React setData — menyebabkan double eksekusi di StrictMode dan side-effect
    // tidak terenkapsulasi dengan baik.
    const prev = data;
    if (!prev) return;
    const updated = logActivity(
      { ...prev, transactions: [...txs, ...prev.transactions] },
      "backup_restore",
      `Import ${txs.length} transaksi dari file eksternal`
    );
    setData(updated);
    // [v9.0 fix] M8: side-effect dijalankan setelah setData, bukan di dalam updater.
    // [v9.0 fix] M9: ganti require() CommonJS dengan ESM import di atas.
    try {
      rebuildLearningFromHistory(updated.transactions);
    } catch {}
  }

  function updateWallets(wallets: Wallet[]) {
    setData((d) => (d ? { ...d, wallets } : d));
  }
  function updateCOA(coa: COAAccount[]) {
    setData((d) => (d ? { ...d, coa } : d));
  }
  function updateBudgets(budgets: Budget[]) {
    setData((d) => (d ? { ...d, budgets } : d));
  }
  function updateGoals(goals: SavingsGoal[]) {
    setData((d) => (d ? { ...d, savingsGoals: goals } : d));
  }
  function updateRecurring(recurring: RecurringTransaction[]) {
    setData((d) => (d ? { ...d, recurring } : d));
  }
  function updateDebts(debts: DebtLoan[]) {
    setData((d) => (d ? { ...d, debts } : d));
  }
  function updateSettings(settings: SettingsType) {
    setData((d) => {
      if (!d) return d;
      // v8.1: log settings change (skip biometric toggles to avoid spam)
      // [v9.0 fix] M-x: typed tracked-key list — sebelumnya `as any` index access.
      const tracked = [
        "biometricEnabled",
        "pinEnabled",
        "syncEnabled",
        "autoBackupEnabled",
        "privacyBlurMode",
        "largeTxConfirmation",
        "themeChoice",
        "ownerName",
      ] as const;
      type TrackedKey = (typeof tracked)[number];
      const changed = tracked.find(
        (k: TrackedKey) => settings[k] !== d.settings[k]
      );
      if (changed) {
        return logActivity(d, "settings_change", `Ubah pengaturan: ${changed}`, { field: changed });
      }
      return { ...d, settings };
    });
  }

  function handleContribute(goalId: string, amount: number) {
    setData((d) => {
      if (!d) return d;
      return {
        ...d,
        savingsGoals: d.savingsGoals.map((g) =>
          g.id === goalId
            ? { ...g, currentAmount: g.currentAmount + amount }
            : g
        ),
      };
    });
  }

  function handleExecuteRecurring(tx: Transaction) {
    setData((d) => {
      if (!d) return d;
      // Update nextRunDate on the recurring template jika ada fromRecurringId
      const recurringId = tx.fromRecurringId;
      const recurring = recurringId
        ? d.recurring.map((r) => {
            if (r.id !== recurringId) return r;
            const next = computeNextRunFromRecurring(r);
            return { ...r, nextRunDate: next };
          })
        : d.recurring;
      return {
        ...d,
        transactions: [tx, ...d.transactions],
        recurring,
      };
    });
    toast.success("Transaksi berulang dicatat");
  }

  function handleRestore(parsed: AppData) {
    setData((d) => (d ? logActivity({ ...parsed }, "backup_restore", "Restore data dari backup JSON") : parsed));
    toast.success("Backup dipulihkan");
  }

  // v8.1: Restore dari backup terenkripsi (dipanggil dari CloudSettingsPanel via event)
  useEffect(() => {
    function onEncryptedRestore(e: Event) {
      const ev = e as CustomEvent<AppData>;
      if (ev.detail) {
        const restored = logActivity(ev.detail, "backup_restore", "Restore dari backup terenkripsi (AES-GCM)");
        setData(restored);
        toast.success("Backup terenkripsi dipulihkan");
      }
    }
    window.addEventListener("uangku-restore-encrypted", onEncryptedRestore as EventListener);
    return () => window.removeEventListener("uangku-restore-encrypted", onEncryptedRestore as EventListener);
  }, []);

  // v8.1: Apply theme on mount + when themeChoice changes
  useEffect(() => {
    if (typeof document === "undefined") return;
    const html = document.documentElement;
    html.classList.remove("theme-bank-pro", "theme-green-eco", "theme-pink-pastel", "theme-black-cyan");
    const theme = data?.settings.themeChoice;
    if (theme && theme !== "navy-gold") {
      html.classList.add(`theme-${theme}`);
    }
  }, [data?.settings.themeChoice]);

  // v8.1: Apply privacy blur on mount + when privacyBlurMode changes
  useEffect(() => {
    if (typeof document === "undefined") return;
    togglePrivacyBlur(data?.settings.privacyBlurMode === true);
  }, [data?.settings.privacyBlurMode]);

  // v8.1: Listen storage-ready event (Capacitor Preferences init selesai)
  useEffect(() => {
    function onStorageReady() {
      // Reload data dari storage baru setelah Capacitor Preferences siap
      // [v9.0 fix] M9: ganti require() CommonJS dengan ESM import di atas (loadData).
      const fresh = loadData();
      setData(fresh);
    }
    window.addEventListener("uangku-storage-ready", onStorageReady);
    return () => window.removeEventListener("uangku-storage-ready", onStorageReady);
  }, []);

  // v8.1: Log app_open on mount — DIHAPUS di v9.0 fix M1.
  // Sebelumnya effect ini pakai `if (!data) return` + deps `[]`, yang artinya
  // tidak pernah fire karena `data` masih null saat mount. app_open sekarang
  // dicatat langsung di mount-load effect (lihat comment [v9.0 fix] M1 di atas).
  // [v9.0 fix] C4: listener `uangku-pin-upgraded` — ketika verifyPin mendeteksi
  // PIN lama (simpleHash 32-bit) dan berhasil di-upgrade ke PBKDF2, persist
  // hash baru ke data.settings.pinHash juga (single source of truth).
  useEffect(() => {
    function onPinUpgrade(e: Event) {
      const ev = e as CustomEvent<{ newHash: string }>;
      if (ev.detail?.newHash) {
        setData((d) =>
          d
            ? logActivity(
                { ...d, settings: { ...d.settings, pinHash: ev.detail.newHash } },
                "settings_change",
                "PIN hash di-upgrade otomatis (simpleHash → PBKDF2)",
                { migrated: true }
              )
            : d
        );
      }
    }
    window.addEventListener("uangku-pin-upgraded", onPinUpgrade as EventListener);
    return () => window.removeEventListener("uangku-pin-upgraded", onPinUpgrade as EventListener);
  }, []);

  function handleMarkAllNotifRead() {
    setData((d) =>
      d
        ? {
            ...d,
            notifications: d.notifications.map((n) => ({ ...n, read: true })),
          }
        : d
    );
  }
  function handleClearNotifs() {
    setData((d) => (d ? { ...d, notifications: [] } : d));
  }

  function openAdd() {
    setEditing(null);
    setDialogOpen(true);
  }
  function openEdit(tx: Transaction) {
    setEditing(tx);
    setDialogOpen(true);
  }

  const activeWallet = data.wallets.find((w) => w.id === activeWalletId);
  const tabs: { id: Tab; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "dashboard", label: "Beranda", icon: LayoutDashboard },
    { id: "transactions", label: "Transaksi", icon: Receipt },
    { id: "report", label: "Laporan", icon: PieChart },
    { id: "coa", label: "COA", icon: Folder },
    { id: "more", label: "Lainnya", icon: Settings },
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <Toaster
        richColors
        position="top-center"
        theme="dark"
        toastOptions={{
          style: {
            background: "rgba(20,15,40,0.92)",
            border: "1px solid rgba(255,255,255,0.12)",
            color: "#fff",
          },
        }}
      />

      {/* Header */}
      <header className="sticky top-0 z-30 glass-strong border-b border-border/30">
        <div className="mx-auto flex max-w-md items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl gradient-gold text-primary-foreground shadow-lg shadow-[oklch(0.78_0.16_85/0.4)]">
              <WalletIcon className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-tight text-gradient-gold">
                Uangku Pro
              </h1>
              <p className="text-[10px] leading-tight text-muted-foreground">
                {data.settings.ownerName !== "Saya"
                  ? data.settings.ownerName
                  : "Pencatat Keuangan Personal"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setNotifOpen(true)}
              className="relative h-9 w-9"
              aria-label="Notifikasi"
            >
              <Bell className="h-4 w-4" />
              {notifCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-pink-500 px-1 text-[10px] font-bold text-white">
                  {notifCount > 9 ? "9+" : notifCount}
                </span>
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setWalletSwitcherOpen(true)}
              className="relative h-9 w-9"
              aria-label="Dompet"
            >
              <span className="text-lg">{activeWallet?.icon ?? "💵"}</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Konten Tab */}
      <main className="mx-auto w-full max-w-md flex-1 px-4 py-4 pb-20">
        {tab === "dashboard" && (
          <Dashboard
            data={data}
            summary={summary}
            monthKey={monthKey}
            onAdd={openAdd}
            onTransfer={() => setTransferOpen(true)}
            onOpenTransaction={openEdit}
            onSeeAll={() => setTab("transactions")}
            onSwitchWallet={() => { setMoreView("wallets"); setTab("more"); }}
            onOpenSavings={() => { setMoreView("savings"); setTab("more"); }}
            onOpenBudget={() => { setMoreView("budget"); setTab("more"); }}
            onOpenNotifications={() => setNotifOpen(true)}
            notifCount={notifCount}
          />
        )}
        {tab === "transactions" && (
          <TransactionsList
            data={data}
            onOpenTransaction={openEdit}
            onAdd={openAdd}
            onDeleteTransaction={handleDeleteTx}
          />
        )}
        {tab === "report" && (
          <MtdYtdDashboard data={data} onOpenTransaction={openEdit} />
        )}
        {tab === "coa" && <COAManager data={data} onUpdate={updateCOA} />}
        {tab === "more" && (
          <MorePanel
            view={moreView}
            setView={setMoreView}
            data={data}
            onUpdateWallets={updateWallets}
            onUpdateBudgets={updateBudgets}
            onUpdateGoals={updateGoals}
            onUpdateRecurring={updateRecurring}
            onUpdateSettings={updateSettings}
            onUpdateDebts={updateDebts}
            // [v9.0 fix] M-gap: pass setData-based clearLogs callback ke MorePanel.
            onClearActivityLogs={() =>
              setData((d) => (d ? { ...d, activityLogs: [] } : d))
            }
            onContribute={handleContribute}
            onExecuteRecurring={handleExecuteRecurring}
            onOpenExport={() => setExportOpen(true)}
            onOpenImport={() => setImportOpen(true)}
            onMarkAllNotifRead={handleMarkAllNotifRead}
            onClearNotifs={handleClearNotifs}
            onRestore={handleRestore}
            onAdd={openAdd}
            onOpenTransaction={openEdit}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="sticky bottom-0 z-30 glass-strong border-t border-border/30">
        <div className="mx-auto flex max-w-md items-stretch justify-around px-1 pt-1 pb-[calc(env(safe-area-inset-bottom)+4px)]">
          {tabs.map((t) => {
            const active = tab === t.id;
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "flex flex-1 flex-col items-center gap-0.5 py-2.5 transition-colors hover-smooth",
                  active
                    ? "text-gold"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon
                  className={cn("h-5 w-5", active && "scale-110")}
                  strokeWidth={active ? 2.5 : 2}
                />
                <span
                  className={cn(
                    "text-[10px] font-medium",
                    active && "font-semibold"
                  )}
                >
                  {t.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Dialogs */}
      <AddTransactionDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) setEditing(null);
        }}
        data={data}
        onSave={handleSaveTx}
        onDelete={handleDeleteTx}
        editing={editing}
        defaultWalletId={activeWalletId}
      />
      <TransferDialog
        open={transferOpen}
        onOpenChange={setTransferOpen}
        data={data}
        onTransfer={handleTransfer}
        defaultFromWalletId={activeWalletId}
      />
      <ExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        data={data}
      />
      <ImportDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        data={data}
        onImport={handleImport}
      />
      <NotificationCenter
        open={notifOpen}
        onOpenChange={setNotifOpen}
        data={data}
        onUpdateSettings={updateSettings}
        onMarkAllRead={handleMarkAllNotifRead}
        onClearNotifications={handleClearNotifs}
      />

      {/* Wallet Switcher */}
      <WalletSwitcher
        open={walletSwitcherOpen}
        onOpenChange={setWalletSwitcherOpen}
        data={data}
        activeWalletId={activeWalletId}
        onSelect={(id) => {
          setActiveWalletId(id);
          setWalletSwitcherOpen(false);
        }}
        onManage={() => {
          setWalletSwitcherOpen(false);
          setMoreView("wallets");
          setTab("more");
        }}
      />

      {/* Lock Screen (muncul kalau biometric/PIN aktif & aplikasi terkunci) */}
      <LockScreen
        enabled={
          !!data &&
          (data.settings.biometricEnabled || data.settings.pinEnabled) &&
          !isUnlocked
        }
        biometricAvailable={biometricAvailable}
        biometricEnabled={data.settings.biometricEnabled}
        pinEnabled={data.settings.pinEnabled}
        onBiometricUnlock={async () => {
          try {
            const ok = await authenticate();
            return ok;
          } catch {
            return false;
          }
        }}
        onPinUnlock={unlockWithPin}
      />
    </div>
  );
}

// === More Panel (gabungan: budget, savings, recurring, wallets, debts, akuntansi, security, cloud, settings, tools) ===
function MorePanel({
  view,
  setView,
  data,
  onUpdateWallets,
  onUpdateBudgets,
  onUpdateGoals,
  onUpdateRecurring,
  onUpdateSettings,
  onUpdateDebts,
  onClearActivityLogs,
  onContribute,
  onExecuteRecurring,
  onOpenExport,
  onOpenImport,
  onMarkAllNotifRead,
  onClearNotifs,
  onRestore,
  onAdd,
  onOpenTransaction,
}: {
  view: MoreView;
  setView: (v: MoreView) => void;
  data: AppData;
  onUpdateWallets: (w: Wallet[]) => void;
  onUpdateBudgets: (b: Budget[]) => void;
  onUpdateGoals: (g: SavingsGoal[]) => void;
  onUpdateRecurring: (r: RecurringTransaction[]) => void;
  onUpdateDebts: (d: DebtLoan[]) => void;
  onUpdateSettings: (s: SettingsType) => void;
  // [v9.0 fix] M-gap: clear activityLogs via parent setData (sebelumnya placeholder).
  onClearActivityLogs?: () => void;
  onContribute: (goalId: string, amount: number) => void;
  onExecuteRecurring: (tx: Transaction) => void;
  onOpenExport: () => void;
  onOpenImport: () => void;
  onMarkAllNotifRead: () => void;
  onClearNotifs: () => void;
  onRestore: (data: AppData) => void;
  onAdd: () => void;
  onOpenTransaction: (tx: Transaction) => void;
}) {
  const items: { id: MoreView; label: string; icon: typeof LayoutDashboard }[] = [
    { id: "budget", label: "Anggaran", icon: Target },
    { id: "savings", label: "Tabungan", icon: Target },
    { id: "recurring", label: "Berulang", icon: Repeat },
    { id: "debts", label: "Utang", icon: HandCoins },
    { id: "akuntansi", label: "Akuntansi", icon: Folder },
    { id: "analytics", label: "Analitik", icon: LayoutDashboard },
    { id: "splitbill", label: "Split Bill", icon: Users },
    { id: "wallets", label: "Dompet", icon: WalletIcon },
    { id: "security", label: "Keamanan", icon: Lock },
    { id: "cloud", label: "Cloud", icon: Repeat },
    { id: "settings", label: "Pengaturan", icon: Settings },
  ];

  return (
    <div className="space-y-3 pb-4">
      {/* Tools card */}
      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={onOpenExport}
          className="flex items-center gap-2 rounded-xl glass p-3 text-left hover:bg-accent transition-colors border-border/50"
        >
          <Download className="h-5 w-5 text-emerald-400" />
          <div>
            <p className="text-sm font-semibold">Ekspor Excel</p>
            <p className="text-[10px] text-muted-foreground">Multi-sheet profesional</p>
          </div>
        </button>
        <button
          onClick={onOpenImport}
          className="flex items-center gap-2 rounded-xl glass p-3 text-left hover:bg-accent transition-colors border-border/50"
        >
          <Upload className="h-5 w-5 text-violet-400" />
          <div>
            <p className="text-sm font-semibold">Import</p>
            <p className="text-[10px] text-muted-foreground">Money Lover/Monefy</p>
          </div>
        </button>
      </div>

      {/* Sub-tab selector */}
      <div className="flex gap-1 overflow-x-auto pb-1 -mx-1 px-1">
        {items.map((item) => {
          const Icon = item.icon;
          const active = view === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-colors",
                active
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/40 text-muted-foreground hover:bg-accent"
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {item.label}
            </button>
          );
        })}
      </div>

      {/* Active view */}
      {view === "budget" && (
        <BudgetManager data={data} onUpdate={onUpdateBudgets} />
      )}
      {view === "savings" && (
        <SavingsGoalManager
          data={data}
          onUpdate={onUpdateGoals}
          onContribute={onContribute}
        />
      )}
      {view === "recurring" && (
        <RecurringManager
          data={data}
          onUpdate={onUpdateRecurring}
          onExecute={onExecuteRecurring}
        />
      )}
      {view === "debts" && (
        <DebtTracker data={data} onUpdate={onUpdateDebts} />
      )}
      {view === "akuntansi" && (
        <FinancialReports data={data} />
      )}
      {view === "analytics" && (
        <AnalyticsDashboard data={data} />
      )}
      {view === "splitbill" && (
        <SplitBillCalculator />
      )}
      {view === "wallets" && (
        <WalletManager data={data} onUpdate={onUpdateWallets} />
      )}
      {view === "security" && (
        <SecuritySettingsPanel
          data={data}
          onUpdateSettings={onUpdateSettings}
          onClearActivityLogs={onClearActivityLogs}
        />
      )}
      {view === "cloud" && (
        <CloudSettingsPanel data={data} onUpdateSettings={onUpdateSettings} />
      )}
      {view === "settings" && (
        <SettingsPanel
          data={data}
          onUpdateSettings={onUpdateSettings}
          onMarkAllNotifRead={onMarkAllNotifRead}
          onClearNotifs={onClearNotifs}
          onRestore={onRestore}
        />
      )}
    </div>
  );
}

function SettingsPanel({
  data,
  onUpdateSettings,
  onMarkAllNotifRead,
  onClearNotifs,
  onRestore,
}: {
  data: AppData;
  onUpdateSettings: (s: SettingsType) => void;
  onMarkAllNotifRead: () => void;
  onClearNotifs: () => void;
  onRestore: (data: AppData) => void;
}) {
  const [name, setName] = useState(data.settings.ownerName);

  function handleReset() {
    if (
      !confirm(
        "Hapus SEMUA data? Transaksi, dompet, COA, anggaran, target, dan template berulang akan hilang. Tindakan ini tidak bisa dibatalkan."
      )
    )
      return;
    localStorage.removeItem("uangku-pro.data.v2");
    window.location.reload();
  }

  function handleBackup() {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `uangku-backup-${todayISO()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Backup diunduh");
  }

  function handleRestore(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string) as AppData;
        if (!parsed.transactions || !Array.isArray(parsed.transactions)) {
          toast.error("File backup tidak valid");
          return;
        }
        onRestore(parsed);
      } catch {
        toast.error("Gagal memulihkan backup");
      }
    };
    reader.readAsText(f);
  }

  return (
    <div className="space-y-3">
      <div className="rounded-2xl glass p-4 border-border/50 space-y-3">
        <h2 className="text-sm font-semibold">Profil</h2>
        <div className="space-y-1.5">
          <label className="text-xs text-muted-foreground">Nama Pemilik</label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full rounded-lg bg-input/50 border border-border/50 px-3 py-2 text-sm"
            placeholder="Nama Anda"
          />
        </div>
        <button
          onClick={() => onUpdateSettings({ ...data.settings, ownerName: name.trim() || "Saya" })}
          className="w-full rounded-lg bg-primary text-primary-foreground py-2 text-sm font-medium"
        >
          Simpan Nama
        </button>
      </div>

      <div className="rounded-2xl glass p-4 border-border/50 space-y-2">
        <h2 className="text-sm font-semibold">Backup & Restore</h2>
        <button
          onClick={handleBackup}
          className="w-full flex items-center gap-2 rounded-lg border border-border/50 px-3 py-2 text-sm hover:bg-accent transition-colors"
        >
          <Download className="h-4 w-4 text-emerald-400" />
          Backup semua data (JSON)
        </button>
        <label className="w-full flex items-center gap-2 rounded-lg border border-border/50 px-3 py-2 text-sm hover:bg-accent transition-colors cursor-pointer">
          <Upload className="h-4 w-4 text-violet-400" />
          Pulihkan dari backup
          <input type="file" accept=".json" className="hidden" onChange={handleRestore} />
        </label>
      </div>

      <div className="rounded-2xl glass p-4 border-border/50 space-y-2">
        <h2 className="text-sm font-semibold">Notifikasi</h2>
        <button
          onClick={onMarkAllNotifRead}
          className="w-full flex items-center gap-2 rounded-lg border border-border/50 px-3 py-2 text-sm hover:bg-accent transition-colors"
        >
          <Bell className="h-4 w-4 text-violet-400" />
          Tandai semua dibaca
        </button>
        <button
          onClick={onClearNotifs}
          className="w-full flex items-center gap-2 rounded-lg border border-border/50 px-3 py-2 text-sm hover:bg-accent transition-colors text-red-400"
        >
          <X className="h-4 w-4" />
          Hapus semua riwayat notifikasi
        </button>
      </div>

      <div className="rounded-2xl glass p-4 border-border/50 border-red-500/30">
        <h2 className="text-sm font-semibold text-red-400 mb-2">Zona Berbahaya</h2>
        <button
          onClick={handleReset}
          className="w-full rounded-lg border border-red-500/40 px-3 py-2 text-sm font-medium text-red-400 hover:bg-red-500/10 transition-colors"
        >
          Reset Semua Data
        </button>
      </div>

      <p className="text-center text-[10px] text-muted-foreground py-2">
        Uangku Pro v8.1 · PWA · Offline-first · AES-GCM + PBKDF2
      </p>
    </div>
  );
}

function WalletSwitcher({
  open,
  onOpenChange,
  data,
  activeWalletId,
  onSelect,
  onManage,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  data: AppData;
  activeWalletId: string;
  onSelect: (id: string) => void;
  onManage: () => void;
}) {
  const activeWallets = data.wallets.filter((w) => !w.archived);
  return (
    <div
      className={cn(
        "fixed inset-0 z-40 flex items-end justify-center transition-all",
        open ? "visible" : "invisible"
      )}
      onClick={() => onOpenChange(false)}
    >
      <div
        className={cn(
          "absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity",
          open ? "opacity-100" : "opacity-0"
        )}
      />
      <div
        className={cn(
          "relative w-full max-w-md rounded-t-3xl glass-strong border-t border-border/50 p-4 pb-8 transition-transform",
          open ? "translate-y-0" : "translate-y-full"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mx-auto mb-3 h-1 w-12 rounded-full bg-muted-foreground/40" />
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-semibold">Pilih Dompet Aktif</h2>
          <button onClick={onManage} className="text-xs text-violet-400 font-medium">
            Kelola →
          </button>
        </div>
        <div className="space-y-1.5">
          {activeWallets.map((w) => {
            const active = w.id === activeWalletId;
            return (
              <button
                key={w.id}
                onClick={() => onSelect(w.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl p-3 transition-colors text-left",
                  active
                    ? "bg-primary/15 border border-primary/30"
                    : "hover:bg-accent border border-transparent"
                )}
              >
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-xl text-xl"
                  style={{ backgroundColor: w.color + "20" }}
                >
                  {w.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{w.name}</p>
                </div>
                {active && <ChevronDown className="h-4 w-4 text-primary rotate-[-90deg]" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// Generate notifications jika belum ada untuk hari ini
function generateNotificationsIfNeeded(
  data: AppData,
  setData: React.Dispatch<React.SetStateAction<AppData | null>>
) {
  const today = todayISO();
  const existing = data.notifications;
  // Check if we already generated for today
  const todaysNotifs = existing.filter((n) => n.createdAt.slice(0, 10) === today);
  if (todaysNotifs.length > 5) return; // cap

  const newNotifs: AppNotification[] = [];
  // 1. Upcoming bills (within 3 days)
  const bills = getUpcomingBills(data.recurring, 3);
  for (const b of bills) {
    if (existing.some((n) => n.message.includes(b.name))) continue;
    const days = Math.ceil(
      (new Date(b.nextRunDate).getTime() - Date.now()) /
        (24 * 60 * 60 * 1000)
    );
    newNotifs.push({
      id: genId(),
      type: "bill_due",
      title: `Tagihan: ${b.name}`,
      message:
        days <= 0
          ? `Jatuh tempo hari ini ${formatCurrency(b.amount)}`
          : days === 1
          ? `Jatuh tempo besok ${formatCurrency(b.amount)}`
          : `Jatuh tempo ${days} hari lagi ${formatCurrency(b.amount)}`,
      createdAt: new Date().toISOString(),
      read: false,
    });
  }
  // 2. Budget alerts
  const monthKey = getMonthKey(today);
  const usages = getBudgetUsage(
    data.budgets,
    data.transactions,
    data.coa,
    monthKey
  );
  const threshold = data.settings.budgetAlertThreshold ?? 80;
  for (const u of usages.filter((b) => b.percent >= threshold && b.percent < 200)) {
    if (existing.some((n) => n.message.includes(u.coaName))) continue;
    newNotifs.push({
      id: genId(),
      type: "budget_alert",
      title: `Anggaran: ${u.coaName}`,
      message: `Terpakai ${u.percent.toFixed(0)}% dari ${formatCurrency(u.budget.amount)}`,
      createdAt: new Date().toISOString(),
      read: false,
    });
  }
  // 3. Low balance
  const low = getLowBalanceWallets(data.wallets, data.transactions);
  for (const w of low) {
    if (existing.some((n) => n.message.includes(w.name))) continue;
    newNotifs.push({
      id: genId(),
      type: "low_balance",
      title: `Saldo Minimum: ${w.name}`,
      message: `Saldo di bawah minimum ${formatCurrency(w.minAlert!)}`,
      createdAt: new Date().toISOString(),
      read: false,
    });
  }

  if (newNotifs.length > 0) {
    setData((d) =>
      d ? { ...d, notifications: [...newNotifs, ...d.notifications].slice(0, 50) } : d
    );
  }
}

// Helper untuk menghitung next run date sebuah recurring transaction
function computeNextRunFromRecurring(r: RecurringTransaction): string {
  const now = new Date();
  if (r.frequency === "weekly") {
    const d = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
      d.getDate()
    ).padStart(2, "0")}`;
  } else if (r.frequency === "monthly") {
    const d = new Date(now.getFullYear(), now.getMonth() + 1, Math.min(r.dayOfMonth, 28));
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
      d.getDate()
    ).padStart(2, "0")}`;
  } else {
    const d = new Date(now.getFullYear() + 1, now.getMonth(), Math.min(r.dayOfMonth, 28));
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
      d.getDate()
    ).padStart(2, "0")}`;
  }
}
