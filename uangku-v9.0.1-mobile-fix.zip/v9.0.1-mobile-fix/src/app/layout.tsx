import type { Metadata, Viewport } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const jakarta = Plus_Jakarta_Sans({
  variable: "--font-jakarta",
  subsets: ["latin"],
  weight: ["500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "Uangku Pro — Pencatat Keuangan Personal",
  description:
    "Aplikasi pencatat uang masuk & keluar dengan multi-dompet, COA, anggaran bulanan, savings goal, MTD/YTD multi-tahun, transfer antar-dompet, ekspor Excel profesional & import dari Money Lover/Monefy/Wallet. Bekerja offline & dapat dipasang di layar utama Android.",
  keywords: [
    "uangku",
    "pencatat uang",
    "uang masuk",
    "uang keluar",
    "keuangan",
    "finance tracker",
    "budget",
    "pemasukan",
    "pengeluaran",
    "COA",
    "chart of account",
    "MTD",
    "YTD",
  ],
  authors: [{ name: "Uangku Pro" }],
  manifest: "/manifest.json",
  applicationName: "Uangku Pro",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Uangku Pro",
  },
  icons: {
    icon: [
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icon-192.png", sizes: "192x192", type: "image/png" }],
  },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = {
  themeColor: "#0a0118",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${jakarta.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
      </body>
    </html>
  );
}
