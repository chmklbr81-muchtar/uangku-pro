// Excel export dengan ExcelJS — multi-sheet styled & profesional
// Sheets: Dashboard, Transaksi, Laporan Bulanan, Laporan Tahunan, COA, Anggaran, Savings Goals
// [v9.0 fix] Hapus unused imports (LOW priority cleanup) — Transaction, COAAccount,
// Wallet, Budget, SavingsGoal, formatCurrency, sumByCOA, getMonthlySeries,
// MonthlyPoint, BudgetUsage tidak pernah direferensikan setelah refactor export.
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import type { AppData } from "./types";
import {
  getMonthKey,
  getYear,
  getMonthLabel,
  getWallet,
  getCOAAccount,
  getWalletBalance,
} from "./finance";

// === Palet ===
const COLORS = {
  primary: "FFA855F7", // violet
  secondary: "FFEC4899", // pink
  dark: "FF0A0118",
  surface: "FF1A0F2E",
  textLight: "FFFFFFFF",
  textMid: "FFB8B8C8",
  textDark: "FF1F2937",
  border: "FFE5E7EB",
  headerBg: "FF2A1B47",
  headerBg2: "FF6D28D9",
  positive: "FF10B981",
  negative: "FFEF4444",
  warning: "FFF59E0B",
  altRow: "FFF8F6FC",
};

// [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
// Excel/LibreOffice akan mengeksekusi cell yang dimulai dengan = + - @ sebagai formula.
// Prefix single-quote membuat Excel memperlakukannya sebagai literal text.
// Numerik tetap dikembalikan sebagai number (bukan string) agar alignment/format angka tetap berlaku.
function sanitizeCell(value: unknown): string | number {
  if (typeof value === "number" && isFinite(value)) return value;
  const s = String(value ?? "");
  if (/^[=+\-@]/.test(s)) return "'" + s;
  return s;
}

export interface ExportOptions {
  rangeStart: string; // yyyy-mm-dd
  rangeEnd: string; // yyyy-mm-dd
  includeTransactions: boolean;
  includeMonthlyReport: boolean;
  includeYearlyReport: boolean;
  includeCOA: boolean;
  includeBudget: boolean;
  includeSavings: boolean;
  includeDashboard: boolean;
}

export const DEFAULT_EXPORT_OPTIONS: ExportOptions = {
  rangeStart: `${new Date().getFullYear()}-01-01`,
  rangeEnd: `${new Date().getFullYear()}-12-31`,
  includeTransactions: true,
  includeMonthlyReport: true,
  includeYearlyReport: true,
  includeCOA: true,
  includeBudget: true,
  includeSavings: true,
  includeDashboard: true,
};

export async function exportToExcel(data: AppData, options: ExportOptions) {
  const wb = new ExcelJS.Workbook();
  wb.creator = "Uangku Pro";
  wb.created = new Date();
  wb.properties.date1904 = false;

  const rangeLabel = `${formatDateID(options.rangeStart)} s/d ${formatDateID(
    options.rangeEnd
  )}`;

  if (options.includeDashboard) buildDashboardSheet(wb, data, options, rangeLabel);
  if (options.includeTransactions)
    buildTransactionsSheet(wb, data, options, rangeLabel);
  if (options.includeMonthlyReport)
    buildMonthlyReportSheet(wb, data, options, rangeLabel);
  if (options.includeYearlyReport)
    buildYearlyReportSheet(wb, data, options, rangeLabel);
  if (options.includeCOA) buildCOASheet(wb, data);
  if (options.includeBudget) buildBudgetSheet(wb, data, options);
  if (options.includeSavings) buildSavingsSheet(wb, data);

  const buffer = await wb.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const filename = `Uangku_Pro_${todayFile()}.xlsx`;
  saveAs(blob, filename);
  return filename;
}

function todayFile(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

function formatDateID(iso: string): string {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

// === Helper styling ===
function styleHeaderCell(cell: ExcelJS.Cell, bg: string, color = COLORS.textLight) {
  cell.fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: bg },
    fgColor: { argb: bg },
  };
  cell.font = { bold: true, color: { argb: color }, size: 11, name: "Calibri" };
  cell.alignment = { vertical: "middle", horizontal: "left" };
  cell.border = {
    bottom: { style: "thin", color: { argb: COLORS.border } },
  };
}

function styleDataCell(
  cell: ExcelJS.Cell,
  altRow = false
) {
  cell.font = { size: 10, name: "Calibri", color: { argb: COLORS.textDark } };
  cell.alignment = { vertical: "middle" };
  if (altRow) {
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      bgColor: { argb: COLORS.altRow },
      fgColor: { argb: COLORS.altRow },
    };
  }
  cell.border = {
    bottom: { style: "hair", color: { argb: COLORS.border } },
  };
}

function styleCurrencyCell(
  cell: ExcelJS.Cell,
  amount: number,
  altRow = false,
  bold = false
) {
  cell.value = amount;
  cell.numFmt = '"Rp"#,##0;[Red]"-Rp"#,##0';
  cell.font = {
    size: 10,
    name: "Calibri",
    bold,
    color: { argb: amount < 0 ? COLORS.negative : COLORS.textDark },
  };
  cell.alignment = { vertical: "middle", horizontal: "right" };
  if (altRow) {
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      bgColor: { argb: COLORS.altRow },
      fgColor: { argb: COLORS.altRow },
    };
  }
  cell.border = {
    bottom: { style: "hair", color: { argb: COLORS.border } },
  };
}

function addCoverHeader(
  ws: ExcelJS.Worksheet,
  title: string,
  subtitle: string,
  span: number
) {
  // Row 1: Brand
  ws.mergeCells(1, 1, 1, span);
  const brandCell = ws.getCell(1, 1);
  brandCell.value = "UANGKU PRO";
  brandCell.font = { bold: true, size: 20, color: { argb: COLORS.primary }, name: "Calibri" };
  brandCell.alignment = { horizontal: "left", vertical: "middle" };
  ws.getRow(1).height = 32;

  // Row 2: Tagline
  ws.mergeCells(2, 1, 2, span);
  const tagline = ws.getCell(2, 1);
  tagline.value = "Laporan Keuangan Personal";
  tagline.font = { italic: true, size: 10, color: { argb: COLORS.textMid }, name: "Calibri" };
  tagline.alignment = { horizontal: "left" };

  // Row 3: Title
  ws.mergeCells(3, 1, 3, span);
  const titleCell = ws.getCell(3, 1);
  titleCell.value = title;
  titleCell.font = { bold: true, size: 14, color: { argb: COLORS.textDark }, name: "Calibri" };
  titleCell.alignment = { horizontal: "left", vertical: "middle" };
  ws.getRow(3).height = 24;

  // Row 4: Subtitle (periode/desc)
  ws.mergeCells(4, 1, 4, span);
  const subCell = ws.getCell(4, 1);
  subCell.value = subtitle;
  subCell.font = { size: 10, color: { argb: COLORS.textMid }, name: "Calibri" };
  subCell.alignment = { horizontal: "left" };

  // Row 5: empty
  ws.getRow(5).height = 6;
}

// === SHEET 1: DASHBOARD ===
function buildDashboardSheet(
  wb: ExcelJS.Workbook,
  data: AppData,
  options: ExportOptions,
  rangeLabel: string
) {
  const ws = wb.addWorksheet("Dashboard", {
    properties: { tabColor: { argb: COLORS.primary } },
  });
  ws.columns = [
    { width: 32 },
    { width: 22 },
    { width: 22 },
    { width: 22 },
  ];

  addCoverHeader(ws, "Ringkasan Keuangan", `Periode: ${rangeLabel}`, 4);

  // Filter transaksi dalam range
  const txs = data.transactions.filter(
    (t) => t.date >= options.rangeStart && t.date <= options.rangeEnd
  );
  const totalIncome = txs.filter((t) => t.type === "income").reduce((a, t) => a + t.amount, 0);
  const totalExpense = txs.filter((t) => t.type === "expense").reduce((a, t) => a + t.amount, 0);
  const totalTransfer = txs.filter((t) => t.type === "transfer").reduce((a, t) => a + t.amount, 0);
  const balance = totalIncome - totalExpense;
  const savingsRate = totalIncome > 0 ? (balance / totalIncome) * 100 : 0;

  // Section: Ringkasan
  ws.mergeCells(6, 1, 6, 4);
  const sec1 = ws.getCell(6, 1);
  sec1.value = "📊 Ringkasan Periode";
  sec1.font = { bold: true, size: 12, color: { argb: COLORS.primary } };
  sec1.fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: "FFF3E8FF" },
    fgColor: { argb: "FFF3E8FF" },
  };
  sec1.alignment = { horizontal: "left", vertical: "middle" };
  ws.getRow(6).height = 22;

  // Stat cards
  const stats = [
    { label: "Total Pemasukan", value: totalIncome, color: COLORS.positive, sign: "+" },
    { label: "Total Pengeluaran", value: totalExpense, color: COLORS.negative, sign: "−" },
    { label: "Selisih (Net)", value: balance, color: balance >= 0 ? COLORS.positive : COLORS.negative, sign: balance >= 0 ? "+" : "−" },
    { label: "Total Transfer Antar-Dompet", value: totalTransfer, color: COLORS.textDark, sign: "" },
    { label: "Savings Rate", value: savingsRate, color: COLORS.primary, isPercent: true },
    { label: "Jumlah Transaksi", value: txs.length, color: COLORS.textDark, isCount: true },
  ];

  let row = 7;
  for (const s of stats) {
    ws.getCell(row, 1).value = s.label;
    styleDataCell(ws.getCell(row, 1));
    ws.getCell(row, 1).font = { size: 11, name: "Calibri", color: { argb: COLORS.textDark } };

    if (s.isPercent) {
      const c = ws.getCell(row, 2);
      c.value = s.value / 100;
      c.numFmt = "0.0%";
      c.font = { bold: true, size: 12, color: { argb: s.color } };
      c.alignment = { horizontal: "right" };
    } else if (s.isCount) {
      const c = ws.getCell(row, 2);
      c.value = s.value;
      c.font = { bold: true, size: 12, color: { argb: s.color } };
      c.alignment = { horizontal: "right" };
    } else {
      styleCurrencyCell(ws.getCell(row, 2), s.value, false, true);
    }
    row++;
  }

  // Section: Saldo per dompet
  row += 1;
  ws.mergeCells(row, 1, row, 4);
  const sec2 = ws.getCell(row, 1);
  sec2.value = "💳 Saldo per Dompet";
  sec2.font = { bold: true, size: 12, color: { argb: COLORS.primary } };
  sec2.fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: "FFF3E8FF" },
    fgColor: { argb: "FFF3E8FF" },
  };
  sec2.alignment = { horizontal: "left", vertical: "middle" };
  ws.getRow(row).height = 22;
  row += 1;

  // Header
  ["Dompet", "Tipe", "Saldo Awal", "Saldo Saat Ini"].forEach((h, i) => {
    const c = ws.getCell(row, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  row += 1;

  const activeWallets = data.wallets.filter((w) => !w.archived);
  activeWallets.forEach((w, idx) => {
    const alt = idx % 2 === 1;
    ws.getCell(row, 1).value = sanitizeCell(`${w.icon} ${w.name}`);
    styleDataCell(ws.getCell(row, 1), alt);
    ws.getCell(row, 2).value = sanitizeCell(w.type.replace(/_/g, " "));
    styleDataCell(ws.getCell(row, 2), alt);
    styleCurrencyCell(ws.getCell(row, 3), w.initialBalance, alt);
    const current = getWalletBalance(w.id, data.transactions, data.wallets);
    styleCurrencyCell(ws.getCell(row, 4), current, alt, true);
    row++;
  });

  // Total saldo
  ws.getCell(row, 1).value = "TOTAL";
  styleDataCell(ws.getCell(row, 1));
  ws.getCell(row, 1).font = { bold: true, size: 11, name: "Calibri" };
  ws.getCell(row, 2).value = "";
  styleDataCell(ws.getCell(row, 2));
  const totalInit = activeWallets.reduce((a, w) => a + w.initialBalance, 0);
  styleCurrencyCell(ws.getCell(row, 3), totalInit, false, true);
  const totalCur = activeWallets.reduce(
    (a, w) => a + getWalletBalance(w.id, data.transactions, data.wallets),
    0
  );
  styleCurrencyCell(ws.getCell(row, 4), totalCur, false, true);
  ws.getRow(row).height = 22;

  // Footer
  row += 2;
  ws.getCell(row, 1).value = `Diekspor pada ${new Date().toLocaleString("id-ID")}`;
  ws.getCell(row, 1).font = { italic: true, size: 9, color: { argb: COLORS.textMid } };
}

// === SHEET 2: TRANSAKSI ===
function buildTransactionsSheet(
  wb: ExcelJS.Workbook,
  data: AppData,
  options: ExportOptions,
  rangeLabel: string
) {
  const ws = wb.addWorksheet("Transaksi", {
    properties: { tabColor: { argb: COLORS.secondary } },
  });
  ws.columns = [
    { width: 14 },
    { width: 14 },
    { width: 22 },
    { width: 12 },
    { width: 16 },
    { width: 18 },
    { width: 30 },
    { width: 16 },
    { width: 18 },
  ];

  addCoverHeader(ws, "Daftar Transaksi", `Periode: ${rangeLabel}`, 9);

  // Header
  const headers = [
    "Tanggal",
    "Tipe",
    "Dompet",
    "Jumlah",
    "Kode COA",
    "Kategori (COA)",
    "Catatan",
    "Tag",
    "Dibuat Pada",
  ];
  headers.forEach((h, i) => {
    const c = ws.getCell(6, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  ws.getRow(6).height = 26;

  const txs = data.transactions
    .filter((t) => t.date >= options.rangeStart && t.date <= options.rangeEnd)
    .sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.createdAt.localeCompare(a.createdAt);
    });

  let row = 7;
  txs.forEach((t, idx) => {
    const alt = idx % 2 === 1;
    const wallet = getWallet(data.wallets, t.walletId);
    const coa = getCOAAccount(data.coa, t.coaId);

    ws.getCell(row, 1).value = new Date(t.date);
    ws.getCell(row, 1).numFmt = "dd-mmm-yyyy";
    styleDataCell(ws.getCell(row, 1), alt);

    ws.getCell(row, 2).value =
      t.type === "income"
        ? "Masuk"
        : t.type === "expense"
        ? "Keluar"
        : "Transfer";
    ws.getCell(row, 2).font = {
      size: 10,
      name: "Calibri",
      bold: true,
      color: {
        argb:
          t.type === "income"
            ? COLORS.positive
            : t.type === "expense"
            ? COLORS.negative
            : COLORS.primary,
      },
    };
    ws.getCell(row, 2).alignment = { vertical: "middle" };

    ws.getCell(row, 3).value = wallet ? sanitizeCell(`${wallet.icon} ${wallet.name}`) : "—";
    styleDataCell(ws.getCell(row, 3), alt);

    styleCurrencyCell(ws.getCell(row, 4), t.amount, alt);

    ws.getCell(row, 5).value = sanitizeCell(coa?.code ?? "—");
    styleDataCell(ws.getCell(row, 5), alt);

    // [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
    ws.getCell(row, 6).value = sanitizeCell(coa?.name ?? t.category);
    styleDataCell(ws.getCell(row, 6), alt);

    // [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
    ws.getCell(row, 7).value = sanitizeCell(t.note ?? "");
    styleDataCell(ws.getCell(row, 7), alt);

    // [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
    ws.getCell(row, 8).value = sanitizeCell((t.tags ?? []).join(", "));
    styleDataCell(ws.getCell(row, 8), alt);

    ws.getCell(row, 9).value = new Date(t.createdAt);
    ws.getCell(row, 9).numFmt = "dd-mmm-yyyy HH:mm";
    styleDataCell(ws.getCell(row, 9), alt);

    row++;
  });

  // Freeze panes
  ws.views = [{ state: "frozen", ySplit: 6 }];
}

// === SHEET 3: LAPORAN BULANAN ===
function buildMonthlyReportSheet(
  wb: ExcelJS.Workbook,
  data: AppData,
  options: ExportOptions,
  rangeLabel: string
) {
  const ws = wb.addWorksheet("Laporan Bulanan", {
    properties: { tabColor: { argb: COLORS.positive } },
  });
  ws.columns = [
    { width: 22 },
    { width: 18 },
    { width: 18 },
    { width: 18 },
    { width: 14 },
  ];

  addCoverHeader(ws, "Laporan Bulanan", `Periode: ${rangeLabel}`, 5);

  // Header
  const headers = ["Bulan", "Pemasukan", "Pengeluaran", "Selisih", "Savings %"];
  headers.forEach((h, i) => {
    const c = ws.getCell(6, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  ws.getRow(6).height = 26;

  // Kumpulkan semua monthKey yang ada transaksi dalam range
  const startMonth = options.rangeStart.slice(0, 7);
  const endMonth = options.rangeEnd.slice(0, 7);
  const months: string[] = [];
  let [sy, sm] = startMonth.split("-").map(Number);
  let [ey, em] = endMonth.split("-").map(Number);
  let cy = sy,
    cm = sm;
  while (cy < ey || (cy === ey && cm <= em)) {
    months.push(`${cy}-${String(cm).padStart(2, "0")}`);
    cm++;
    if (cm > 12) {
      cm = 1;
      cy++;
    }
  }

  let row = 7;
  let totalIn = 0,
    totalOut = 0;
  months.forEach((mk, idx) => {
    const alt = idx % 2 === 1;
    let income = 0,
      expense = 0;
    for (const t of data.transactions) {
      if (t.type === "transfer") continue;
      if (getMonthKey(t.date) !== mk) continue;
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    }
    totalIn += income;
    totalOut += expense;

    ws.getCell(row, 1).value = getMonthLabel(mk);
    styleDataCell(ws.getCell(row, 1), alt);
    ws.getCell(row, 1).font = { size: 11, name: "Calibri", bold: true };
    styleCurrencyCell(ws.getCell(row, 2), income, alt);
    styleCurrencyCell(ws.getCell(row, 3), expense, alt);
    styleCurrencyCell(ws.getCell(row, 4), income - expense, alt, true);
    const sr = income > 0 ? (income - expense) / income : 0;
    const c = ws.getCell(row, 5);
    c.value = sr;
    c.numFmt = "0.0%";
    c.font = { size: 10, name: "Calibri", color: { argb: COLORS.primary }, bold: true };
    c.alignment = { horizontal: "right" };
    if (alt) {
      c.fill = {
        type: "pattern",
        pattern: "solid",
        bgColor: { argb: COLORS.altRow },
        fgColor: { argb: COLORS.altRow },
      };
    }
    row++;
  });

  // Total
  ws.getCell(row, 1).value = "TOTAL";
  ws.getCell(row, 1).font = { bold: true, size: 12 };
  ws.getCell(row, 1).fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: COLORS.headerBg },
    fgColor: { argb: COLORS.headerBg },
  };
  ws.getCell(row, 1).font = { bold: true, size: 12, color: { argb: COLORS.textLight } };
  ws.getCell(row, 2).fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: COLORS.headerBg },
    fgColor: { argb: COLORS.headerBg },
  };
  ws.getCell(row, 3).fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: COLORS.headerBg },
    fgColor: { argb: COLORS.headerBg },
  };
  ws.getCell(row, 4).fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: COLORS.headerBg },
    fgColor: { argb: COLORS.headerBg },
  };
  ws.getCell(row, 5).fill = {
    type: "pattern",
    pattern: "solid",
    bgColor: { argb: COLORS.headerBg },
    fgColor: { argb: COLORS.headerBg },
  };
  styleCurrencyCell(ws.getCell(row, 2), totalIn, false, true);
  styleCurrencyCell(ws.getCell(row, 3), totalOut, false, true);
  styleCurrencyCell(ws.getCell(row, 4), totalIn - totalOut, false, true);
  const c = ws.getCell(row, 5);
  c.value = totalIn > 0 ? (totalIn - totalOut) / totalIn : 0;
  c.numFmt = "0.0%";
  c.font = { bold: true, size: 12, color: { argb: COLORS.textLight } };
  c.alignment = { horizontal: "right" };

  ws.views = [{ state: "frozen", ySplit: 6 }];
}

// === SHEET 4: LAPORAN TAHUNAN (multi-tahun, YoY) ===
function buildYearlyReportSheet(
  wb: ExcelJS.Workbook,
  data: AppData,
  options: ExportOptions,
  rangeLabel: string
) {
  const ws = wb.addWorksheet("Laporan Tahunan", {
    properties: { tabColor: { argb: COLORS.warning } },
  });
  ws.columns = [
    { width: 10 },
    { width: 18 },
    { width: 18 },
    { width: 18 },
    { width: 14 },
    { width: 14 },
  ];

  addCoverHeader(ws, "Laporan Tahunan (Multi-Tahun)", `Periode: ${rangeLabel}`, 6);

  const headers = [
    "Tahun",
    "Pemasukan",
    "Pengeluaran",
    "Selisih",
    "Savings %",
    "YoY %",
  ];
  headers.forEach((h, i) => {
    const c = ws.getCell(6, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  ws.getRow(6).height = 26;

  const startY = getYear(options.rangeStart);
  const endY = getYear(options.rangeEnd);
  const years: number[] = [];
  for (let y = startY; y <= endY; y++) years.push(y);

  let row = 7;
  let prevNet: number | null = null;
  years.forEach((y, idx) => {
    const alt = idx % 2 === 1;
    let income = 0,
      expense = 0;
    for (const t of data.transactions) {
      if (t.type === "transfer") continue;
      if (getYear(t.date) !== y) continue;
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    }
    const net = income - expense;
    const sr = income > 0 ? net / income : 0;

    ws.getCell(row, 1).value = y;
    styleDataCell(ws.getCell(row, 1), alt);
    ws.getCell(row, 1).font = { size: 12, name: "Calibri", bold: true };
    styleCurrencyCell(ws.getCell(row, 2), income, alt);
    styleCurrencyCell(ws.getCell(row, 3), expense, alt);
    styleCurrencyCell(ws.getCell(row, 4), net, alt, true);

    const c = ws.getCell(row, 5);
    c.value = sr;
    c.numFmt = "0.0%";
    c.font = { size: 10, name: "Calibri", color: { argb: COLORS.primary }, bold: true };
    c.alignment = { horizontal: "right" };
    if (alt) {
      c.fill = {
        type: "pattern",
        pattern: "solid",
        bgColor: { argb: COLORS.altRow },
        fgColor: { argb: COLORS.altRow },
      };
    }

    const yoy = ws.getCell(row, 6);
    if (prevNet !== null && prevNet !== 0) {
      yoy.value = (net - prevNet) / Math.abs(prevNet);
      yoy.numFmt = "+0.0%;-0.0%;0%";
      yoy.font = {
        size: 10,
        name: "Calibri",
        bold: true,
        color: { argb: net >= prevNet ? COLORS.positive : COLORS.negative },
      };
    } else {
      yoy.value = "—";
      yoy.font = { size: 10, color: { argb: COLORS.textMid } };
    }
    yoy.alignment = { horizontal: "right" };
    if (alt) {
      yoy.fill = {
        type: "pattern",
        pattern: "solid",
        bgColor: { argb: COLORS.altRow },
        fgColor: { argb: COLORS.altRow },
      };
    }

    prevNet = net;
    row++;
  });

  ws.views = [{ state: "frozen", ySplit: 6 }];
}

// === SHEET 5: COA ===
function buildCOASheet(wb: ExcelJS.Workbook, data: AppData) {
  const ws = wb.addWorksheet("COA", {
    properties: { tabColor: { argb: "FF0EA5E9" } },
  });
  ws.columns = [{ width: 14 }, { width: 36 }, { width: 18 }, { width: 12 }];

  addCoverHeader(ws, "Chart of Account", "Daftar akun lengkap Uangku Pro", 4);

  const headers = ["Kode", "Nama Akun", "Tipe", "Status"];
  headers.forEach((h, i) => {
    const c = ws.getCell(6, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  ws.getRow(6).height = 26;

  const sorted = [...data.coa].sort((a, b) => a.code.localeCompare(b.code));
  let row = 7;
  sorted.forEach((acc, idx) => {
    const alt = idx % 2 === 1;
    const isRoot = acc.parentId === null;
    ws.getCell(row, 1).value = sanitizeCell(acc.code);
    styleDataCell(ws.getCell(row, 1), alt);
    if (isRoot) {
      ws.getCell(row, 1).font = { bold: true, size: 11, name: "Calibri" };
    }
    // [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
    ws.getCell(row, 2).value = sanitizeCell(isRoot ? acc.name.toUpperCase() : `   ↳ ${acc.name}`);
    styleDataCell(ws.getCell(row, 2), alt);
    if (isRoot) {
      ws.getCell(row, 2).font = { bold: true, size: 11, name: "Calibri" };
    }
    ws.getCell(row, 3).value = acc.type.replace(/_/g, " ");
    styleDataCell(ws.getCell(row, 3), alt);
    ws.getCell(row, 4).value = acc.archived ? "Arsip" : "Aktif";
    styleDataCell(ws.getCell(row, 4), alt);
    row++;
  });

  ws.views = [{ state: "frozen", ySplit: 6 }];
}

// === SHEET 6: ANGGARAN ===
function buildBudgetSheet(
  wb: ExcelJS.Workbook,
  data: AppData,
  options: ExportOptions
) {
  const ws = wb.addWorksheet("Anggaran", {
    properties: { tabColor: { argb: "FF8B5CF6" } },
  });
  ws.columns = [
    { width: 12 },
    { width: 14 },
    { width: 30 },
    { width: 16 },
    { width: 16 },
    { width: 12 },
  ];

  addCoverHeader(
    ws,
    "Laporan Anggaran",
    `Tahun ${getYear(options.rangeStart)}`,
    6
  );

  const headers = ["Bulan", "Kode", "Kategori", "Anggaran", "Terpakai", "%"];
  headers.forEach((h, i) => {
    const c = ws.getCell(6, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  ws.getRow(6).height = 26;

  // Ambil budget untuk tahun range
  const startYear = getYear(options.rangeStart);
  const endYear = getYear(options.rangeEnd);
  const budgets = data.budgets.filter((b) => {
    const y = Number(b.monthKey.slice(0, 4));
    return y >= startYear && y <= endYear;
  });

  let row = 7;
  budgets
    .sort((a, b) => a.monthKey.localeCompare(b.monthKey))
    .forEach((b, idx) => {
      const alt = idx % 2 === 1;
      const coa = getCOAAccount(data.coa, b.coaId);
      const used = data.transactions
        .filter(
          (t) =>
            t.coaId === b.coaId &&
            getMonthKey(t.date) === b.monthKey &&
            t.type === "expense"
        )
        .reduce((a, t) => a + t.amount, 0);
      const percent = b.amount > 0 ? (used / b.amount) * 100 : 0;

      ws.getCell(row, 1).value = getMonthLabel(b.monthKey);
      styleDataCell(ws.getCell(row, 1), alt);
      // [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
      ws.getCell(row, 2).value = sanitizeCell(coa?.code ?? "—");
      styleDataCell(ws.getCell(row, 2), alt);
      ws.getCell(row, 3).value = sanitizeCell(coa?.name ?? "—");
      styleDataCell(ws.getCell(row, 3), alt);
      styleCurrencyCell(ws.getCell(row, 4), b.amount, alt);
      styleCurrencyCell(ws.getCell(row, 5), used, alt);
      const c = ws.getCell(row, 6);
      c.value = percent / 100;
      c.numFmt = "0%";
      c.font = {
        size: 10,
        name: "Calibri",
        bold: true,
        color: {
          argb:
            percent >= 100
              ? COLORS.negative
              : percent >= 80
              ? COLORS.warning
              : COLORS.positive,
        },
      };
      c.alignment = { horizontal: "right" };
      if (alt) {
        c.fill = {
          type: "pattern",
          pattern: "solid",
          bgColor: { argb: COLORS.altRow },
          fgColor: { argb: COLORS.altRow },
        };
      }
      row++;
    });

  ws.views = [{ state: "frozen", ySplit: 6 }];
}

// === SHEET 7: SAVINGS GOALS ===
function buildSavingsSheet(wb: ExcelJS.Workbook, data: AppData) {
  const ws = wb.addWorksheet("Savings Goals", {
    properties: { tabColor: { argb: COLORS.positive } },
  });
  ws.columns = [
    { width: 22 },
    { width: 18 },
    { width: 18 },
    { width: 14 },
    { width: 14 },
    { width: 14 },
  ];

  addCoverHeader(ws, "Savings Goals", "Target tabungan & progress", 6);

  const headers = [
    "Nama Target",
    "Target",
    "Tercapai",
    "Sisa",
    "Progress",
    "Deadline",
  ];
  headers.forEach((h, i) => {
    const c = ws.getCell(6, i + 1);
    c.value = h;
    styleHeaderCell(c, COLORS.headerBg);
  });
  ws.getRow(6).height = 26;

  let row = 7;
  data.savingsGoals
    .filter((g) => !g.archived)
    .forEach((g, idx) => {
      const alt = idx % 2 === 1;
      // [v9.0 fix] Cegah formula injection (CWE-1236) — prefix ' untuk leading =+-@
      ws.getCell(row, 1).value = sanitizeCell(g.name);
      styleDataCell(ws.getCell(row, 1), alt);
      styleCurrencyCell(ws.getCell(row, 2), g.targetAmount, alt);
      styleCurrencyCell(ws.getCell(row, 3), g.currentAmount, alt, true);
      styleCurrencyCell(ws.getCell(row, 4), g.targetAmount - g.currentAmount, alt);
      const c = ws.getCell(row, 5);
      c.value = g.targetAmount > 0 ? g.currentAmount / g.targetAmount : 0;
      c.numFmt = "0.0%";
      c.font = { bold: true, size: 11, name: "Calibri", color: { argb: COLORS.primary } };
      c.alignment = { horizontal: "right" };
      if (alt) {
        c.fill = {
          type: "pattern",
          pattern: "solid",
          bgColor: { argb: COLORS.altRow },
          fgColor: { argb: COLORS.altRow },
        };
      }
      ws.getCell(row, 6).value = g.deadline ? new Date(g.deadline) : "—";
      if (g.deadline) ws.getCell(row, 6).numFmt = "dd-mmm-yyyy";
      styleDataCell(ws.getCell(row, 6), alt);
      row++;
    });

  ws.views = [{ state: "frozen", ySplit: 6 }];
}
