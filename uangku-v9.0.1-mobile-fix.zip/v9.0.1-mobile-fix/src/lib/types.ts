// Tipe data lengkap untuk Uangku Pro
// PWA pencatat keuangan personal: multi-dompet, COA Full Pro, MTD/YTD, transfer, savings, recurring

// === DOMPET (Multi-Wallet) ===
export type WalletType =
  | "cash"
  | "bank_bca"
  | "bank_mandiri"
  | "ewallet_gopay"
  | "ewallet_ovo"
  | "ewallet_dana"
  | "ewallet_shopeepay"
  | "qris"
  | "investment";

export type CurrencyCode = "IDR" | "USD" | "SGD" | "EUR" | "JPY" | "GBP";

export interface Wallet {
  id: string;
  name: string;
  type: WalletType;
  icon: string; // emoji
  color: string; // hex string untuk accent
  initialBalance: number; // saldo awal saat dompet dibuat
  minAlert?: number; // alert saldo minimum
  createdAt: string;
  archived?: boolean;
  currency?: CurrencyCode; // default IDR, tapi bisa valas
  exchangeRate?: number; // rate ke IDR, diupdate manual/user input
}

// === COA (Chart of Account) Full Pro ===
// 8-9 akun induk + sub-akun bisa dikustom
export type COAType =
  | "asset" // Aset
  | "liability" // Kewajiban
  | "equity" // Ekuitas
  | "income" // Pendapatan
  | "expense" // Beban
  | "capital" // Modal
  | "drawings" // Prive
  | "other_income" // Pendapatan Lain
  | "operating_expense"; // Beban Operasional

export interface COAAccount {
  id: string;
  code: string; // contoh "1-1000"
  name: string;
  type: COAType;
  parentId: string | null; // null = akun induk
  isDefault: boolean; // true = tidak bisa dihapus (default bawaan)
  archived?: boolean;
}

// === TRANSAKSI ===
export type TransactionType = "income" | "expense" | "transfer";

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  date: string; // yyyy-mm-dd
  walletId: string;
  coaId: string; // akun COA yang dipengaruhi
  category: string; // redundant dari COA name untuk backward search
  note?: string;
  tags?: string[]; // tag multi-dimensi
  createdAt: string;
  // Untuk transfer
  transferToWalletId?: string;
  transferPairId?: string; // id pasangan (income+expense) untuk transfer
  fromRecurringId?: string;
  // [v9.0 fix] T-1.2: Soft-delete + LWW sync support
  // deletedAt = ISO timestamp saat transaksi di-soft-delete; item tetap disimpan selama 30 hari untuk propagate deletion via sync.
  // updatedAt = ISO timestamp perubahan terakhir; dipakai mergeCollection() di supabaseSmartSync untuk last-write-wins.
  deletedAt?: string;
  updatedAt?: string;
}

// === ANGGARAN (Budget) ===
export interface Budget {
  id: string;
  coaId: string;
  monthKey: string; // yyyy-mm
  amount: number; // batas anggaran bulan itu
}

// === SAVINGS GOAL ===
export interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  deadline?: string; // yyyy-mm-dd opsional
  walletId?: string; // dompet yang jadi sumber tabungan
  color: string;
  createdAt: string;
  archived?: boolean;
}

// === TRANSAKSI BERULANG ===
export type RecurringFrequency = "weekly" | "monthly" | "yearly";

export interface RecurringTransaction {
  id: string;
  name: string;
  type: "income" | "expense";
  amount: number;
  walletId: string;
  coaId: string;
  frequency: RecurringFrequency;
  dayOfMonth: number; // 1-31 (untuk monthly/yearly) atau 0-6 (untuk weekly = Minggu-Sabtu)
  startDate: string;
  nextRunDate: string;
  note?: string;
  archived?: boolean;
}

// === NOTIFIKASI ===
export type NotificationType =
  | "bill_due" // tagihan jatuh tempo
  | "budget_alert" // anggaran hampir habis
  | "daily_reminder" // catat harian
  | "low_balance"; // saldo minimum

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  read: boolean;
  actionUrl?: string;
}

// === UTANG-PIUTANG (Debt Tracker) ===
export type DebtType = "receivable" | "payable"; // piutang (orang utang ke saya) / utang (saya utang ke orang)
export type DebtStatus = "active" | "paid" | "partial";

export interface DebtLoan {
  id: string;
  type: DebtType;
  personName: string;
  amount: number; // total utang/piutang
  paidAmount: number; // sudah dibayar/terima berapa
  date: string; // tanggal pinjam
  dueDate?: string; // jatuh tempo
  note?: string;
  walletId?: string; // dompet yang dipakai untuk transaksi
  status: DebtStatus;
  createdAt: string;
  updatedAt: string;
}

// === PENGATURAN ===
export type ThemeChoice = "navy-gold" | "bank-pro" | "green-eco" | "pink-pastel" | "black-cyan";

export interface Settings {
  ownerName: string;
  currency: string; // default IDR
  dailyReminderHour: number; // 0-23
  dailyReminderEnabled: boolean;
  budgetAlertThreshold: number; // persen, default 80
  notificationsEnabled: boolean;
  // Keamanan
  biometricEnabled: boolean;
  pinEnabled: boolean;
  // [v9.0 fix] C-3: pinHash disimpan di sini sebagai source-of-truth canonical.
  // Legacy localStorage key "uangku.pinHash" hanya dipakai untuk backward-compat baca.
  pinHash?: string; // hash PIN (PBKDF2-SHA256), jangan simpan plain text
  autoLockMinutes: number; // 0 = tidak auto-lock
  // Privacy & Security
  privacyBlurMode: boolean; // hide nominal saat screenshot
  largeTxConfirmation: boolean; // konfirmasi 2x untuk transaksi > Rp 1jt
  largeTxThreshold: number; // batas, default 1jt
  encryptedBackupPassword?: string; // hash password untuk encrypted backup
  // Sync
  syncEnabled: boolean;
  syncProvider?: "supabase";
  supabaseUrl?: string;
  supabaseAnonKey?: string;
  syncUserId?: string;
  syncEmail?: string;
  lastSyncAt?: string;
  // Auto-backup
  autoBackupEnabled: boolean;
  autoBackupProvider?: "gdrive";
  gdriveClientId?: string;
  gdriveFolderId?: string;
  lastBackupAt?: string;
  // Tema
  themeMode: "dark" | "light" | "auto";
  themeChoice: ThemeChoice; // pilihan tema visual
}

// === ACTIVITY LOG (audit trail) ===
export type ActivityType =
  | "app_open"
  | "app_close"
  | "login_biometric"
  | "login_pin"
  | "login_failed"
  | "tx_add"
  | "tx_edit"
  | "tx_delete"
  | "sync_push"
  | "sync_pull"
  | "backup_create"
  | "backup_restore"
  | "settings_change";

export interface ActivityLog {
  id: string;
  type: ActivityType;
  description: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

// === STATE STORAGE ===
// Semua data disimpan dalam 1 key dengan struktur ini
export interface AppData {
  schemaVersion: number;
  wallets: Wallet[];
  coa: COAAccount[];
  transactions: Transaction[];
  budgets: Budget[];
  savingsGoals: SavingsGoal[];
  recurring: RecurringTransaction[];
  notifications: AppNotification[];
  debts: DebtLoan[];
  activityLogs: ActivityLog[];
  settings: Settings;
}
