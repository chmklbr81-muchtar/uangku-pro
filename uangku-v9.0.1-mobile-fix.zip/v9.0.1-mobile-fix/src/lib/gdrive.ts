// Modul backup ke Google Drive — pakai Google Identity OAuth 2.0 implicit flow
// User harus buat Google OAuth Client ID di https://console.cloud.google.com
// Authorized JavaScript origins: domain aplikasi (mis. https://stirring-hummingbird-8e6c8f.netlify.app)
// Authorized redirect URIs: domain + / (root)
//
// Cara pakai:
// 1. User masukkan Client ID di Settings
// 2. Klik "Aktifkan Google Drive" → akan redirect ke Google login
// 3. Setelah login, otomatis dapat access token
// 4. Auto-backup mingguan: upload file JSON ke folder "Uangku Pro" di Drive user
//
// [v9.0 fix] T-2.3: OAuth state sekarang random nonce per-request (16-char hex) disimpan di
// sessionStorage, divalidasi di parseTokenFromUrl() untuk cegah CSRF / token substitution attack.
// [v9.0 fix] T-2.6: searchFile() sekarang filter `parents` supaya tidak overwrite file di folder lain.

import type { AppData } from "./types";

const SCOPE = "https://www.googleapis.com/auth/drive.file";
const TOKEN_KEY = "uangku.gdrive.token";
const TOKEN_EXPIRY_KEY = "uangku.gdrive.tokenExpiry";
// [v9.0 fix] T-2.3: state nonce disimpan di sessionStorage (bukan localStorage) supaya cleared saat tab tutup.
const OAUTH_STATE_KEY = "uangku.oauth.state";
const SOFT_DELETE_WINDOW_MS = 30 * 24 * 60 * 60 * 1000; // 30 hari

interface TokenInfo {
  access_token: string;
  expires_in: number;
  expires_at: number;
}

// [v9.0 fix] T-2.3: generate random 16-char hex nonce untuk OAuth state parameter.
// Pakai crypto.getRandomValues (tersedia di browser modern + Capacitor WebView) supaya cryptographically secure.
export function generateStateNonce(): string {
  if (typeof window === "undefined" || !window.crypto?.getRandomValues) {
    // Fallback untuk environment tanpa WebCrypto — Math.random less secure tapi masih random
    return Array.from({ length: 16 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
  }
  const bytes = new Uint8Array(8); // 8 bytes = 16 hex chars
  window.crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

export function getStoredToken(): TokenInfo | null {
  if (typeof window === "undefined") return null;
  const token = localStorage.getItem(TOKEN_KEY);
  const expiry = localStorage.getItem(TOKEN_EXPIRY_KEY);
  if (!token || !expiry) return null;
  const expiresAt = Number(expiry);
  if (Date.now() > expiresAt) return null;
  return { access_token: token, expires_in: 0, expires_at: expiresAt };
}

// Generate OAuth URL untuk redirect
// @deprecated v8.x — penggunaan langsung di settings-panels.tsx juga masih ada; akan disatukan di v9.1.
// [v9.0 fix] T-2.3: state sekarang nonce acak, disimpan ke sessionStorage sebelum redirect.
export function getOAuthUrl(clientId: string, redirectUri: string): string {
  const state = generateStateNonce();
  if (typeof window !== "undefined") {
    sessionStorage.setItem(OAUTH_STATE_KEY, state);
  }
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: "token",
    scope: SCOPE,
    include_granted_scopes: "true",
    state,
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
}

// Parse token dari URL setelah redirect dari Google
// [v9.0 fix] T-2.3: validasi state parameter dari URL == nonce yang disimpan sebelum redirect.
// Throw error jika mismatch (kemungkinan CSRF / token substitution attack).
export function parseTokenFromUrl(): TokenInfo | null {
  if (typeof window === "undefined") return null;
  const hash = window.location.hash.slice(1);
  if (!hash) return null;
  const params = new URLSearchParams(hash);

  // [v9.0 fix] T-2.3: cek error response dari Google (mis. user deny consent)
  const oauthError = params.get("error");
  if (oauthError) {
    const desc = params.get("error_description") ?? oauthError;
    // Bersihkan hash dari URL agar tidak re-trigger
    window.history.replaceState(null, "", window.location.pathname);
    throw new Error(`Google OAuth error: ${desc}`);
  }

  // [v9.0 fix] T-2.3: validate state — tolak jika mismatch atau tidak ada
  const returnedState = params.get("state");
  const expectedState =
    typeof window !== "undefined" ? sessionStorage.getItem(OAUTH_STATE_KEY) : null;
  if (!expectedState || !returnedState || returnedState !== expectedState) {
    // Bersihkan hash & state supaya tidak re-trigger, lalu throw supaya caller tahu ada potensi serangan
    window.history.replaceState(null, "", window.location.pathname);
    sessionStorage.removeItem(OAUTH_STATE_KEY);
    throw new Error(
      "OAuth state mismatch — kemungkinan CSRF/token substitution attack. Backup diblokir."
    );
  }
  // [v9.0 fix] T-2.3: clear state setelah dipakai (one-time use)
  sessionStorage.removeItem(OAUTH_STATE_KEY);

  const accessToken = params.get("access_token");
  const expiresIn = Number(params.get("expires_in") ?? "0");
  if (!accessToken || expiresIn <= 0) return null;
  const tokenInfo: TokenInfo = {
    access_token: accessToken,
    expires_in: expiresIn,
    expires_at: Date.now() + expiresIn * 1000,
  };
  localStorage.setItem(TOKEN_KEY, accessToken);
  localStorage.setItem(TOKEN_EXPIRY_KEY, String(tokenInfo.expires_at));
  // Bersihkan hash dari URL
  window.history.replaceState(null, "", window.location.pathname);
  return tokenInfo;
}

// Buat folder "Uangku Pro" di Drive user (jika belum ada), return folder ID
async function getOrCreateFolder(token: string): Promise<string | null> {
  try {
    // Cari folder dulu
    const searchRes = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=name%3D'Uangku%20Pro'%20and%20mimeType%3D'application%2Fvnd.google-apps.folder'%20and%20trashed%3Dfalse`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!searchRes.ok) return null;
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      return searchData.files[0].id as string;
    }
    // Buat folder baru
    const createRes = await fetch("https://www.googleapis.com/drive/v3/files", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: "Uangku Pro",
        mimeType: "application/vnd.google-apps.folder",
      }),
    });
    if (!createRes.ok) return null;
    const createData = await createRes.json();
    return createData.id as string;
  } catch {
    return null;
  }
}

// [v9.0 fix] T-2.6: searchFile sekarang filter `parents` supaya hanya cocok file di folder Uangku Pro.
// Sebelumnya query hanya `name='...' and trashed=false` → bisa kena file di folder lain dengan nama sama
// (mis. backup lama di root Drive atau folder lain milik user) → PATCH akan menimpanya & kehilangan parent.
export async function searchFile(
  fileName: string,
  folderId: string,
  token: string
): Promise<{ id: string } | null> {
  try {
    // Escape single quote di nama file supaya query Google Drive tidak rusak (although filename dari dateStr).
    const escapedName = fileName.replace(/'/g, "\\'");
    const q = `name='${escapedName}' and '${folderId}' in parents and trashed=false`;
    const searchRes = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!searchRes.ok) return null;
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      return { id: searchData.files[0].id as string };
    }
    return null;
  } catch {
    return null;
  }
}

// Upload backup JSON ke Drive
export async function backupToGDrive(
  data: AppData,
  token?: string
): Promise<{ success: boolean; fileId?: string; error?: string }> {
  try {
    const tokenInfo = token ? { access_token: token } : getStoredToken();
    if (!tokenInfo) return { success: false, error: "Belum login Google" };
    const folderId = await getOrCreateFolder(tokenInfo.access_token);
    if (!folderId) return { success: false, error: "Gagal buat folder" };

    const dateStr = new Date().toISOString().slice(0, 10);
    const filename = `uangku-backup-${dateStr}.json`;
    const content = JSON.stringify(data, null, 2);

    // [v9.0 fix] T-2.6: pakai searchFile dengan filter parents supaya tidak overwrite file di folder lain.
    const existing = await searchFile(filename, folderId, tokenInfo.access_token);
    const existingFileId = existing?.id;

    // Buat multipart upload
    const metadata = {
      name: filename,
      mimeType: "application/json",
      ...(existingFileId ? {} : { parents: [folderId] }),
    };
    const boundary = "uangku-pro-" + Date.now();
    const body =
      `--${boundary}\r\n` +
      "Content-Type: application/json; charset=UTF-8\r\n\r\n" +
      JSON.stringify(metadata) +
      `\r\n--${boundary}\r\n` +
      "Content-Type: application/json\r\n\r\n" +
      content +
      `\r\n--${boundary}--`;

    const url = existingFileId
      ? `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=multipart`
      : "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";

    const res = await fetch(url, {
      method: existingFileId ? "PATCH" : "POST",
      headers: {
        Authorization: `Bearer ${tokenInfo.access_token}`,
        "Content-Type": `multipart/related; boundary=${boundary}`,
      },
      body,
    });
    if (!res.ok) return { success: false, error: `Upload gagal: ${res.status}` };
    const result = await res.json();
    return { success: true, fileId: result.id };
  } catch (e: any) {
    return { success: false, error: e?.message ?? "Network error" };
  }
}

// Logout (clear token)
// @deprecated v8.x — hanya bersihkan token; v9.1 akan integrasi dengan revoke endpoint Google.
export function logoutGDrive() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(TOKEN_EXPIRY_KEY);
}
