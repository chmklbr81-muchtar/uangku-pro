// Multi-Currency helpers v2.1 — static rates + 24h live-rate cache
//
// Strategy:
//   1. DEFAULT_RATES (hardcoded) sebagai fallback awal
//   2. fetchLiveRates() ambil dari https://open.er-api.com/v6/latest/IDR (gratis, no API key)
//      hasil di-cache di localStorage 24 jam (key: uangku.rates.cache)
//   3. User override per-wallet tetap prioritas tertinggi (wallet.exchangeRate)
//
// Cache structure: { fetchedAt: ISO, base: "IDR", rates: { USD: 15800, ... } }

import type { CurrencyCode, Wallet } from "./types";

export const DEFAULT_RATES: Record<CurrencyCode, number> = {
  IDR: 1,        // base
  USD: 15800,
  SGD: 11800,
  EUR: 17000,
  JPY: 105,
  GBP: 20000,
};

export const CURRENCY_SYMBOLS: Record<CurrencyCode, string> = {
  IDR: "Rp",
  USD: "$",
  SGD: "S$",
  EUR: "€",
  JPY: "¥",
  GBP: "£",
};

export const CURRENCY_NAMES: Record<CurrencyCode, string> = {
  // @deprecated v8.x — tidak dipakai di UI v9.0 (cukup CURRENCY_SYMBOLS untuk display); akan dihapus di v9.1.
  IDR: "Rupiah Indonesia",
  USD: "US Dollar",
  SGD: "Singapore Dollar",
  EUR: "Euro",
  JPY: "Japanese Yen",
  GBP: "British Pound",
};

const RATE_CACHE_KEY = "uangku.rates.cache.v2";
const RATE_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

interface RateCache {
  fetchedAt: string; // ISO
  base: string;
  rates: Partial<Record<CurrencyCode, number>>;
}

// Convert any currency to IDR using stored rate (live > default)
export function convertToIDR(
  amount: number,
  currency: CurrencyCode,
  customRate?: number
): number {
  const rate = customRate ?? getEffectiveRate(currency);
  return Math.round(amount * rate);
}

// Get effective rate: custom > live cache > default
export function getEffectiveRate(currency: CurrencyCode): number {
  if (currency === "IDR") return 1;
  const cached = getLiveRate(currency);
  return cached ?? DEFAULT_RATES[currency] ?? 1;
}

// Read live rate from cache (no network)
export function getLiveRate(currency: CurrencyCode): number | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(RATE_CACHE_KEY);
    if (!raw) return null;
    const cache = JSON.parse(raw) as RateCache;
    const fetchedAt = new Date(cache.fetchedAt).getTime();
    if (Date.now() - fetchedAt > RATE_CACHE_TTL_MS) return null;
    const rate = cache.rates[currency];
    return typeof rate === "number" && rate > 0 ? rate : null;
  } catch {
    return null;
  }
}

export function getRateCacheInfo(): { fetchedAt: string | null; isStale: boolean } {
  // @deprecated v8.x — UI v9.0 sudah tidak menampilkan indikator "cache stale"; akan dihapus di v9.1.
  if (typeof window === "undefined") return { fetchedAt: null, isStale: true };
  try {
    const raw = localStorage.getItem(RATE_CACHE_KEY);
    if (!raw) return { fetchedAt: null, isStale: true };
    const cache = JSON.parse(raw) as RateCache;
    const fetchedAt = new Date(cache.fetchedAt).getTime();
    return {
      fetchedAt: cache.fetchedAt,
      isStale: Date.now() - fetchedAt > RATE_CACHE_TTL_MS,
    };
  } catch {
    return { fetchedAt: null, isStale: true };
  }
}

// Fetch live rates from open.er-api.com (free, no API key, no rate limit).
// Returns rates for all supported non-IDR currencies (USD, SGD, EUR, JPY, GBP).
// On error, returns null (caller falls back to DEFAULT_RATES).
export async function fetchLiveRates(): Promise<Partial<Record<CurrencyCode, number>> | null> {
  try {
    // open.er-api.com returns rates with base = IDR; we want how much 1 USD = X IDR etc.
    // The API returns: { rates: { USD: 0.0000633, ... } } which is 1 IDR = X USD
    // To get 1 USD = X IDR we need 1/rates.USD
    const res = await fetch("https://open.er-api.com/v6/latest/IDR", {
      method: "GET",
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (!data || !data.rates) return null;
    const rates = data.rates as Record<string, number>;
    const result: Partial<Record<CurrencyCode, number>> = {};
    (["USD", "SGD", "EUR", "JPY", "GBP"] as CurrencyCode[]).forEach((cur) => {
      const v = rates[cur];
      if (typeof v === "number" && v > 0) {
        // 1 IDR = v USD, so 1 USD = 1/v IDR
        result[cur] = Math.round(1 / v);
      }
    });
    // Save cache
    const cache: RateCache = {
      fetchedAt: new Date().toISOString(),
      base: "IDR",
      rates: result,
    };
    if (typeof window !== "undefined") {
      localStorage.setItem(RATE_CACHE_KEY, JSON.stringify(cache));
    }
    return result;
  } catch {
    return null;
  }
}

// Format amount with proper currency symbol
export function formatCurrencyWithCode(
  amount: number,
  currency: CurrencyCode = "IDR"
): string {
  if (currency === "IDR") {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  }
  if (currency === "JPY") {
    return `${CURRENCY_SYMBOLS.JPY}${Math.round(amount).toLocaleString("en-US")}`;
  }
  if (currency === "USD" || currency === "SGD" || currency === "EUR" || currency === "GBP") {
    return `${CURRENCY_SYMBOLS[currency]}${amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  return `${CURRENCY_SYMBOLS[currency]}${amount.toLocaleString("en-US")}`;
}

// Total balance across all wallets, converted to IDR
export function getTotalBalanceIDR(
  wallets: Wallet[],
  transactions: any[]
): number {
  let total = 0;
  for (const w of wallets.filter((w) => !w.archived)) {
    let bal = w.initialBalance;
    for (const t of transactions) {
      if (t.walletId === w.id) {
        if (t.type === "income") bal += t.amount;
        else if (t.type === "expense") bal -= t.amount;
        else if (t.type === "transfer") bal -= t.amount;
      } else if (t.type === "transfer" && t.transferToWalletId === w.id) {
        bal += t.amount;
      }
    }
    const currency = w.currency ?? "IDR";
    total += convertToIDR(bal, currency, w.exchangeRate);
  }
  return total;
}

// Update exchange rate (user manual input)
// @deprecated v8.x — di v9.0 user input rate langsung di WalletManager; helper ini tidak dipakai lagi.
export function updateWalletRate(
  walletId: string,
  rate: number,
  wallets: Wallet[]
): Wallet[] {
  return wallets.map((w) =>
    w.id === walletId ? { ...w, exchangeRate: rate } : w
  );
}
