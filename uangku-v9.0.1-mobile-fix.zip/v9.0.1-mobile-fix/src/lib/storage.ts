// Storage v2.1 — Capacitor Preferences (native) dengan localStorage fallback
//
// v8.0: 100% localStorage
// v8.1: prefer @capacitor/preferences bila tersedia (lebih stabil di WebView, tidak ke-clear saat cache flush),
//       fallback ke localStorage untuk dev/PWA biasa.
//
// API tetap sync (loadData/saveData) supaya callers tidak perlu berubah.
// Capacitor Preferences sendiri async, jadi kita cache nilai di in-memory map
// dan menulis secara fire-and-forget di saveData.

import type { AppData, Transaction } from "./types";
import { createInitialData } from "./default-data";

const STORAGE_KEY = "uangku-pro.data.v4";
const SCHEMA_VERSION = 4;
const OLD_KEY = "uangku.transactions.v1";

// === Capacitor Preferences loader (lazy, supaya tidak crash di SSR) ===
type PreferencesAPI = {
  get: (opts: { key: string }) => Promise<{ value: string | null }>;
  set: (opts: { key: string; value: string }) => Promise<void>;
  remove: (opts: { key: string }) => Promise<void>;
};

// [v9.0 fix] Typed shape of the @capacitor/preferences module export
type CapacitorPreferencesModule = {
  Preferences?: PreferencesAPI;
  default?: { Preferences?: PreferencesAPI };
};

let _capPref: PreferencesAPI | null = null;
let _capPrefChecked = false;

async function getCapacitorPreferences(): Promise<PreferencesAPI | null> {
  if (_capPrefChecked) return _capPref;
  _capPrefChecked = true;
  try {
    if (typeof window === "undefined") return null;
    // Dynamic import — fails gracefully if package not bundled (web-only PWA)
    const mod = (await import("@capacitor/preferences")) as CapacitorPreferencesModule;
    _capPref = mod.Preferences ?? mod.default?.Preferences ?? null;
    return _capPref;
  } catch {
    return null;
  }
}

// Cache in-memory supaya load sync setelah init
let _memoryCache: string | null = null;
let _initialized = false;

// [v9.0 fix] C-1: Race condition Capacitor Preferences overwrite
// Cegah race condition: jangan tulis sebelum initStorage selesai baca.
// _initPromise diset saat init dimulai; saveData() akan menunggu ini bila belum ready.
let _storageReady = false;
let _initPromise: Promise<void> | null = null;

async function initStorage(): Promise<void> {
  // [v9.0 fix] C-1: dedupe concurrent init calls via _initPromise
  if (_initialized) return _initPromise ?? Promise.resolve();
  _initialized = true;
  _initPromise = (async () => {
    const cap = await getCapacitorPreferences();
    if (cap) {
      try {
        const { value } = await cap.get({ key: STORAGE_KEY });
        _memoryCache = value;
        // Migrasi dari localStorage lama jika Capacitor kosong tapi localStorage ada data
        if (!_memoryCache && typeof window !== "undefined") {
          const ls = window.localStorage.getItem(STORAGE_KEY);
          if (ls) {
            _memoryCache = ls;
            await cap.set({ key: STORAGE_KEY, value: ls });
            window.localStorage.removeItem(STORAGE_KEY); // pindah, buang dari ls
          }
        }
        // [v9.0 fix] C-1: tandai storage siap dibaca — saveData() boleh persist sekarang.
        _storageReady = true;
        return;
      } catch {
        // fall through to localStorage
      }
    }
    if (typeof window !== "undefined") {
      _memoryCache = window.localStorage.getItem(STORAGE_KEY);
    }
    // [v9.0 fix] C-1: localStorage fallback juga dianggap ready (sync read sudah selesai).
    _storageReady = true;
  })();
  return _initPromise;
}

async function persistStorage(value: string): Promise<void> {
  _memoryCache = value;
  const cap = await getCapacitorPreferences();
  if (cap) {
    try {
      await cap.set({ key: STORAGE_KEY, value });
      return;
    } catch {
      // fall through to localStorage
    }
  }
  if (typeof window !== "undefined") {
    window.localStorage.setItem(STORAGE_KEY, value);
  }
}

async function clearStorage(): Promise<void> {
  _memoryCache = null;
  const cap = await getCapacitorPreferences();
  if (cap) {
    try {
      await cap.remove({ key: STORAGE_KEY });
      await cap.remove({ key: "uangku-pro.data.v2" });
      return;
    } catch {
      // fall through
    }
  }
  if (typeof window !== "undefined") {
    window.localStorage.removeItem(STORAGE_KEY);
    window.localStorage.removeItem("uangku-pro.data.v2");
  }
}

// === Migration helpers (unchanged logic) ===
function migrateFromV1(): AppData | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(OLD_KEY);
    if (!raw) return null;
    const oldTxs = JSON.parse(raw) as Array<{
      id: string;
      type: "income" | "expense";
      amount: number;
      category: string;
      date: string;
      note?: string;
      createdAt: string;
    }>;
    if (!Array.isArray(oldTxs) || oldTxs.length === 0) return null;

    const data = createInitialData();
    const catMap: Record<string, string> = {
      gaji: "coa-5-1100",
      bonus: "coa-5-1200",
      hadiah: "coa-6-1000",
      investasi: "coa-5-1300",
      penjualan: "coa-5-1001",
      "lainnya-in": "coa-6-1200",
      makanan: "coa-8-1001",
      transportasi: "coa-8-1100",
      belanja: "coa-8-1200",
      tagihan: "coa-8-1300",
      hiburan: "coa-8-1400",
      kesehatan: "coa-8-1500",
      pendidikan: "coa-8-1600",
      "lainnya-out": "coa-8-9000",
    };
    const cashWallet = data.wallets.find((w) => w.type === "cash");
    if (!cashWallet) return null;

    const newTxs: Transaction[] = oldTxs.map((t) => {
      const coaId = catMap[t.category] ?? "coa-8-9000";
      const coa = data.coa.find((c) => c.id === coaId);
      return {
        id: t.id,
        type: t.type,
        amount: t.amount,
        date: t.date,
        walletId: cashWallet.id,
        coaId,
        category: coa?.name ?? t.category,
        note: t.note,
        createdAt: t.createdAt,
      };
    });
    data.transactions = newTxs;
    return data;
  } catch {
    return null;
  }
}

function migrateFromV3(): AppData | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("uangku-pro.data.v3");
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AppData;
    if (!parsed || typeof parsed !== "object") return null;
    const initial = createInitialData();
    return {
      ...initial,
      ...parsed,
      activityLogs: parsed.activityLogs ?? [],
      settings: {
        ...initial.settings,
        ...parsed.settings,
      },
      schemaVersion: SCHEMA_VERSION,
    };
  } catch {
    return null;
  }
}

function migrateFromV2(): AppData | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem("uangku-pro.data.v2");
    if (!raw) return null;
    const parsed = JSON.parse(raw) as AppData;
    if (!parsed || typeof parsed !== "object") return null;
    const initial = createInitialData();
    return {
      ...initial,
      ...parsed,
      debts: parsed.debts ?? [],
      settings: {
        ...initial.settings,
        ...parsed.settings,
      },
      schemaVersion: SCHEMA_VERSION,
    };
  } catch {
    return null;
  }
}

function parseRaw(raw: string | null): AppData | null {
  if (!raw) return null;
  // [v9.0 fix] C-2: validate arrays after JSON.parse — wrap seluruh proses dalam try/catch.
  // Bila struktur rusak / field array hilang, fallback ke createInitialData() + log warning.
  try {
    const parsed = JSON.parse(raw) as Partial<AppData> & Record<string, unknown>;
    if (!parsed || typeof parsed !== "object") {
      console.warn("[v9.0 fix] parseRaw: payload bukan object, fallback ke initial data");
      return createInitialData();
    }
    // `categories` tidak ada di AppData v4, tapi tetap kita cek defensively bila ada di payload lama.
    const arraysValid =
      Array.isArray(parsed.transactions) &&
      Array.isArray(parsed.wallets) &&
      Array.isArray(parsed.coa) &&
      Array.isArray(parsed.categories ?? []) &&
      Array.isArray(parsed.budgets) &&
      Array.isArray(parsed.savingsGoals) &&
      Array.isArray(parsed.debts) &&
      Array.isArray(parsed.activityLogs);
    if (!arraysValid) {
      console.warn("[v9.0 fix] parseRaw: salah satu array inti tidak valid, fallback ke initial data");
      return createInitialData();
    }
    return {
      ...createInitialData(),
      ...parsed,
      schemaVersion: SCHEMA_VERSION,
    } as AppData;
  } catch (e) {
    console.warn("[v9.0 fix] parseRaw: JSON.parse gagal, fallback ke initial data", e);
    return createInitialData();
  }
}

// === Public sync API ===
// Catatan: pada pertama kali dipanggil, initStorage() belum selesai (async).
// Karena itu loadData() akan return initial data jika cache belum siap,
// lalu trigger init async yang akan dispatch event "uangku-storage-ready".
export function loadData(): AppData {
  if (typeof window === "undefined") return createInitialData();
  // Trigger async init (fire-and-forget)
  if (!_initialized) {
    initStorage().then(() => {
      // Beri tahu UI untuk reload setelah cache siap
      window.dispatchEvent(new CustomEvent("uangku-storage-ready"));
    });
  }
  // Coba cache dulu
  if (_memoryCache) {
    return parseRaw(_memoryCache) ?? createInitialData();
  }
  // Coba localStorage langsung (fallback saat Capacitor belum siap)
  const ls = typeof window !== "undefined" ? window.localStorage.getItem(STORAGE_KEY) : null;
  if (ls) {
    _memoryCache = ls;
    return parseRaw(ls) ?? createInitialData();
  }
  // Coba migrasi dari versi lama
  const migratedV3 = migrateFromV3();
  if (migratedV3) {
    saveData(migratedV3);
    return migratedV3;
  }
  const migratedV2 = migrateFromV2();
  if (migratedV2) {
    saveData(migratedV2);
    return migratedV2;
  }
  const migrated = migrateFromV1();
  if (migrated) {
    saveData(migrated);
    return migrated;
  }
  return createInitialData();
}

export function saveData(data: AppData): void {
  if (typeof window === "undefined") return;
  try {
    const json = JSON.stringify(data);
    _memoryCache = json;
    // [v9.0 fix] C-1: Cegah race condition: jangan tulis sebelum initStorage selesai baca.
    // Bila storage belum ready, tunggu _initPromise dulu baru persist. Memory cache tetap
    // di-update synchronously supaya loadData() berikutnya langsung dapat nilai terbaru.
    const persist = () => {
      persistStorage(json).catch((e) => console.error("Gagal menyimpan data", e));
    };
    if (!_storageReady && _initPromise) {
      _initPromise.then(persist).catch((e) => console.error("Gagal menyimpan data", e));
    } else {
      persist();
    }
    // Juga simpan ke localStorage sebagai backup sync (cepat)
    // Hanya jika Capacitor tidak tersedia (persistStorage sudah handle ini).
  } catch (e) {
    console.error("Gagal menyimpan data", e);
  }
}

export function resetData(): void {
  if (typeof window === "undefined") return;
  // [v9.0 fix] C-3: clear ALL uangku.* localStorage keys + Capacitor Preferences
  clearAllStorage();
  clearStorage().catch(() => {});
}

// [v9.0 fix] C-3: helper yang iterasi semua localStorage key berawalan "uangku."
// dan remove masing-masing. Dipakai resetData() supaya tidak ada PIN hash / session /
// cache rate / learning stats yang tertinggal setelah reset (data leakage / stale state).
export function clearAllStorage(): void {
  if (typeof window === "undefined") return;
  try {
    const keys = Object.keys(window.localStorage).filter((k) => k.startsWith("uangku."));
    for (const k of keys) {
      window.localStorage.removeItem(k);
    }
  } catch (e) {
    console.warn("[v9.0 fix] clearAllStorage: gagan iterate/remove localStorage", e);
  }
}

// Export semua data sebagai JSON backup
export function exportBackup(data: AppData): string {
  return JSON.stringify(data, null, 2);
}

// Import data dari JSON backup
export function importBackup(jsonString: string): AppData | null {
  try {
    const parsed = JSON.parse(jsonString) as AppData;
    if (!parsed || typeof parsed !== "object") return null;
    if (!Array.isArray(parsed.transactions)) return null;
    return {
      ...createInitialData(),
      ...parsed,
      schemaVersion: SCHEMA_VERSION,
    };
  } catch {
    return null;
  }
}
