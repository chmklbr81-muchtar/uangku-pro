// Modul sync Supabase v2.1 — granular per-field conflict resolution + soft-delete + LWW timestamps
//
// v8.0 strategi: "cloud wins" untuk seluruh AppData (single-user 2-device)
// v8.1 strategi: per-collection merge dengan:
//   - Per-item lastWriteWins berdasarkan `updatedAt` timestamp per item
//   - Soft-delete: item dengan `deletedAt` tidak muncul di UI, tapi tetap di-sync untuk propagate deletion
//   - Per-field merge untuk Settings (timestamped)
//   - Schema SQL baru: 2 tabel — `user_data_meta` (settings) + `user_data_items` (per-item collections)
//
// v9.0 fixes:
//   - T-1.3: getStoredSession() jadi async + auto-refresh access_token kalau expires < 5 menit
//   - T-1.7: supabaseDeleteAccount() panggil /auth/v1/logout untuk invalidate session sebelum clearSession
//   - T-4.1/T-4.2: fetchWithRetry() dengan exponential backoff; offline queue di localStorage
//
// Backward-compat: tetap support legacy table `user_data` (single jsonb row) untuk user lama.
// Strategi: coba dulu granular; jika tabel belum ada (404/error), fallback ke legacy push/pull.

import type {
  AppData,
  Transaction,
  Wallet,
  COAAccount,
  Budget,
  SavingsGoal,
  RecurringTransaction,
  DebtLoan,
} from "./types";

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

export interface SupabaseSession {
  access_token: string;
  refresh_token?: string;
  expires_at?: number;
  user?: {
    id: string;
    email: string;
  };
}

export interface SyncResult {
  success: boolean;
  error?: string;
  pulledData?: Partial<AppData>;
  pushedAt?: string;
  conflictsResolved?: number;
  pulledItems?: number;
  pushedItems?: number;
}

const SESSION_KEY = "uangku.supabase.session";
// [v9.0 fix] T-1.3: simpan konfigurasi (url+anonKey) bersamaan dengan session
// supaya refreshSession() bisa POST ke /auth/v1/token?grant_type=refresh_token tanpa param config.
const SESSION_CONFIG_KEY = "uangku.supabase.sessionConfig";
// [v9.0 fix] T-4.2: offline queue untuk operasi sync yang gagal karena network error
const SYNC_QUEUE_KEY = "uangku.sync.queue";
const SYNC_QUEUE_MAX = 100; // batasi untuk hindari localStorage overflow

interface QueuedSyncOp {
  id: string;
  enqueuedAt: string;
  config: SupabaseConfig;
  data: AppData;
}

// [v9.0 fix] T-4.1/T-4.2: fetch dengan retry exponential backoff (1s, 2s, 4s) untuk network flakiness.
async function fetchWithRetry(
  url: string,
  options: RequestInit,
  retries = 3
): Promise<Response> {
  let lastErr: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, options);
      // Retry hanya untuk network-level / 5xx / 429. 4xx (selain 429) langsung return — client error tidak akan sembuh dengan retry.
      if (res.status >= 500 || res.status === 429) {
        if (attempt < retries) {
          const backoffMs = Math.pow(2, attempt) * 1000; // 1s, 2s, 4s
          await new Promise((r) => setTimeout(r, backoffMs));
          continue;
        }
      }
      return res;
    } catch (e) {
      lastErr = e;
      if (attempt < retries) {
        const backoffMs = Math.pow(2, attempt) * 1000;
        await new Promise((r) => setTimeout(r, backoffMs));
        continue;
      }
    }
  }
  throw lastErr ?? new Error("fetchWithRetry exhausted");
}

// [v9.0 fix] T-4.2: queue operasi sync gagal ke localStorage, diproses saat app launch / online.
function enqueueSyncOp(op: QueuedSyncOp) {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(SYNC_QUEUE_KEY);
    const queue: QueuedSyncOp[] = raw ? (JSON.parse(raw) as QueuedSyncOp[]) : [];
    queue.push(op);
    // Trim oldest entries if over limit
    const trimmed = queue.length > SYNC_QUEUE_MAX ? queue.slice(queue.length - SYNC_QUEUE_MAX) : queue;
    localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(trimmed));
  } catch {
    // localStorage penuh / corrupted — silently ignore, data lokal tetap aman di saveData().
  }
}

// [v9.0 fix] T-4.2: proses seluruh queue (dipanggil dari page.tsx saat app launch / online event).
export async function processSyncQueue(): Promise<{ processed: number; succeeded: number }> {
  if (typeof window === "undefined") return { processed: 0, succeeded: 0 };
  let raw: string | null;
  try {
    raw = localStorage.getItem(SYNC_QUEUE_KEY);
  } catch {
    return { processed: 0, succeeded: 0 };
  }
  if (!raw) return { processed: 0, succeeded: 0 };
  let queue: QueuedSyncOp[];
  try {
    queue = JSON.parse(raw) as QueuedSyncOp[];
  } catch {
    localStorage.removeItem(SYNC_QUEUE_KEY);
    return { processed: 0, succeeded: 0 };
  }
  if (!Array.isArray(queue) || queue.length === 0) return { processed: 0, succeeded: 0 };

  let succeeded = 0;
  const remaining: QueuedSyncOp[] = [];
  for (const op of queue) {
    try {
      const result = await supabaseSmartSync(op.config, op.data);
      if (result.success) {
        succeeded++;
      } else {
        // Masih gagal — keep in queue untuk retry next launch
        remaining.push(op);
      }
    } catch {
      remaining.push(op);
    }
  }
  // Tulis ulang queue dengan item yang masih gagal (atau hapus kalau kosong)
  try {
    if (remaining.length === 0) {
      localStorage.removeItem(SYNC_QUEUE_KEY);
    } else {
      localStorage.setItem(SYNC_QUEUE_KEY, JSON.stringify(remaining));
    }
  } catch {
    // ignore
  }
  return { processed: queue.length, succeeded };
}

// === Session management ===
// [v9.0 fix] T-1.3: dibuat async — sebelum return, cek apakah access_token expires dalam 5 menit;
// jika ya, panggil refreshSession() supaya token selalu valid saat dipakai oleh fetch sync.
export async function getStoredSession(): Promise<SupabaseSession | null> {
  if (typeof window === "undefined") return null;
  let session: SupabaseSession;
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    session = JSON.parse(raw) as SupabaseSession;
  } catch {
    return null;
  }
  // Sudah kedaluwarsa absolut → hapus & return null
  if (session.expires_at && Date.now() > session.expires_at * 1000) {
    // Coba refresh dulu kalau ada refresh_token; kalau gagal baru remove.
    const refreshed = await refreshSession(session).catch(() => null);
    if (refreshed) return refreshed;
    localStorage.removeItem(SESSION_KEY);
    return null;
  }
  // [v9.0 fix] T-1.3: akan kedaluwarsa dalam < 5 menit → proaktif refresh supaya sync tidak gagal diam-diam
  if (
    session.expires_at &&
    session.expires_at * 1000 - Date.now() < 5 * 60 * 1000
  ) {
    const refreshed = await refreshSession(session).catch(() => null);
    if (refreshed) return refreshed;
    // Refresh gagal — return session lama (masih valid sebentar), caller akan handle kalau 401.
  }
  return session;
}

// [v9.0 fix] T-1.3: refresh access_token via refresh_token grant.
// Baca config (url+anonKey) dari localStorage key SESSION_CONFIG_KEY yang diset saat saveSession().
// Return session baru jika sukses (sekaligus persist); null jika gagal (mis. refresh_token invalid).
export async function refreshSession(
  currentSession: SupabaseSession
): Promise<SupabaseSession | null> {
  if (typeof window === "undefined") return null;
  if (!currentSession.refresh_token) return null;
  let config: SupabaseConfig | null = null;
  try {
    const cfgRaw = localStorage.getItem(SESSION_CONFIG_KEY);
    if (cfgRaw) config = JSON.parse(cfgRaw) as SupabaseConfig;
  } catch {
    // ignore
  }
  if (!config || !config.url || !config.anonKey) return null;

  try {
    const res = await fetchWithRetry(
      `${config.url}/auth/v1/token?grant_type=refresh_token`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: config.anonKey,
        },
        body: JSON.stringify({ refresh_token: currentSession.refresh_token }),
      },
      2 // retry sekali untuk flaky network
    );
    if (!res.ok) return null;
    const data = await res.json();
    if (!data?.access_token) return null;
    const newSession: SupabaseSession = {
      access_token: data.access_token,
      refresh_token: data.refresh_token ?? currentSession.refresh_token,
      expires_at: data.expires_at,
      user: currentSession.user, // preserve user identity
    };
    saveSession(newSession, config);
    return newSession;
  } catch {
    return null;
  }
}

// [v9.0 fix] T-1.3: saveSession menerima config opsional supaya bisa dipakai refreshSession() nanti.
export function saveSession(session: SupabaseSession, config?: SupabaseConfig) {
  if (typeof window === "undefined") return;
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  if (config) {
    localStorage.setItem(SESSION_CONFIG_KEY, JSON.stringify(config));
  }
}

export function clearSession() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(SESSION_KEY);
  // [v9.0 fix] T-1.3: bersihkan juga config yang tersimpan bersama session
  localStorage.removeItem(SESSION_CONFIG_KEY);
}

// === Sign up user baru (email + password) ===
export async function supabaseSignUp(
  config: SupabaseConfig,
  email: string,
  password: string
): Promise<{ session?: SupabaseSession; error?: string }> {
  try {
    const res = await fetch(`${config.url}/auth/v1/signup`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: config.anonKey,
      },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      return { error: data?.error?.message ?? data?.msg ?? "Sign up gagal" };
    }
    if (data.session) {
      const session: SupabaseSession = {
        access_token: data.session.access_token,
        refresh_token: data.session.refresh_token,
        expires_at: data.session.expires_at,
        user: data.user ? { id: data.user.id, email: data.user.email } : undefined,
      };
      // [v9.0 fix] T-1.3: simpan config bersamaan supaya refreshSession() bisa baca url+anonKey
      saveSession(session, config);
      return { session };
    }
    return {
      error:
        "Akun dibuat. Cek email Anda untuk konfirmasi, lalu login kembali.",
    };
  } catch (e: any) {
    return { error: e?.message ?? "Network error" };
  }
}

// === Sign in (login) ===
export async function supabaseSignIn(
  config: SupabaseConfig,
  email: string,
  password: string
): Promise<{ session?: SupabaseSession; error?: string }> {
  try {
    const res = await fetch(`${config.url}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: config.anonKey,
      },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      return { error: data?.error?.message ?? "Login gagal" };
    }
    const session: SupabaseSession = {
      access_token: data.access_token,
      refresh_token: data.refresh_token,
      expires_at: data.expires_at,
      user: data.user ? { id: data.user.id, email: data.user.email } : undefined,
    };
    // [v9.0 fix] T-1.3: simpan config bersamaan supaya refreshSession() bisa baca url+anonKey
    saveSession(session, config);
    return { session };
  } catch (e: any) {
    return { error: e?.message ?? "Network error" };
  }
}

// === Sign out ===
export async function supabaseSignOut(config: SupabaseConfig) {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async (auto-refresh)
  const session = await getStoredSession();
  if (session) {
    try {
      // [v9.0 fix] T-4.1: fetchWithRetry supaya logout tidak gagal karena blip network
      await fetchWithRetry(
        `${config.url}/auth/v1/logout`,
        {
          method: "POST",
          headers: {
            apikey: config.anonKey,
            Authorization: `Bearer ${session.access_token}`,
          },
        },
        2
      );
    } catch {
      // ignore error — logout server-side best-effort; local session tetap di-clear
    }
  }
  clearSession();
}

// === Hapus akun & data dari Supabase ===
// [v9.0 fix] T-1.7: setelah hapus row data, panggil /auth/v1/logout untuk invalidate access_token.
// TODO (server-side): penghapusan auth user di auth.users Supabase memerlukan service_role key
// (lihat README) — TIDAK bisa dilakukan dari client dengan anon key. Harus pakai Edge Function
// atau admin API server-side. Sampai itu tersedia, email user tetap terdaftar di auth.users Supabase.
export async function supabaseDeleteAccount(
  config: SupabaseConfig
): Promise<{ success: boolean; error?: string }> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) {
    return { success: false, error: "Belum login" };
  }
  try {
    // Step 1: Hapus row user_data di Supabase (legacy)
    // [v9.0 fix] T-4.1: pakai fetchWithRetry untuk tahan terhadap network blip
    const res1 = await fetchWithRetry(
      `${config.url}/rest/v1/user_data?id=eq.${session.user.id}`,
      {
        method: "DELETE",
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${session.access_token}`,
        },
      },
      2
    );
    if (!res1.ok) {
      return { success: false, error: `Gagal hapus data: ${res1.status}` };
    }
    // Step 2 (granular): hapus semua item user_data_items
    await fetchWithRetry(
      `${config.url}/rest/v1/user_data_items?user_id=eq.${session.user.id}`,
      {
        method: "DELETE",
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${session.access_token}`,
        },
      },
      2
    );
    await fetchWithRetry(
      `${config.url}/rest/v1/user_data_meta?id=eq.${session.user.id}`,
      {
        method: "DELETE",
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${session.access_token}`,
        },
      },
      2
    );
    // [v9.0 fix] T-1.7: panggil /auth/v1/logout untuk invalidate session (access_token) sebelum clearSession.
    // Supabase akan memblacklist access_token + revoke refresh_token di server.
    try {
      await fetchWithRetry(
        `${config.url}/auth/v1/logout`,
        {
          method: "POST",
          headers: {
            apikey: config.anonKey,
            Authorization: `Bearer ${session.access_token}`,
          },
        },
        2
      );
    } catch {
      // Best-effort: kalau logout gagal, local session tetap di-clear di supabaseSignOut().
    }
    await supabaseSignOut(config);
    return { success: true };
  } catch (e: any) {
    return { success: false, error: e?.message ?? "Network error" };
  }
}

// === Test connection ===
// @deprecated v8.x — hanya dipakai di UI Settings lama; untuk v9.0+ lebih baik pakai
// supabaseSmartSync yang sekaligus test koneksi + merge data.
export async function supabaseTestConnection(
  config: SupabaseConfig
): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetchWithRetry(`${config.url}/auth/v1/settings`, {
      method: "GET",
      headers: { apikey: config.anonKey },
    }, 2);
    if (!res.ok) return { ok: false, error: `Status ${res.status}` };
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "Network error" };
  }
}

// === Collection names ===
// Each collection = a JSON array stored as a row in `user_data_items`.
// Row shape: { user_id, collection, items, updated_at, deleted_at? }
const COLLECTIONS = [
  "transactions",
  "wallets",
  "coa",
  "budgets",
  "savingsGoals",
  "recurring",
  "debts",
] as const;
type CollectionName = (typeof COLLECTIONS)[number];

// [v9.0 fix] M-x: typed map CollectionName → domain array type.
// Sebelumnya call-site pakai `as any` untuk coerce. Sekarang compiler tahu
// bahwa `transactions` adalah Transaction[], dst. Field `notifications` &
// `activityLogs` sengaja tidak di-sync (local-only).
type CollectionArrayOfType = {
  transactions: Transaction[];
  wallets: Wallet[];
  coa: COAAccount[];
  budgets: Budget[];
  savingsGoals: SavingsGoal[];
  recurring: RecurringTransaction[];
  debts: DebtLoan[];
};
// Minimum contract yang dipakai mergeCollection (LWW) — semua domain type
// kita punya `id: string`, jadi aman.
type Syncable = { id: string };

function authHeaders(config: SupabaseConfig, session: SupabaseSession) {
  return {
    apikey: config.anonKey,
    Authorization: `Bearer ${session.access_token}`,
    "Content-Type": "application/json",
  };
}

// === LEGACY: Push semua data ke single row `user_data` (v8.0 schema) ===
// Dipakai sebagai fallback bila tabel granular belum dibuat user.
// @deprecated v8.x — akan dihapus di v9.1; auto-push v9.0 sudah pakai supabaseSmartSync.
export async function supabasePushData(
  config: SupabaseConfig,
  data: AppData
): Promise<SyncResult> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) {
    return { success: false, error: "Belum login" };
  }
  try {
    const payload = {
      transactions: data.transactions,
      wallets: data.wallets,
      coa: data.coa,
      budgets: data.budgets,
      savingsGoals: data.savingsGoals,
      recurring: data.recurring,
      debts: data.debts,
      settings: data.settings,
    };

    // [v9.0 fix] T-4.1: fetchWithRetry
    const res = await fetchWithRetry(
      `${config.url}/rest/v1/user_data?id=eq.${session.user.id}`,
      {
        method: "PUT",
        headers: {
          ...authHeaders(config, session),
          Prefer: "return=minimal,resolution=merge-duplicates",
        },
        body: JSON.stringify({
          id: session.user.id,
          user_id: session.user.id,
          data: payload,
          updated_at: new Date().toISOString(),
        }),
      },
      3
    );
    if (!res.ok) {
      const errText = await res.text();
      return { success: false, error: `Push gagal (${res.status}): ${errText.slice(0, 200)}` };
    }
    return { success: true, pushedAt: new Date().toISOString() };
  } catch (e: any) {
    return { success: false, error: e?.message ?? "Network error" };
  }
}

// === LEGACY: Pull single row ===
// @deprecated v8.x — dipakai hanya sebagai fallback oleh supabaseSmartSyncLegacy.
export async function supabasePullData(
  config: SupabaseConfig
): Promise<SyncResult> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) {
    return { success: false, error: "Belum login" };
  }
  try {
    // [v9.0 fix] T-4.1: fetchWithRetry
    const res = await fetchWithRetry(
      `${config.url}/rest/v1/user_data?id=eq.${session.user.id}&select=data,updated_at`,
      {
        method: "GET",
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${session.access_token}`,
        },
      },
      3
    );
    if (!res.ok) {
      return { success: false, error: `Pull gagal: ${res.status}` };
    }
    const rows = await res.json();
    if (!Array.isArray(rows) || rows.length === 0) {
      return { success: true, pulledData: {} };
    }
    return { success: true, pulledData: rows[0].data as Partial<AppData> };
  } catch (e: any) {
    return { success: false, error: e?.message ?? "Network error" };
  }
}

// === GRANULAR: Push satu collection ===
async function supabasePushCollection(
  config: SupabaseConfig,
  collection: CollectionName,
  items: unknown[]
): Promise<{ ok: boolean; error?: string }> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) return { ok: false, error: "Belum login" };
  try {
    // [v9.0 fix] T-4.1: fetchWithRetry
    const res = await fetchWithRetry(
      `${config.url}/rest/v1/user_data_items?user_id=eq.${session.user.id}&collection=eq.${collection}`,
      {
        method: "PUT",
        headers: {
          ...authHeaders(config, session),
          Prefer: "return=minimal,resolution=merge-duplicates",
        },
        body: JSON.stringify({
          user_id: session.user.id,
          collection,
          items,
          updated_at: new Date().toISOString(),
        }),
      },
      3
    );
    if (!res.ok) {
      const txt = await res.text();
      return { ok: false, error: `${res.status}: ${txt.slice(0, 200)}` };
    }
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "Network error" };
  }
}

// === GRANULAR: Pull satu collection ===
async function supabasePullCollection(
  config: SupabaseConfig,
  collection: CollectionName
): Promise<{ items: unknown[] | null; updatedAt?: string; error?: string }> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) return { items: null, error: "Belum login" };
  try {
    // [v9.0 fix] T-4.1: fetchWithRetry
    const res = await fetchWithRetry(
      `${config.url}/rest/v1/user_data_items?user_id=eq.${session.user.id}&collection=eq.${collection}&select=items,updated_at`,
      {
        method: "GET",
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${session.access_token}`,
        },
      },
      3
    );
    if (!res.ok) {
      return { items: null, error: `${res.status}` };
    }
    const rows = await res.json();
    if (!Array.isArray(rows) || rows.length === 0) {
      return { items: null }; // collection belum ada di cloud
    }
    return {
      items: (rows[0].items ?? []) as unknown[],
      updatedAt: rows[0].updated_at as string,
    };
  } catch (e: any) {
    return { items: null, error: e?.message ?? "Network error" };
  }
}

// === GRANULAR: Push settings (single meta row) ===
async function supabasePushSettings(
  config: SupabaseConfig,
  settings: AppData["settings"]
): Promise<{ ok: boolean; error?: string }> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) return { ok: false, error: "Belum login" };
  try {
    // [v9.0 fix] T-4.1: fetchWithRetry
    const res = await fetchWithRetry(
      `${config.url}/rest/v1/user_data_meta?id=eq.${session.user.id}`,
      {
        method: "PUT",
        headers: {
          ...authHeaders(config, session),
          Prefer: "return=minimal,resolution=merge-duplicates",
        },
        body: JSON.stringify({
          id: session.user.id,
          user_id: session.user.id,
          settings,
          updated_at: new Date().toISOString(),
        }),
      },
      3
    );
    if (!res.ok) {
      const txt = await res.text();
      return { ok: false, error: `${res.status}: ${txt.slice(0, 200)}` };
    }
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message ?? "Network error" };
  }
}

// === GRANULAR: Pull settings ===
async function supabasePullSettings(
  config: SupabaseConfig
): Promise<{ settings: AppData["settings"] | null; updatedAt?: string; error?: string }> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async
  const session = await getStoredSession();
  if (!session || !session.user) return { settings: null, error: "Belum login" };
  try {
    // [v9.0 fix] T-4.1: fetchWithRetry
    const res = await fetchWithRetry(
      `${config.url}/rest/v1/user_data_meta?id=eq.${session.user.id}&select=settings,updated_at`,
      {
        method: "GET",
        headers: {
          apikey: config.anonKey,
          Authorization: `Bearer ${session.access_token}`,
        },
      },
      3
    );
    if (!res.ok) return { settings: null, error: `${res.status}` };
    const rows = await res.json();
    if (!Array.isArray(rows) || rows.length === 0) {
      return { settings: null };
    }
    return {
      settings: rows[0].settings as AppData["settings"],
      updatedAt: rows[0].updated_at as string,
    };
  } catch (e: any) {
    return { settings: null, error: e?.message ?? "Network error" };
  }
}

// === Per-item merge (LWW) ===
// Each item should have `id` and optional `updatedAt`. If both local & cloud have the same id,
// the one with the newer `updatedAt` wins. If both have a `deletedAt` field set, item is soft-deleted.
//
// [v9.0 fix] M-x: constraint dilonggarkan ke `{ id: string }` supaya domain types
// (Wallet, COAAccount, Budget, SavingsGoal, RecurringTransaction — yang tidak punya
// `updatedAt`/`deletedAt`) bisa masuk tanpa `as any` cast di call-site. Field
// timestamp opsional diakses via helper `SyncableMeta` intersection, type-safe.
interface SyncableMeta {
  id: string;
  updatedAt?: string;
  deletedAt?: string;
}
function mergeCollection<T extends { id: string }>(
  local: T[],
  cloud: T[]
): { merged: T[]; conflictsResolved: number } {
  const map = new Map<string, T>();
  let conflicts = 0;
  // Seed with local
  for (const item of local) {
    map.set(item.id, item);
  }
  // Merge cloud
  for (const cloudItem of cloud) {
    const localItem = map.get(cloudItem.id);
    if (!localItem) {
      map.set(cloudItem.id, cloudItem);
      continue;
    }
    // Conflict: pick newer (compare optional updatedAt via SyncableMeta cast — safe karena field optional).
    const localMeta = localItem as unknown as SyncableMeta;
    const cloudMeta = cloudItem as unknown as SyncableMeta;
    const localTs = localMeta.updatedAt ? new Date(localMeta.updatedAt).getTime() : 0;
    const cloudTs = cloudMeta.updatedAt ? new Date(cloudMeta.updatedAt).getTime() : 0;
    if (cloudTs > localTs) {
      map.set(cloudItem.id, cloudItem);
    }
    conflicts++;
  }
  // Drop soft-deleted items older than 30 days (cleanup)
  const now = Date.now();
  const merged: T[] = [];
  for (const item of map.values()) {
    const meta = item as unknown as SyncableMeta;
    if (meta.deletedAt) {
      const deletedTs = new Date(meta.deletedAt).getTime();
      if (now - deletedTs > 30 * 24 * 60 * 60 * 1000) continue; // purge
    }
    merged.push(item);
  }
  return { merged, conflictsResolved: conflicts };
}

// === GRANULAR SMART SYNC ===
// Try granular sync first; if any collection returns 404 (table doesn't exist),
// fall back to legacy single-row sync.
// [v9.0 fix] T-4.2: pada network error (fetch throw), operasi di-queue ke localStorage
// supaya bisa di-retry saat app launch / online (lihat processSyncQueue di page.tsx).
export async function supabaseSmartSync(
  config: SupabaseConfig,
  localData: AppData
): Promise<{ success: boolean; mergedData?: AppData; error?: string; pushedAt?: string; conflictsResolved?: number }> {
  // [v9.0 fix] T-1.3: getStoredSession sekarang async (auto-refresh access_token jika kedaluwarsa)
  let session: SupabaseSession | null;
  try {
    session = await getStoredSession();
  } catch (e: any) {
    // [v9.0 fix] T-4.2: network error saat getStoredSession (mis. refreshSession fetch gagal) → queue op
    enqueueSyncOp({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      enqueuedAt: new Date().toISOString(),
      config,
      data: localData,
    });
    return { success: false, error: `Session refresh gagal: ${e?.message ?? "unknown"}` };
  }
  if (!session || !session.user) {
    return { success: false, error: "Belum login" };
  }

  // [v9.0 fix] M-x: typed collections array — sebelumnya `{ items: any[] }[]`.
  const collections: { name: CollectionName; items: Syncable[] }[] = [
    { name: "transactions", items: localData.transactions as Syncable[] },
    { name: "wallets", items: localData.wallets as Syncable[] },
    { name: "coa", items: localData.coa as Syncable[] },
    { name: "budgets", items: localData.budgets as Syncable[] },
    { name: "savingsGoals", items: localData.savingsGoals as Syncable[] },
    { name: "recurring", items: localData.recurring as Syncable[] },
    { name: "debts", items: localData.debts as Syncable[] },
  ];

  // Try granular pull for each
  const merged: Partial<Record<CollectionName, Syncable[]>> = {};
  let totalConflicts = 0;
  let granularOk = true;
  const startTs = Date.now();

  try {
    for (const c of collections) {
      const pulled = await supabasePullCollection(config, c.name);
      if (pulled.error && pulled.error.startsWith("404")) {
        granularOk = false;
        break;
      }
      if (pulled.error) {
        // Other error — try granular anyway with local items only
        merged[c.name] = c.items;
        continue;
      }
      if (!pulled.items || pulled.items.length === 0) {
        // Cloud doesn't have it yet — use local
        merged[c.name] = c.items;
        continue;
      }
      // [v9.0 fix] M-x: mergeCollection sekarang accept `{ id: string }[]` — tidak perlu `as any`.
      const { merged: m, conflictsResolved } = mergeCollection<Syncable>(
        c.items,
        pulled.items as Syncable[]
      );
      merged[c.name] = m;
      totalConflicts += conflictsResolved;
    }
  } catch (e: any) {
    // [v9.0 fix] T-4.2: network error di tengah pull → queue op utuh untuk retry
    enqueueSyncOp({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      enqueuedAt: new Date().toISOString(),
      config,
      data: localData,
    });
    return { success: false, error: `Network error (pull): ${e?.message ?? "unknown"}` };
  }

  if (!granularOk) {
    // Fallback to legacy
    try {
      const legacyResult = await supabaseSmartSyncLegacy(config, localData);
      return {
        ...legacyResult,
        conflictsResolved: 0,
      };
    } catch (e: any) {
      // [v9.0 fix] T-4.2: queue untuk retry
      enqueueSyncOp({
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        enqueuedAt: new Date().toISOString(),
        config,
        data: localData,
      });
      return { success: false, error: `Legacy sync gagal: ${e?.message ?? "unknown"}` };
    }
  }

  // Pull settings granular
  const pulledSettings = await supabasePullSettings(config);
  let finalSettings = localData.settings;
  if (pulledSettings.settings) {
    // Merge settings: cloud wins for cloud-only keys, local wins for local-only keys
    // For overlapping keys, use the newer updated_at
    const localTs = new Date(localData.settings.lastSyncAt ?? 0).getTime();
    const cloudTs = pulledSettings.updatedAt ? new Date(pulledSettings.updatedAt).getTime() : 0;
    if (cloudTs > localTs) {
      finalSettings = {
        ...localData.settings, // keep local-only fields (sync tokens etc.)
        ...pulledSettings.settings,
      };
    }
  }

  // Build merged AppData
  // [v9.0 fix] M-x: cast kembali ke domain type via `as unknown as T[]` (explicit double-cast)
  // karena hasil merge adalah `Syncable[]` (hanya punya `id`). Audit [M-1] merekomendasikan
  // `as unknown as T` daripada `as any` supaya intent eksplisit.
  const mergedData: AppData = {
    schemaVersion: localData.schemaVersion,
    transactions: (merged.transactions ?? localData.transactions) as unknown as Transaction[],
    wallets: (merged.wallets ?? localData.wallets) as unknown as Wallet[],
    coa: (merged.coa ?? localData.coa) as unknown as COAAccount[],
    budgets: (merged.budgets ?? localData.budgets) as unknown as Budget[],
    savingsGoals: (merged.savingsGoals ?? localData.savingsGoals) as unknown as SavingsGoal[],
    recurring: (merged.recurring ?? localData.recurring) as unknown as RecurringTransaction[],
    debts: (merged.debts ?? localData.debts) as unknown as DebtLoan[],
    notifications: localData.notifications, // local-only, not synced
    activityLogs: localData.activityLogs, // local-only, not synced
    settings: finalSettings,
  };

  // Push merged back (granular)
  let pushErrors: string[] = [];
  for (const c of collections) {
    // [v9.0 fix] M-x: index access via Record lookup — sebelumnya `(merged as any)[c.name]`.
    const items: Syncable[] = merged[c.name] ?? c.items;
    const r = await supabasePushCollection(config, c.name, items);
    if (!r.ok) pushErrors.push(`${c.name}: ${r.error}`);
  }
  const settingsPush = await supabasePushSettings(config, finalSettings);
  if (!settingsPush.ok) pushErrors.push(`settings: ${settingsPush.error}`);

  // [v9.0 fix] T-4.2: jika push gagal total (semua collection error), queue untuk retry.
  // Heuristik: >50% collection gagal → anggap network bermasalah.
  if (pushErrors.length > collections.length / 2) {
    enqueueSyncOp({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      enqueuedAt: new Date().toISOString(),
      config,
      data: localData,
    });
  }

  return {
    success: pushErrors.length === 0,
    mergedData,
    pushedAt: new Date().toISOString(),
    conflictsResolved: totalConflicts,
    error: pushErrors.length > 0 ? pushErrors.join("; ") : undefined,
  };
}

// === LEGACY fallback ===
async function supabaseSmartSyncLegacy(
  config: SupabaseConfig,
  localData: AppData
): Promise<{ success: boolean; mergedData?: AppData; error?: string; pushedAt?: string }> {
  const pullResult = await supabasePullData(config);
  if (!pullResult.success) {
    return { success: false, error: pullResult.error };
  }
  const cloudData = pullResult.pulledData ?? {};

  let mergedData = localData;
  if (
    cloudData.transactions &&
    Array.isArray(cloudData.transactions) &&
    cloudData.transactions.length > 0
  ) {
    mergedData = {
      ...localData,
      ...cloudData,
      settings: {
        ...cloudData.settings,
        ...localData.settings,
      },
    } as AppData;
  }

  const pushResult = await supabasePushData(config, mergedData);
  if (!pushResult.success) {
    return { success: false, error: pushResult.error };
  }

  return {
    success: true,
    mergedData,
    pushedAt: pushResult.pushedAt,
  };
}
