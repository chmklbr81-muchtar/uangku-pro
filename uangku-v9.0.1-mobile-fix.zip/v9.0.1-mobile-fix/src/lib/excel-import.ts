// Import Excel/CSV dari Money Lover, Monefy, Wallet by BudgetBakers
// Format deteksi otomatis berdasarkan header kolom

// [v9.0 fix] Hapus unused import AppData (LOW priority cleanup)
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import type { Transaction, COAAccount } from "./types";
import { genId } from "./finance";

export type DetectedFormat = "money_lover" | "monefy" | "wallet" | "generic" | "unknown";

export interface ImportPreviewRow {
  date: string;
  type: "income" | "expense";
  amount: number;
  category: string;
  note: string;
  wallet?: string;
  mappedCOAId: string;
}

export interface ImportResult {
  format: DetectedFormat;
  formatLabel: string;
  rows: ImportPreviewRow[];
  totalRows: number;
  unmappedCategories: string[];
}

// Detect format dari header
function detectFormat(headers: string[]): DetectedFormat {
  const lower = headers.map((h) => h.toLowerCase().trim());
  // Money Lover: "Date" "Note" "Amount" "Category" "Wallet" (or "Account")
  const hasMoneyLover =
    lower.includes("date") &&
    lower.includes("amount") &&
    lower.includes("category") &&
    (lower.includes("wallet") || lower.includes("account"));
  // Monefy: "date" "note" "amount" "category" "account"
  const hasMonefy =
    lower.includes("date") && lower.includes("amount") && lower.includes("category") && lower.includes("note") && lower.includes("account");
  // Wallet by BudgetBakers: "Date" "Account" "Category" "Amount" "Note" (with "Expense/Income" type)
  const hasWallet =
    lower.includes("date") &&
    lower.includes("account") &&
    lower.includes("category") &&
    lower.includes("amount");

  // Wallet dan Money Lover mirip; Wallet punya account+category+amount saja, Money Lover tambahan note
  if (hasMonefy) return "monefy";
  if (hasWallet && lower.includes("note")) return "wallet";
  if (hasMoneyLover) return "money_lover";
  if (lower.includes("date") && lower.includes("amount")) return "generic";
  return "unknown";
}

// Parse tanggal fleksibel (dd/mm/yyyy, dd-mm-yyyy, yyyy-mm-dd, Excel serial)
function parseDate(raw: string | number | Date): string {
  if (raw instanceof Date) {
    return dateToISO(raw);
  }
  if (typeof raw === "number") {
    // Excel serial date (days since 1899-12-30)
    const d = new Date((raw - 25569) * 86400 * 1000);
    return dateToISO(d);
  }
  const s = String(raw).trim();
  // yyyy-mm-dd
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
  // dd/mm/yyyy or dd-mm-yyyy
  const m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/);
  if (m) {
    const dd = m[1].padStart(2, "0");
    const mm = m[2].padStart(2, "0");
    return `${m[3]}-${mm}-${dd}`;
  }
  // mm/dd/yyyy (US)
  const m2 = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (m2) {
    return `${m2[3]}-${m2[1].padStart(2, "0")}-${m2[2].padStart(2, "0")}`;
  }
  // Fallback
  return s;
}

function dateToISO(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

// [v9.0 fix] Handle format US (1,234.56) dan ID (1.234,56) tanpa kehilangan precision
// Deteksi format: jika string mengandung , DAN . -> asumsi ID (1.234,56)
// Jika hanya . -> US format (1,234.56) dimana koma = ribuan
// Jika hanya , -> ID decimal (1234,56)
function parseAmount(raw: string | number): number {
  if (typeof raw === "number") return Math.abs(raw);
  if (!raw) return 0;
  // Strip currency prefix/suffix dan whitespace, keep only digits, comma, dot, minus
  let s = String(raw)
    .replace(/[Rr][Pp]\.?\s*/g, "")
    .replace(/[^\d,.-]/g, "");
  if (!s) return 0;
  const hasComma = s.includes(",");
  const hasDot = s.includes(".");
  const lastComma = s.lastIndexOf(",");
  const lastDot = s.lastIndexOf(".");
  if (hasComma && hasDot) {
    // Format ID jika koma terakhir lebih kanan dari titik terakhir (1.234,56)
    // Format US jika titik terakhir lebih kanan dari koma terakhir (1,234.56)
    if (lastComma > lastDot) {
      // ID: titik = ribuan, koma = decimal
      s = s.replace(/\./g, "").replace(",", ".");
    } else {
      // US: koma = ribuan, titik = decimal
      s = s.replace(/,/g, "");
    }
  } else if (hasComma) {
    // Hanya koma. Asumsi: jika 1-2 digit setelah koma terakhir -> decimal (ID)
    // Jika tepat 3 digit setelah koma terakhir -> ambigu, asumsikan ribuan (US-style 1,234)
    const afterLast = s.length - lastComma - 1;
    if (afterLast === 3) {
      s = s.replace(/,/g, "");
    } else {
      s = s.replace(/,/g, ".");
    }
  }
  // Jika hanya titik -> biarkan (US decimal 1234.56)
  const n = parseFloat(s);
  return isNaN(n) ? 0 : Math.abs(n);
}

// Deteksi tipe dari string kolom (untuk Money Lover/Wallet)
function detectType(
  raw: string | number,
  amount: number
): "income" | "expense" {
  if (typeof raw === "string") {
    const s = raw.toLowerCase().trim();
    if (["income", "pemasukan", "masuk", "credit", "+"].includes(s)) return "income";
    if (["expense", "pengeluaran", "keluar", "debit", "-"].includes(s))
      return "expense";
  }
  // Fallback: anggap amount negatif = expense, positif = income
  const n = typeof raw === "number" ? raw : parseAmount(String(raw));
  // [v9.0 fix] Money Lover tanpa kolom Type: amount < 0 = expense, amount > 0 = income
  return n < 0 ? "expense" : "income";
}

// Mapping kategori default → COA code
const CATEGORY_MAPPING: Record<string, { coaCode: string; keywords: string[] }> = {
  // Income
  "1-1100": { coaCode: "1-1100", keywords: ["gaji", "salary", "upah", "wage"] },
  "5-1200": { coaCode: "5-1200", keywords: ["bonus", "thr", "insentif", "incentive"] },
  "5-1001": { coaCode: "5-1001", keywords: ["jual", "sale", "penjualan", "omzet"] },
  "5-1002": { coaCode: "5-1002", keywords: ["jasa", "service", "fee"] },
  "5-1300": { coaCode: "5-1300", keywords: ["investasi", "dividen", "bunga", "deposito", "reksadana"] },
  "6-1000": { coaCode: "6-1000", keywords: ["hadiah", "gift", "prize"] },
  "6-1200": { coaCode: "6-1200", keywords: ["refund", "reimburse", "kembali", "cashback"] },
  // Expense
  "8-1001": { coaCode: "8-1001", keywords: ["makan", "food", "eat", "restoran", "kuliner", "kafe", "cafe", "jajan"] },
  "8-1002": { coaCode: "8-1002", keywords: ["groceries", "belanja bulanan", "market", "supermarket", "sembako"] },
  "8-1100": { coaCode: "8-1100", keywords: ["transport", "bensin", "bbm", "parkir", "tol", "gojek", "grab", "taxi", "transportasi"] },
  "8-1200": { coaCode: "8-1200", keywords: ["belanja", "shopping", "pakaian", "baju", "sepatu", "fashion"] },
  "8-1300": { coaCode: "8-1300", keywords: ["listrik", "air", "internet", "wifi", "streaming", "netflix", "spotify", "pulsa", "tagihan"] },
  "8-1400": { coaCode: "8-1400", keywords: ["hiburan", "entertainment", "film", "game", "nonton", "concert", "karaoke"] },
  "8-1500": { coaCode: "8-1500", keywords: ["kesehatan", "dokter", "rumah sakit", "obat", "vitamin", "apotek", "rs"] },
  "8-1600": { coaCode: "8-1600", keywords: ["pendidikan", "sekolah", "kursus", "buku", "training", "kuliah", " spp"] },
  "8-1700": { coaCode: "8-1700", keywords: ["sewa", "kontrakan", "kos", "rent", "kantor"] },
  "8-1800": { coaCode: "8-1800", keywords: ["asuransi", "insurance", "premi"] },
  "8-1900": { coaCode: "8-1900", keywords: ["donasi", "sedekah", "zakat", "charity", "wakaf", "infak"] },
  "8-2000": { coaCode: "8-2000", keywords: ["admin", "fee bank", "biaya admin", "transfer fee"] },
  "8-9000": { coaCode: "8-9000", keywords: ["lainnya", "other", "misc", "dll", "uncategorized"] },
};

export function mapCategoryToCOA(
  categoryName: string,
  coa: COAAccount[]
): string {
  // [v9.0 fix] Guard against empty COA array (penyebab crash import)
  // Lempar error jelas agar UI bisa tampilkan pesan ke user, bukan TypeError cryptic.
  if (!coa || coa.length === 0) {
    throw new Error(
      "Chart of Accounts belum di-setup. Tambahkan minimal 1 akun di COA Manager sebelum import."
    );
  }
  const lower = categoryName.toLowerCase();
  for (const [, info] of Object.entries(CATEGORY_MAPPING)) {
    if (info.keywords.some((k) => lower.includes(k))) {
      const acc = coa.find((c) => c.code === info.coaCode);
      if (acc) return acc.id;
    }
  }
  // Fallback: cari nama match
  const direct = coa.find((c) => c.name.toLowerCase() === lower && c.parentId !== null);
  if (direct) return direct.id;
  // Default: Beban Lain-lain (expense) atau Pendapatan Lain (income)
  const fallback = coa.find((c) => c.code === "8-9000");
  // [v9.0 fix] Guard against empty COA array (penyebab crash import)
  return fallback?.id ?? coa.find((c) => c.type === "expense")?.id ?? coa[0]?.id ?? "";
}

export async function parseImportFile(file: File): Promise<ImportResult> {
  const isExcel = file.name.match(/\.(xlsx|xls)$/i);
  if (isExcel) {
    return await parseExcelFile(file);
  }
  // CSV
  const text = await file.text();
  return parseCSV(text);
}

async function parseExcelFile(file: File): Promise<ImportResult> {
  const buf = await file.arrayBuffer();
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buf);
  const ws = wb.worksheets[0];
  if (!ws) throw new Error("File Excel kosong");

  const rows: (string | number | Date)[][] = [];
  let rowCount = 0;
  ws.eachRow({ includeEmpty: false }, (row, idx) => {
    if (idx === 1) return; // skip header
    // [v9.0 fix] Batasi maksimal 10.000 baris per import (cegah DoS / memory exhaustion)
    rowCount++;
    if (rowCount > 10000) {
      throw new Error("Maksimal 10.000 baris per import.");
    }
    const vals = (row.values as (string | number | Date | null)[])
      .slice(1)
      .map((v) => (v ?? "") as string | number | Date);
    rows.push(vals);
  });

  // [v9.0 fix] M-x: typed ExcelJS cell-value union — sebelumnya `as any[]`.
  // ExcelJS `row.values` returns sparse array of CellValue (string|number|Date|boolean|null|undefined|{result,...}).
  // Kita hanya butuh string label untuk header, jadi coerce aman via String(v ?? "").
  type CellValue = string | number | Date | boolean | null | undefined;
  const headerRow = ws.getRow(1).values as CellValue[];
  const headers = headerRow.slice(1).map((v) => String(v ?? ""));
  return processRows(headers, rows);
}

function parseCSV(text: string): ImportResult {
  // [v9.0 fix] Strip BOM jika ada (file dari Excel/Windows sering punya BOM UTF-8)
  text = text.replace(/^\uFEFF/, "");
  // [v9.0 fix] Proper CSV parser handling quoted multi-line fields
  // Sebelumnya pakai text.split(/\r?\n/) yang akan salah split bila ada
  // field quoted yang berisi newline (mis. catatan multi-baris).
  const records = parseCSVRecords(text);
  if (records.length < 2) throw new Error("CSV kosong");
  const headers = records[0];
  // [v9.0 fix] Batasi maksimal 10.000 baris per import
  const dataRows = records.slice(1).slice(0, 10000);
  if (records.length - 1 > 10000) {
    throw new Error("Maksimal 10.000 baris per import.");
  }
  return processRows(headers, dataRows);
}

// [v9.0 fix] Proper CSV parser handling quoted multi-line fields
// Mengembalikan array dari array string. Menghormati quoted field dengan
// embedded newline dan escaped quote (").
function parseCSVRecords(text: string): string[][] {
  const records: string[][] = [];
  let field = "";
  let row: string[] = [];
  let inQuotes = false;
  let i = 0;
  // Normalisasi line ending: \r\n -> \n, lone \r -> \n
  const s = text.replace(/\r\n?/g, "\n");
  while (i < s.length) {
    const ch = s[i];
    if (inQuotes) {
      if (ch === '"') {
        if (s[i + 1] === '"') {
          // Escaped quote
          field += '"';
          i += 2;
          continue;
        }
        // End of quoted field
        inQuotes = false;
        i++;
        continue;
      }
      field += ch;
      i++;
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (ch === ',') {
      row.push(field.trim());
      field = "";
      i++;
      continue;
    }
    if (ch === '\n') {
      row.push(field.trim());
      field = "";
      // Skip empty trailing row (last line kosong)
      if (row.length > 0 && !(row.length === 1 && row[0] === "")) {
        records.push(row);
      }
      row = [];
      i++;
      continue;
    }
    field += ch;
    i++;
  }
  // Flush field & row terakhir
  if (field.length > 0 || row.length > 0) {
    row.push(field.trim());
    if (!(row.length === 1 && row[0] === "")) {
      records.push(row);
    }
  }
  return records;
}

// [v9.0 fix] Hapus dead code parseCSVLine (LOW priority cleanup) — digantikan
// oleh parseCSVRecords di atas yang menangani quoted multi-line fields.

function processRows(
  headers: string[],
  rows: (string | number | Date)[][]
): ImportResult {
  const format = detectFormat(headers);
  const lower = headers.map((h) => h.toLowerCase().trim());

  const idx = {
    date: lower.findIndex((h) => h === "date" || h === "tanggal"),
    note: lower.findIndex((h) => h === "note" || h === "notes" || h === "catatan" || h === "description"),
    amount: lower.findIndex((h) => h === "amount" || h === "jumlah" || h === "nominal"),
    category: lower.findIndex((h) => h === "category" || h === "kategori"),
    wallet: lower.findIndex((h) => h === "wallet" || h === "account" || h === "akun" || h === "dompet"),
    type: lower.findIndex((h) => h === "type" || h === "tipe" || h === "transaction type"),
  };

  if (idx.date === -1 || idx.amount === -1) {
    throw new Error("Format tidak dikenali. Pastikan ada kolom Date dan Amount.");
  }

  const previewRows: ImportPreviewRow[] = [];
  const unmapped = new Set<string>();
  // Untuk detect COA per app, kita butuh tipe transaksi
  // Money Lover: ada kolom "Type" (Expense/Income) atau "Amount" negatif
  // Monefy: tidak ada tipe eksplisit; expense vs income dari kategori (Monefy selalu punya kategori tipe)
  // Wallet: ada kolom "Expense" / "Income" di kolom Category atau type

  for (const row of rows) {
    if (!row || row.length === 0) continue;
    const dateRaw = row[idx.date];
    const amountRaw = row[idx.amount];
    const categoryRaw = idx.category >= 0 ? row[idx.category] : "";
    const noteRaw = idx.note >= 0 ? row[idx.note] : "";
    const walletRaw = idx.wallet >= 0 ? row[idx.wallet] : "";
    const typeRaw = idx.type >= 0 ? row[idx.type] : "";

    if (!dateRaw && !amountRaw) continue;

    const date = parseDate(dateRaw);
    const amount = parseAmount(amountRaw as string);

    // Tentukan tipe
    let type: "income" | "expense" = "expense";
    if (format === "money_lover" || format === "wallet") {
      if (typeRaw) {
        const s = String(typeRaw).toLowerCase();
        if (s.includes("income") || s.includes("masuk") || s === "credit") {
          type = "income";
        } else {
          type = "expense";
        }
      }
      // Money Lover: amount bisa negatif untuk expense
      const rawAmount = typeof amountRaw === "number" ? amountRaw : 0;
      if (rawAmount < 0) type = "expense";
    }
    // Monefy: kategori sudah tahu tipe, tapi kita tidak punya list kategori Monefy
    // Monefy: ada kolom "Type" sebenarnya? Coba dari typeRaw
    if (format === "monefy" && typeRaw) {
      const s = String(typeRaw).toLowerCase();
      if (s.includes("income")) type = "income";
    }
    // Generic: amount negatif = expense, positif = income
    if (format === "generic") {
      const n = typeof amountRaw === "number" ? amountRaw : parseFloat(String(amountRaw));
      type = n < 0 ? "expense" : "income";
    }

    const categoryStr = String(categoryRaw || "").trim() || "Lainnya";
    // [v9.0 fix] Guard against empty COA array (penyebab crash import)
    // Pada tahap parse/preview, COA belum tersedia; mapping ke COA dilakukan
    // di applyImport(). Jangan panggil mapCategoryToCOA(categoryStr, [])
    // karena akan throw TypeError / error "COA belum di-setup".
    if (!categoryStr || categoryStr === "Lainnya") {
      unmapped.add(categoryStr);
    }
    // Karena kita tidak punya COA di sini, kita simpan coaId kosong dulu
    previewRows.push({
      date,
      type,
      amount,
      category: categoryStr,
      note: String(noteRaw || "").trim(),
      wallet: String(walletRaw || "").trim(),
      mappedCOAId: "", // di-remap nantinya saat preview + apply
    });
  }

  const formatLabels: Record<DetectedFormat, string> = {
    money_lover: "Money Lover",
    monefy: "Monefy",
    wallet: "Wallet by BudgetBakers",
    generic: "CSV Generic",
    unknown: "Tidak Dikenali",
  };

  return {
    format,
    formatLabel: formatLabels[format],
    rows: previewRows,
    totalRows: previewRows.length,
    unmappedCategories: Array.from(unmapped),
  };
}

// Apply import: ubah ImportPreviewRow[] menjadi Transaction[]
export function applyImport(
  preview: ImportResult,
  coa: COAAccount[],
  defaultWalletId: string
): Transaction[] {
  return preview.rows.map((r) => {
    const coaId = mapCategoryToCOA(r.category, coa);
    const account = coa.find((c) => c.id === coaId);
    return {
      id: genId(),
      type: r.type,
      amount: r.amount,
      date: r.date,
      walletId: defaultWalletId,
      coaId,
      category: account?.name ?? r.category,
      note: r.note || undefined,
      tags: ["imported"],
      createdAt: new Date().toISOString(),
    };
  });
}

// Generate template download
export async function downloadImportTemplate() {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet("Template Import");
  ws.columns = [
    { width: 14 },
    { width: 18 },
    { width: 16 },
    { width: 24 },
    { width: 28 },
    { width: 16 },
  ];
  ws.getRow(1).values = [
    "Date",
    "Type",
    "Amount",
    "Category",
    "Note",
    "Wallet",
  ];
  ws.getRow(1).eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FFFFFFFF" } };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFA855F7" },
    };
  });

  // Contoh data
  const examples = [
    ["2026-01-15", "Income", 5000000, "Gaji", "Gaji bulanan Januari", "BCA"],
    ["2026-01-16", "Expense", 50000, "Makanan", "Makan siang", "Cash"],
    ["2026-01-20", "Expense", 150000, "Belanja", "Beli baju", "GoPay"],
    ["2026-01-25", "Expense", 350000, "Listrik", "Tagihan listrik bulanan", "BCA"],
    ["2026-01-28", "Income", 200000, "Bonus", "Bonus project", "Mandiri"],
  ];
  examples.forEach((row, idx) => {
    const r = ws.getRow(idx + 2);
    r.values = row;
  });

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  saveAs(blob, "Uangku_Template_Import.xlsx");
}
