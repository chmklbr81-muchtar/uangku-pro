// [v9.0] Dead code — exportToPDF tidak dipanggil di mana pun. deps jspdf+jspdf-autotable tetap di package.json untuk backward-compat. Dihapus di v9.1.
// PDF Export profesional — generate laporan keuangan PDF
// Pakai jsPDF + autotable
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import type { AppData } from "./types";
import {
  formatCurrency,
  formatDate,
  getMonthKey,
  getMonthLabel,
  getYear,
  getWallet,
  getCOAAccount,
  getWalletBalance,
  todayISO,
  computeSummary,
} from "./finance";

// [v9.0 fix] M-x: typed augmentation for jsPDF + autoTable plugin.
// `jspdf-autotable` mutates the jsPDF prototype at runtime (applyPlugin) to add
// `lastAutoTable` and the `autoTable()` instance method, but its .d.ts does not
// declare these on the jsPDF class. Sebelumnya kode pakai `(doc as any).lastAutoTable`
// untuk bypass — sekarang kita augment module declaration supaya type-safe.
interface AutoTableInfo {
  finalY: number;
}
interface JsPDFWithAutoTable extends jsPDF {
  lastAutoTable?: AutoTableInfo;
  // `internal.getNumberOfPages()` sudah ada di jsPDF types via `getNumberOfPages()`
  // top-level method; kita pakai top-level saja supaya tidak perlu `internal` cast.
}

interface PDFExportOptions {
  rangeStart: string;
  rangeEnd: string;
  includeTransactions: boolean;
  includeMonthlyReport: boolean;
  includeCOA: boolean;
  includeWallets: boolean;
}

export async function exportToPDF(data: AppData, options: PDFExportOptions) {
  const doc = new jsPDF({ unit: "mm", format: "a4" }) as JsPDFWithAutoTable;
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;
  let y = 20;

  // === Cover Page ===
  doc.setFillColor(20, 15, 40);
  doc.rect(0, 0, pageWidth, 60, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(28);
  doc.setFont("helvetica", "bold");
  doc.text("Uangku Pro", margin, 30);
  doc.setFontSize(11);
  doc.setFont("helvetica", "normal");
  doc.text("Laporan Keuangan Personal", margin, 40);
  doc.text(
    `Periode: ${formatDate(options.rangeStart)} s/d ${formatDate(options.rangeEnd)}`,
    margin,
    48
  );

  y = 75;
  doc.setTextColor(20, 15, 40);

  // === Summary Cards ===
  const txs = data.transactions.filter(
    (t) => t.date >= options.rangeStart && t.date <= options.rangeEnd
  );
  const totalIncome = txs.filter((t) => t.type === "income").reduce((a, t) => a + t.amount, 0);
  const totalExpense = txs.filter((t) => t.type === "expense").reduce((a, t) => a + t.amount, 0);
  const balance = totalIncome - totalExpense;

  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text("Ringkasan Periode", margin, y);
  y += 8;

  autoTable(doc, {
    startY: y,
    head: [["Statistik", "Nilai"]],
    body: [
      ["Total Pemasukan", formatCurrency(totalIncome)],
      ["Total Pengeluaran", formatCurrency(totalExpense)],
      ["Selisih (Net)", formatCurrency(balance)],
      ["Jumlah Transaksi", `${txs.length} transaksi`],
      ["Jumlah Dompet", `${data.wallets.filter((w) => !w.archived).length} dompet`],
    ],
    theme: "grid",
    headStyles: { fillColor: [124, 58, 237], textColor: 255 },
    bodyStyles: { fontSize: 10 },
    columnStyles: { 0: { fontStyle: "bold", cellWidth: 70 }, 1: { halign: "right" } },
    margin: { left: margin, right: margin },
  });

  y = (doc.lastAutoTable?.finalY ?? y) + 15;

  // === Wallets Summary ===
  if (options.includeWallets) {
    if (y > 250) {
      doc.addPage();
      y = 20;
    }
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("Saldo per Dompet", margin, y);
    y += 8;

    autoTable(doc, {
      startY: y,
      head: [["Dompet", "Tipe", "Saldo Awal", "Saldo Saat Ini"]],
      body: data.wallets.filter((w) => !w.archived).map((w) => [
        `${w.icon} ${w.name}`,
        w.type.replace(/_/g, " "),
        formatCurrency(w.initialBalance),
        formatCurrency(getWalletBalance(w.id, data.transactions, data.wallets)),
      ]),
      theme: "striped",
      headStyles: { fillColor: [16, 122, 87], textColor: 255 },
      bodyStyles: { fontSize: 10 },
      columnStyles: { 2: { halign: "right" }, 3: { halign: "right", fontStyle: "bold" } },
      margin: { left: margin, right: margin },
    });
    y = (doc.lastAutoTable?.finalY ?? y) + 15;
  }

  // === Transactions List ===
  if (options.includeTransactions) {
    doc.addPage();
    y = 20;
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("Daftar Transaksi", margin, y);
    y += 8;

    autoTable(doc, {
      startY: y,
      head: [["Tanggal", "Tipe", "Dompet", "Jumlah", "Kategori", "Catatan"]],
      body: txs
        .sort((a, b) => b.date.localeCompare(a.date))
        .map((t) => {
          const wallet = getWallet(data.wallets, t.walletId);
          const coa = getCOAAccount(data.coa, t.coaId);
          return [
            formatDate(t.date).slice(0, 16),
            t.type === "income" ? "Masuk" : t.type === "expense" ? "Keluar" : "Transfer",
            wallet ? `${wallet.icon} ${wallet.name}` : "—",
            formatCurrency(t.amount),
            coa?.name ?? t.category,
            t.note ?? "",
          ];
        }),
      theme: "striped",
      headStyles: { fillColor: [124, 58, 237], textColor: 255, fontSize: 9 },
      bodyStyles: { fontSize: 8 },
      margin: { left: margin, right: margin },
      columnStyles: { 3: { halign: "right" } },
    });
  }

  // === Monthly Report ===
  if (options.includeMonthlyReport) {
    doc.addPage();
    y = 20;
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("Laporan Bulanan", margin, y);
    y += 8;

    // Build months list
    const months: string[] = [];
    const [sy, sm] = options.rangeStart.split("-").map(Number);
    const [ey, em] = options.rangeEnd.split("-").map(Number);
    let cy = sy, cm = sm;
    while (cy < ey || (cy === ey && cm <= em)) {
      months.push(`${cy}-${String(cm).padStart(2, "0")}`);
      cm++;
      if (cm > 12) { cm = 1; cy++; }
    }

    autoTable(doc, {
      startY: y,
      head: [["Bulan", "Pemasukan", "Pengeluaran", "Selisih", "Savings %"]],
      body: months.map((mk) => {
        let income = 0, expense = 0;
        for (const t of data.transactions) {
          if (t.type === "transfer") continue;
          if (getMonthKey(t.date) !== mk) continue;
          if (t.type === "income") income += t.amount;
          else expense += t.amount;
        }
        const sr = income > 0 ? ((income - expense) / income) * 100 : 0;
        return [
          getMonthLabel(mk),
          formatCurrency(income),
          formatCurrency(expense),
          formatCurrency(income - expense),
          `${sr.toFixed(1)}%`,
        ];
      }),
      theme: "grid",
      headStyles: { fillColor: [16, 122, 87], textColor: 255 },
      bodyStyles: { fontSize: 10 },
      columnStyles: {
        1: { halign: "right" },
        2: { halign: "right" },
        3: { halign: "right" },
        4: { halign: "right" },
      },
      margin: { left: margin, right: margin },
    });
  }

  // === COA List ===
  if (options.includeCOA) {
    doc.addPage();
    y = 20;
    doc.setFontSize(13);
    doc.setFont("helvetica", "bold");
    doc.text("Chart of Account", margin, y);
    y += 8;

    autoTable(doc, {
      startY: y,
      head: [["Kode", "Nama Akun", "Tipe", "Status"]],
      body: data.coa
        .filter((c) => !c.archived)
        .sort((a, b) => a.code.localeCompare(b.code))
        .map((acc) => [
          acc.code,
          acc.parentId === null ? acc.name.toUpperCase() : `   ↳ ${acc.name}`,
          acc.type.replace(/_/g, " "),
          acc.archived ? "Arsip" : "Aktif",
        ]),
      theme: "striped",
      headStyles: { fillColor: [124, 58, 237], textColor: 255 },
      bodyStyles: { fontSize: 9 },
      margin: { left: margin, right: margin },
    });
  }

  // === Footer ===
  // [v9.0 fix] M-x: pakai top-level `getNumberOfPages()` (typed di jsPDF) — sebelumnya `(doc as any).internal.getNumberOfPages()`.
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text(
      `Uangku Pro — Laporan Keuangan · Hal ${i} dari ${pageCount} · Generated ${new Date().toLocaleString("id-ID")}`,
      margin,
      doc.internal.pageSize.getHeight() - 10
    );
  }

  // Save
  const filename = `UangkuPro_Laporan_${todayISO()}.pdf`;
  doc.save(filename);
  return filename;
}
