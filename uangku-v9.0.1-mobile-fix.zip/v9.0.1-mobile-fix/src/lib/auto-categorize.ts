// Auto-categorize v2.1 — Bayesian-flavored keyword matching + user correction learning
//
// v8.0: pure keyword length scoring
// v8.1: weighted keyword scoring + frequency prior from historical user transactions
//       + learning from manual corrections (saved in localStorage as simple stats table).
//
// All learned stats stay local. No external service, no PII leak.

import type { AppData, COAAccount, Transaction } from "./types";

interface KeywordEntry {
  coaId: string;
  keywords: string[];
}

const CATEGORY_KEYWORDS: KeywordEntry[] = [
  // Makanan
  { coaId: "coa-8-1001", keywords: ["makan", "makanan", "warung", "warteg", "padang", "sate", "ayam", "geprek", "bakso", "mie", "nasi", "kopi", "kafe", "cafe", "resto", "restoran", "jajan", "snack"] },
  { coaId: "coa-8-1002", keywords: ["indomaret", "alfamart", "alfamidi", "supermarket", "groceries", "sembako", "pasar", "sayur", "buah", "telur", "beras", "minyak"] },
  // Transportasi
  { coaId: "coa-8-1100", keywords: ["transport", "transportasi", "gojek", "grab", "maxim", "taxi", "taksi", "angkot", "bus", "kereta", "travel"] },
  { coaId: "coa-8-1101", keywords: ["bensin", "pertalite", "pertamax", "solar", "shell", "spbu", "fuel"] },
  { coaId: "coa-8-1102", keywords: ["parkir", "tol", "e-toll", "e toll"] },
  // Belanja
  { coaId: "coa-8-1200", keywords: ["belanja", "shopping", "shopee", "tokopedia", "lazada", "bukalapak", "tiktok shop"] },
  { coaId: "coa-8-1201", keywords: ["baju", "sepatu", "celana", "kaos", "pakaian", "fashion", "uniqlo", "zara"] },
  { coaId: "coa-8-1202", keywords: ["rumah", "kebutuhan rumah", "perabot", "ikea", "dekorasi"] },
  // Tagihan
  { coaId: "coa-8-1300", keywords: ["tagihan", "bill"] },
  { coaId: "coa-8-1301", keywords: ["listrik", "pln", "token", "kwh"] },
  { coaId: "coa-8-1302", keywords: ["air", "pdam", "pam"] },
  { coaId: "coa-8-1303", keywords: ["internet", "wifi", "indihome", "netflix", "spotify", "youtube premium", "streaming"] },
  { coaId: "coa-8-1304", keywords: ["pulsa", "paket data", "kuota", "tri", "telkomsel", "xl", "indosat", "im3"] },
  // Hiburan
  { coaId: "coa-8-1400", keywords: ["hiburan", "entertainment", "bioskop", "nonton", "konser", "karaoke", "game", "steam"] },
  // Kesehatan
  { coaId: "coa-8-1500", keywords: ["kesehatan", "dokter", "rumah sakit", "rs", "klinik", "apotek", "obat", "vitamin"] },
  // Pendidikan
  { coaId: "coa-8-1600", keywords: ["pendidikan", "sekolah", "kuliah", "kursus", "training", "buku", "ujian", "spp"] },
  // Sewa
  { coaId: "coa-8-1700", keywords: ["sewa", "kontrakan", "kos", "kost", "rent", "kantor"] },
  // Asuransi
  { coaId: "coa-8-1800", keywords: ["asuransi", "premi", "bpjs", "prudential", "allianz"] },
  // Donasi
  { coaId: "coa-8-1900", keywords: ["donasi", "sedekah", "zakat", "infaq", "wakaf", "charity"] },
  // Admin bank
  { coaId: "coa-8-2000", keywords: ["admin", "fee bank", "biaya admin", "transfer fee"] },
  // Income
  { coaId: "coa-5-1100", keywords: ["gaji", "salary", "upah", "wage", "thr", "tunjangan"] },
  { coaId: "coa-5-1200", keywords: ["bonus", "insentif", "incentive", "komisi", "fee proyek"] },
  { coaId: "coa-5-1001", keywords: ["jual", "sale", "penjualan", "omzet", "revenue"] },
  { coaId: "coa-5-1002", keywords: ["jasa", "service", "freelance", "proyek"] },
  { coaId: "coa-5-1300", keywords: ["investasi", "dividen", "bunga", "deposito", "reksadana", "saham"] },
  { coaId: "coa-6-1000", keywords: ["hadiah", "gift", "prize", "undian"] },
  { coaId: "coa-6-1200", keywords: ["refund", "reimburse", "kembali", "cashback"] },
];

// Keyword weights — multi-word / brand terms rank higher than generic 1-word terms
function keywordWeight(keyword: string): number {
  if (keyword.includes(" ") || keyword.length >= 7) return keyword.length * 1.5;
  return keyword.length;
}

// === Learning stats ===
// Stored as a small lookup table in localStorage: note-prefix (lowercased, 4-char) → COA ID with count + lastUpdated timestamp.
// [v9.0 fix] Cegah cache poisoning: cap per-prefix + decay (audit task 12-D A-05/A-06)
const LEARN_KEY = "uangku.autoCat.learn";
// [v9.0 fix] Cap per-prefix — mencegah satu prefix banjiri tabel dengan banyak COA (poisoning).
const MAX_ENTRIES_PER_PREFIX = 10;
// [v9.0 fix] Decay time constant (days) untuk exponential decay weight.
const DECAY_TAU_DAYS = 90;

interface LearnEntry {
  prefix: string;
  coaId: string;
  count: number;
  lastUpdated?: number; // [v9.0 fix] NEW — epoch ms, untuk exponential decay weight
}

function loadLearnStats(): LearnEntry[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(LEARN_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // [v9.0 fix] Validate shape: filter entry yang tidak valid (mencegah NaN silent bila localStorage tamper).
    return parsed.filter(
      (e: unknown): e is LearnEntry =>
        !!e &&
        typeof (e as LearnEntry).prefix === "string" &&
        typeof (e as LearnEntry).coaId === "string" &&
        typeof (e as LearnEntry).count === "number" &&
        isFinite((e as LearnEntry).count)
    );
  } catch {
    return [];
  }
}

function saveLearnStats(entries: LearnEntry[]) {
  if (typeof window === "undefined") return;
  try {
    // [v9.0 fix] Cap per-prefix at MAX_ENTRIES_PER_PREFIX (10) — cegah poisoning.
    // Group by prefix, keep top MAX_ENTRIES_PER_PREFIX by count within each group, then global cap 1000.
    const byPrefix = new Map<string, LearnEntry[]>();
    for (const e of entries) {
      const arr = byPrefix.get(e.prefix) ?? [];
      arr.push(e);
      byPrefix.set(e.prefix, arr);
    }
    const capped: LearnEntry[] = [];
    for (const arr of byPrefix.values()) {
      arr.sort((a, b) => b.count - a.count);
      capped.push(...arr.slice(0, MAX_ENTRIES_PER_PREFIX));
    }
    // Global cap 1000, keep top by count (preserve existing behavior).
    const sorted = capped.sort((a, b) => b.count - a.count).slice(0, 1000);
    window.localStorage.setItem(LEARN_KEY, JSON.stringify(sorted));
  } catch {
    // ignore quota errors
  }
}

function notePrefix(note: string): string {
  const lower = note.toLowerCase().replace(/[^a-z0-9\s]/g, "").trim();
  // Take first 4 alphanumeric chars from the first significant word
  const words = lower.split(/\s+/).filter(Boolean);
  if (words.length === 0) return "";
  // Use first word, capped at 4 chars
  return words[0].slice(0, 4);
}

// Call this whenever the user saves a transaction with a note — it reinforces the model.
// [v9.0 fix] Cegah cache poisoning: cap per-prefix + decay (audit task 12-D A-05/A-06).
export function learnFromTransaction(tx: Transaction) {
  if (!tx.note || tx.note.trim().length < 3) return;
  const prefix = notePrefix(tx.note);
  if (!prefix) return;
  const now = Date.now();
  const entries = loadLearnStats();
  const existing = entries.find((e) => e.prefix === prefix && e.coaId === tx.coaId);
  if (existing) {
    existing.count += 1;
    existing.lastUpdated = now;
  } else {
    // [v9.0 fix] Cek cap per-prefix sebelum push entry baru — bila sudah penuh (10 entries
    // untuk prefix ini), drop entry dengan count terkecil supaya entry baru bisa masuk.
    const samePrefix = entries.filter((e) => e.prefix === prefix);
    if (samePrefix.length >= MAX_ENTRIES_PER_PREFIX) {
      // Drop entry with smallest count (oldest decayed weight effectively evicted).
      let minIdx = -1;
      let minCount = Infinity;
      for (let i = 0; i < entries.length; i++) {
        if (entries[i].prefix === prefix && entries[i].count < minCount) {
          minCount = entries[i].count;
          minIdx = i;
        }
      }
      if (minIdx >= 0) entries.splice(minIdx, 1);
    }
    entries.push({ prefix, coaId: tx.coaId, count: 1, lastUpdated: now });
  }
  saveLearnStats(entries);
}

// Optional: rebuild learning stats from a full transaction history (useful after import).
export function rebuildLearningFromHistory(transactions: Transaction[]) {
  const now = Date.now();
  const stats: Record<string, Record<string, number>> = {};
  for (const tx of transactions) {
    if (!tx.note || tx.note.trim().length < 3) continue;
    const prefix = notePrefix(tx.note);
    if (!prefix) continue;
    if (!stats[prefix]) stats[prefix] = {};
    stats[prefix][tx.coaId] = (stats[prefix][tx.coaId] ?? 0) + 1;
  }
  const entries: LearnEntry[] = [];
  for (const [prefix, coaMap] of Object.entries(stats)) {
    // [v9.0 fix] Cap per-prefix at MAX_ENTRIES_PER_PREFIX during rebuild.
    const sorted = Object.entries(coaMap)
      .map(([coaId, count]) => ({ prefix, coaId, count, lastUpdated: now }))
      .sort((a, b) => b.count - a.count)
      .slice(0, MAX_ENTRIES_PER_PREFIX);
    entries.push(...sorted);
  }
  saveLearnStats(entries);
}

// [v9.0 fix] Helper: compute decayed weight = count × exp(-daysSinceUpdate / 90).
// Entry lama (>90 hari) weight ~ e^-1 ≈ 0.37; entry baru weight = count.
// Bila entry tidak punya lastUpdated (data lama migrasi), anggap "sekarang" (no decay).
function decayedWeight(entry: LearnEntry): number {
  const now = Date.now();
  const last = typeof entry.lastUpdated === "number" ? entry.lastUpdated : now;
  const daysSince = Math.max(0, (now - last) / (24 * 60 * 60 * 1000));
  return entry.count * Math.exp(-daysSince / DECAY_TAU_DAYS);
}

// === Suggest COA ===
// Returns the best-matching COA account, or null if no good match.
// Scoring:
//   base = Σ(keywordWeight(kw)) for each kw ∈ note
//   prior = decayed_count(prefix, coaId) × 5  (Bayesian-ish prior with exponential decay)
//   score = base + prior
// Threshold: only suggest if score >= 3.
export function suggestCOA(
  note: string,
  coa: COAAccount[],
  transactionType: "income" | "expense" = "expense"
): COAAccount | null {
  if (!note || note.trim().length < 2) return null;
  const noteLower = note.toLowerCase();

  const validTypes =
    transactionType === "income"
      ? ["income", "other_income"]
      : ["expense", "operating_expense"];

  const validCOAs = coa.filter((c) => !c.archived && validTypes.includes(c.type));
  const validCOAIds = new Set(validCOAs.map((c) => c.id));

  // Learned priors
  const prefix = notePrefix(note);
  const learnStats = prefix ? loadLearnStats().filter((e) => e.prefix === prefix) : [];

  let bestMatch: { coaId: string; score: number } | null = null;
  for (const { coaId, keywords } of CATEGORY_KEYWORDS) {
    if (!validCOAIds.has(coaId)) continue;
    let score = 0;
    for (const keyword of keywords) {
      if (noteLower.includes(keyword)) {
        score += keywordWeight(keyword);
      }
    }
    // Add learned prior (with [v9.0 fix] decay)
    const learnEntry = learnStats.find((e) => e.coaId === coaId);
    if (learnEntry) {
      score += Math.min(decayedWeight(learnEntry) * 5, 30); // cap prior contribution
    }
    if (score > 0 && (!bestMatch || score > bestMatch.score)) {
      bestMatch = { coaId, score };
    }
  }

  // Pure-learned fallback: no keyword match, but we have learned priors for this prefix.
  // [v9.0 fix] Pakai decayedWeight + cap 30 (sebelumnya top.count × 5 tanpa cap → overfitting).
  if (!bestMatch && learnStats.length > 0) {
    const top = [...learnStats]
      .map((e) => ({ entry: e, weight: decayedWeight(e) }))
      .sort((a, b) => b.weight - a.weight)[0];
    if (top && validCOAIds.has(top.entry.coaId)) {
      bestMatch = { coaId: top.entry.coaId, score: Math.min(top.weight * 5, 30) };
    }
  }

  if (!bestMatch || bestMatch.score < 3) return null;
  return coa.find((c) => c.id === bestMatch!.coaId) ?? null;
}

// === Smart Notifications ===
export interface SmartNotification {
  id: string;
  type: "warning" | "info" | "tip";
  title: string;
  message: string;
  action?: string;
}

export function generateSmartNotifications(data: AppData): SmartNotification[] {
  const notifications: SmartNotification[] = [];
  const now = new Date();
  const thisMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const lastMonthKey = `${lastMonth.getFullYear()}-${String(lastMonth.getMonth() + 1).padStart(2, "0")}`;

  // 1. Cek transaksi 7 hari terakhir
  let weekTxCount = 0;
  for (const t of data.transactions) {
    const tDate = new Date(t.date);
    const daysAgo = (now.getTime() - tDate.getTime()) / (24 * 60 * 60 * 1000);
    if (daysAgo <= 7) weekTxCount++;
  }
  if (weekTxCount === 0) {
    notifications.push({
      id: "smart-no-tx-week",
      type: "warning",
      title: "Sudah 7 hari tidak ada transaksi",
      message: "Catat transaksi 7 hari terakhir untuk tracking akurat.",
      action: "Tambah Transaksi",
    });
  }

  // 2. Bandingkan pengeluaran bulan ini vs bulan lalu
  let thisMonthExpense = 0, lastMonthExpense = 0;
  for (const t of data.transactions) {
    if (t.type !== "expense") continue;
    const mk = `${t.date.slice(0, 7)}`;
    if (mk === thisMonthKey) thisMonthExpense += t.amount;
    else if (mk === lastMonthKey) lastMonthExpense += t.amount;
  }
  if (lastMonthExpense > 0 && thisMonthExpense > lastMonthExpense * 1.2) {
    const increase = ((thisMonthExpense / lastMonthExpense - 1) * 100).toFixed(0);
    // Use dynamic import to avoid circular dependency at module load
    import("./finance").then(({ formatCurrency }) => {
      // cannot push to array post-return; this branch is informational only
    });
    // Inline formatCurrency for safety
    const fmt = (n: number) =>
      new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(n);
    notifications.push({
      id: "smart-expense-increase",
      type: "warning",
      title: `Pengeluaran naik ${increase}%`,
      message: `Bulan ini ${fmt(thisMonthExpense)}, bulan lalu ${fmt(lastMonthExpense)}.`,
    });
  }

  // 3. Cek budget yang hampir habis
  for (const budget of data.budgets) {
    if (budget.monthKey !== thisMonthKey) continue;
    const used = data.transactions
      .filter((t) => t.coaId === budget.coaId && t.date.slice(0, 7) === thisMonthKey && t.type === "expense")
      .reduce((a, t) => a + t.amount, 0);
    const percent = (used / budget.amount) * 100;
    if (percent >= 80) {
      const acc = data.coa.find((c) => c.id === budget.coaId);
      const fmt = (n: number) =>
        new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(n);
      notifications.push({
        id: `smart-budget-${budget.id}`,
        type: "warning",
        title: `Anggaran ${acc?.name ?? "kategori"} ${percent.toFixed(0)}% terpakai`,
        message: `Sisa ${fmt(budget.amount - used)} bulan ini.`,
      });
    }
  }

  // 4. Tagihan jatuh tempo H-3
  for (const r of data.recurring) {
    if (r.archived || r.type !== "expense") continue;
    const due = new Date(r.nextRunDate);
    const daysToDue = Math.ceil((due.getTime() - now.getTime()) / (24 * 60 * 60 * 1000));
    if (daysToDue >= 0 && daysToDue <= 3) {
      const fmt = (n: number) =>
        new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(n);
      notifications.push({
        id: `smart-bill-${r.id}`,
        type: "warning",
        title: `Tagihan ${r.name} jatuh tempo`,
        message: `${daysToDue === 0 ? "Hari ini" : daysToDue === 1 ? "Besok" : `${daysToDue} hari lagi`}: ${fmt(r.amount)}`,
      });
    }
  }

  // 5. Dompet saldo rendah
  for (const w of data.wallets) {
    if (w.archived || !w.minAlert) continue;
    // Inline balance calc to avoid circular dep
    let bal = w.initialBalance;
    for (const t of data.transactions) {
      if (t.walletId === w.id) {
        if (t.type === "income") bal += t.amount;
        else if (t.type === "expense") bal -= t.amount;
        else if (t.type === "transfer") bal -= t.amount;
      } else if (t.type === "transfer" && t.transferToWalletId === w.id) {
        bal += t.amount;
      }
    }
    if (bal < w.minAlert) {
      const fmt = (n: number) =>
        new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(n);
      notifications.push({
        id: `smart-low-balance-${w.id}`,
        type: "warning",
        title: `Saldo ${w.name} rendah`,
        message: `Saldo ${fmt(bal)} di bawah minimum ${fmt(w.minAlert)}`,
      });
    }
  }

  // 6. Tips harian
  const tips = [
    "Saran: Catat transaksi segera setelah belanja agar tidak lupa.",
    "Saran: Pakai Budget Template 50/30/20 untuk pengeluaran sehat.",
    "Saran: Aktifkan sync Supabase supaya data aman saat pindah HP.",
    "Saran: Backup JSON ke Google Drive minimal seminggu sekali.",
    "Saran: Cek Financial Health Score di Analitik untuk tahu kondisi keuangan.",
  ];
  const today = now.getDate();
  notifications.push({
    id: `smart-tip-${today}`,
    type: "tip",
    title: "Tips Hari Ini",
    message: tips[today % tips.length],
  });

  return notifications;
}
