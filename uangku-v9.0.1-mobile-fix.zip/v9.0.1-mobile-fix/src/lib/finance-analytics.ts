// Financial analytics: Health Score, Wealth Pyramid, Cash Flow Forecast, What-If, Net Worth, Loan Calculator
import type { AppData, Wallet, COAAccount, Transaction } from "./types";
import {
  formatCurrency,
  getMonthKey,
  getYear,
  todayISO,
  getWalletBalance,
} from "./finance";

// === FINANCIAL HEALTH SCORE v2 (0-100) ===
// v9.0 changes (audit task 12-D):
//   - Eliminasi double-counting komponen emergency (sebelumnya emergencyFund + emergencyMonths overlap)
//     → digabung jadi satu komponen `emergencyFundMonths` (bobot 0.20).
//   - Multiplier savingsRate 2.5 → 5.0 supaya savings rate 20% (target) → score 100.
//   - debtRatio saat totalBalance = 0 & totalDebt > 0 → score 0 (sebelumnya 100, bug A-03).
//     Saat totalBalance = 0 & totalDebt = 0 → skip komponen, redistribute bobot 0.14.
//   - debtToIncome saat monthlyIncome = 0 & monthlyDebtService > 0 → score 0 (guard A-04).
//   - Components: 6 (was 7) + 1 optional fallback
//   - Refined weights (sum to 100):
//       savingsRate           27%  (was 22%, +5% dari redistribution emergency)
//       emergencyFundMonths   20%  (NEW — consolidation of old emergencyFund 0.20 + emergencyMonths 0.10,
//                                    10% freed ke savingsRate +5, consistency +3, expenseStability +2)
//       debtRatio             14%  (skip & redistribute bila totalBalance = totalDebt = 0)
//       debtToIncome          10%
//       expenseStability      15%  (was 13%, +2% redistribution)
//       consistency           14%  (was 11%, +3% redistribution)
export interface HealthScore {
  score: number;
  grade: "A+" | "A" | "B" | "C" | "D" | "F";
  components: {
    savingsRate: number;
    emergencyFund: number;         // [v9.0] deprecated alias — mirror of emergencyFundMonths (backward compat)
    debtRatio: number;
    debtToIncome: number;
    expenseStability: number;
    consistency: number;
    emergencyMonths: number;       // [v9.0] deprecated alias — mirror of emergencyFundMonths (backward compat)
    emergencyFundMonths: number;   // [v9.0 fix] NEW — consolidated emergency component (replaces emergencyFund + emergencyMonths)
  };
  metrics: {
    savingsRatePct: number;
    emergencyFundRatio: number;  // 1.0 = 1 month of expenses
    emergencyFundMonths: number;
    debtToIncomePct: number;
    monthlyDebtService: number;
    monthlyIncome: number;
    monthlyExpense: number;
    totalDebt: number;
  };
  insights: string[];
  recommendations: string[];
}

export function computeHealthScore(data: AppData): HealthScore {
  const txs = data.transactions;
  const now = new Date();
  const thisYear = getYear(todayISO());

  let ytdIncome = 0, ytdExpense = 0;
  for (const t of txs) {
    if (t.type === "transfer") continue;
    if (getYear(t.date) !== thisYear) continue;
    if (t.type === "income") ytdIncome += t.amount;
    else ytdExpense += t.amount;
  }

  const savingsRateRaw = ytdIncome > 0 ? ((ytdIncome - ytdExpense) / ytdIncome) * 100 : 0;
  // [v9.0 fix] Multiplier 5.0 supaya savings rate 20% (target) → score 100 (konsisten dengan insight "target: minimal 20%" & 50/30/20 rule).
  // Sebelumnya * 2.5 → 20% hanya capai 50/100.
  const savingsRate = Math.max(0, Math.min(100, savingsRateRaw * 5.0));

  const monthsElapsed = Math.max(1, now.getMonth() + 1);
  const avgMonthlyExpense = ytdExpense / monthsElapsed;
  const avgMonthlyIncome = ytdIncome / monthsElapsed;

  // === NEW: monthly debt service estimate ===
  // Sum of payments to payables in the last 3 months / 3 → monthly debt service
  let recentDebtPayments = 0;
  const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);
  for (const d of data.debts) {
    if (d.type !== "payable") continue;
    if (d.status === "paid") continue;
    // Approximation: outstanding / 12 as monthly commitment
    recentDebtPayments += (d.amount - d.paidAmount) / 12;
  }
  const monthlyDebtService = recentDebtPayments;
  // [v9.0 fix] Guard debtToIncome saat monthlyIncome = 0:
  //   - income = 0 & debt > 0 → score 0 (worst case, user berutang tanpa penghasilan)
  //   - income = 0 & debt = 0 → score 100 (TANPA debt, TANPA income — neutral)
  //   - income > 0 → formula biasa: 0% = 100 score, 36%+ = 0 score (Bank Indonesia guidance)
  let debtToIncomePct: number;
  let debtToIncome: number;
  if (avgMonthlyIncome > 0) {
    debtToIncomePct = (monthlyDebtService / avgMonthlyIncome) * 100;
    debtToIncome = Math.max(0, Math.min(100, 100 - debtToIncomePct * (100 / 36)));
  } else if (monthlyDebtService > 0) {
    // Tidak ada income tapi ada debt service commitment → kondisi terburuk
    debtToIncomePct = 100; // cap di 100 agar insight warning tetap trigger
    debtToIncome = 0;
  } else {
    debtToIncomePct = 0;
    debtToIncome = 100;
  }

  const totalBalance = data.wallets
    .filter((w) => !w.archived)
    .reduce((a, w) => a + getWalletBalance(w.id, txs, data.wallets), 0);
  // [v9.0 fix] Eliminasi double-counting komponen emergency (sebelumnya emergencyFund + emergencyMonths overlap).
  // Sekarang satu komponen `emergencyFundMonths` dihitung dari rasio totalBalance / avgMonthlyExpense.
  // Score: 3 months = 50, 6 months = 100 (cap), 0 months = 0.
  const emergencyFundRatio = avgMonthlyExpense > 0 ? totalBalance / (avgMonthlyExpense * 3) : 0;
  const emergencyFundMonthsRaw = avgMonthlyExpense > 0 ? totalBalance / avgMonthlyExpense : 0;
  // Consolidated emergency score: linear 0→6 months, score = (months / 6) * 100.
  // 3 months (minimum sehat) → 50, 6 months (ideal) → 100.
  const emergencyFundMonthsScore = Math.max(0, Math.min(100, (emergencyFundMonthsRaw / 6) * 100));
  // Backward-compat aliases (mirror nilai consolidated)
  const emergencyFund = emergencyFundMonthsScore;
  const emergencyMonthsScore = emergencyFundMonthsScore;
  const emergencyFundMonths = emergencyFundMonthsRaw; // metric value (raw months)

  const totalDebt = data.debts
    .filter((d) => d.type === "payable" && d.status !== "paid")
    .reduce((a, d) => a + (d.amount - d.paidAmount), 0);
  // [v9.0 fix] debtRatio saat totalBalance = 0:
  //   - balance = 0 & debt > 0 → debtRatio = 1 (worst), score = 0 (sebelumnya 100, bug A-03)
  //   - balance = 0 & debt = 0 → skip komponen, redistribute bobot 0.14 ke komponen lain
  //   - balance > 0 → debtRatio = totalDebt / (totalBalance + totalDebt), score = (1 - debtRatio) * 100
  let debtRatioRaw: number; // 0..1, leverage ratio = debt / (asset + debt)
  let debtRatioScore: number; // 0..100 score
  let hasDebtRatioData = true; // whether component has meaningful data
  if (totalDebt > 0) {
    debtRatioRaw = totalDebt / (totalBalance + totalDebt); // balance=0 → 1 (worst)
    debtRatioScore = Math.max(0, Math.min(100, (1 - debtRatioRaw) * 100));
  } else if (totalBalance > 0) {
    // Punya aset, tanpa utang → best
    debtRatioRaw = 0;
    debtRatioScore = 100;
  } else {
    // Tidak ada aset & tidak ada utang → N/A, skip dari weighted sum
    debtRatioRaw = 0;
    debtRatioScore = 0;
    hasDebtRatioData = false;
  }
  const debtRatio = debtRatioScore;

  const monthlyExpenses: number[] = [];
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    let m = 0;
    for (const t of txs) {
      if (t.type !== "expense") continue;
      if (getMonthKey(t.date) !== mk) continue;
      m += t.amount;
    }
    monthlyExpenses.push(m);
  }
  const nonZero = monthlyExpenses.filter((m) => m > 0);
  let expenseStability = 50;
  if (nonZero.length >= 2) {
    const avg = nonZero.reduce((a, b) => a + b, 0) / nonZero.length;
    const variance = nonZero.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / nonZero.length;
    const cv = avg > 0 ? Math.sqrt(variance) / avg : 0;
    expenseStability = Math.max(0, Math.min(100, 100 - cv * 100));
  }

  const monthsWithData = new Set<string>();
  for (const t of txs) monthsWithData.add(getMonthKey(t.date));
  let consistency = 0;
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    if (monthsWithData.has(mk)) consistency += 100 / 6;
  }

  // [v9.0 fix] Weighted sum dengan bobot baru (post A-01 redistribution):
  //   savingsRate 0.27 + emergencyFundMonths 0.20 + debtRatio 0.14 + debtToIncome 0.10
  //   + expenseStability 0.15 + consistency 0.14 = 1.00 (atau 0.86 bila debtRatio di-skip).
  // Jika debtRatio di-skip (no asset & no debt), bobot di-renormalize sehingga skor tetap di skala 0..100.
  const WEIGHTS = {
    savingsRate: 0.27,
    emergencyFundMonths: 0.20,
    debtRatio: 0.14,
    debtToIncome: 0.10,
    expenseStability: 0.15,
    consistency: 0.14,
  } as const;
  const weightedSum =
    savingsRate * WEIGHTS.savingsRate +
    emergencyFundMonthsScore * WEIGHTS.emergencyFundMonths +
    (hasDebtRatioData ? debtRatioScore * WEIGHTS.debtRatio : 0) +
    debtToIncome * WEIGHTS.debtToIncome +
    expenseStability * WEIGHTS.expenseStability +
    consistency * WEIGHTS.consistency;
  const totalWeight =
    WEIGHTS.savingsRate +
    WEIGHTS.emergencyFundMonths +
    WEIGHTS.debtToIncome +
    WEIGHTS.expenseStability +
    WEIGHTS.consistency +
    (hasDebtRatioData ? WEIGHTS.debtRatio : 0);
  const score = Math.round(weightedSum / totalWeight);

  let grade: HealthScore["grade"] = "F";
  if (score >= 90) grade = "A+";
  else if (score >= 80) grade = "A";
  else if (score >= 65) grade = "B";
  else if (score >= 50) grade = "C";
  else if (score >= 35) grade = "D";

  const insights: string[] = [];
  const recommendations: string[] = [];

  // [v9.0 fix] Insight savingsRate tetap pakai target 20% (sekarang konsisten dengan multiplier 5.0 → 20% = score 100).
  if (savingsRateRaw < 10) {
    insights.push(`Savings rate ${savingsRateRaw.toFixed(1)}% (target: minimal 20%)`);
    recommendations.push("Kurangi pengeluaran tidak penting, alokasikan ke tabungan");
  } else if (savingsRateRaw >= 20) {
    insights.push(`Savings rate ${savingsRateRaw.toFixed(1)}% sangat baik!`);
  }

  if (emergencyFundRatio < 1) {
    insights.push(`Emergency fund ${emergencyFundRatio.toFixed(1)}x pengeluaran bulanan (target: 3x)`);
    recommendations.push("Bangun emergency fund minimal 3x pengeluaran bulanan");
  } else if (emergencyFundRatio >= 3) {
    insights.push(`Emergency fund ${emergencyFundRatio.toFixed(1)}x — sangat aman!`);
  }

  // [v9.0 fix] Insight emergency pakai consolidated metric (emergencyFundMonths bulan, target 3-6 bln).
  if (emergencyFundMonths < 1) {
    insights.push(`Emergency fund ${emergencyFundMonths.toFixed(1)} bulan (sangat tipis)`);
  } else if (emergencyFundMonths >= 3) {
    insights.push(`Emergency fund ${emergencyFundMonths.toFixed(1)} bulan — sehat`);
  }

  // NEW: debt-to-income insight
  if (debtToIncomePct > 36) {
    insights.push(`Debt-to-income ratio ${debtToIncomePct.toFixed(0)}% — di atas batas aman 36%`);
    recommendations.push("Hentikan utang baru, alokasikan lebih besar untuk pelunasan utang");
  } else if (debtToIncomePct > 0 && debtToIncomePct <= 18) {
    insights.push(`Debt-to-income ratio ${debtToIncomePct.toFixed(0)}% — sangat sehat`);
  }

  if (totalDebt > 0) {
    insights.push(`Total utang outstanding: ${formatCurrency(totalDebt)}`);
    // debtRatioRaw sekarang = debt / (asset + debt). Threshold 0.5 → utang ≥ 50% dari (asset+debt).
    if (debtRatioRaw >= 0.5) {
      recommendations.push("Bayar utang lebih agresif — rasio utang terlalu tinggi");
    }
  }

  if (expenseStability < 50) {
    insights.push(`Pengeluaran fluktuatif (stability ${expenseStability.toFixed(0)}%)`);
    recommendations.push("Buat anggaran bulanan untuk stabilkan pengeluaran");
  }

  if (consistency < 50) {
    insights.push(`Baru catat transaksi ${Math.round((consistency / 100) * 6)} bulan dari 6 bulan terakhir`);
    recommendations.push("Catat transaksi rutin setiap hari untuk tracking akurat");
  }

  if (insights.length === 0) {
    insights.push("Keuangan Anda dalam kondisi sehat! Pertahankan.");
  }

  return {
    score,
    grade,
    components: {
      savingsRate: Math.round(savingsRate),
      emergencyFund: Math.round(emergencyFund), // [v9.0] deprecated alias — mirror emergencyFundMonthsScore
      debtRatio: Math.round(debtRatio),
      debtToIncome: Math.round(debtToIncome),
      expenseStability: Math.round(expenseStability),
      consistency: Math.round(consistency),
      emergencyMonths: Math.round(emergencyMonthsScore), // [v9.0] deprecated alias — mirror emergencyFundMonthsScore
      emergencyFundMonths: Math.round(emergencyFundMonthsScore), // [v9.0 fix] NEW consolidated
    },
    metrics: {
      savingsRatePct: savingsRateRaw,
      emergencyFundRatio,
      emergencyFundMonths, // raw months value
      debtToIncomePct,
      monthlyDebtService,
      monthlyIncome: avgMonthlyIncome,
      monthlyExpense: avgMonthlyExpense,
      totalDebt,
    },
    insights,
    recommendations,
  };
}

// === WEALTH PYRAMID ===
export interface WealthPyramid {
  needs: number;
  wants: number;
  savings: number;
  investing: number;
  totalExpense: number;
  proportions: {
    needs: number;
    wants: number;
    savings: number;
    investing: number;
  };
  recommendations: string[];
}

export function computeWealthPyramid(data: AppData): WealthPyramid {
  const now = new Date();
  const thisMonthKey = getMonthKey(todayISO());

  const NEEDS_COA = ["coa-8-1001", "coa-8-1002", "coa-8-1100", "coa-8-1300", "coa-8-1700", "coa-8-1301", "coa-8-1302", "coa-8-1303", "coa-8-1800", "coa-8-1500", "coa-8-1600"];
  const WANTS_COA = ["coa-8-1200", "coa-8-1201", "coa-8-1202", "coa-8-1400", "coa-8-1900"];
  const INVESTING_COA = ["coa-1-1400", "coa-1-1401", "coa-1-1402", "coa-1-1403"];

  let needs = 0, wants = 0, savings = 0, investing = 0;

  for (const t of data.transactions) {
    if (t.type === "transfer") continue;
    if (getMonthKey(t.date) !== thisMonthKey) continue;
    if (t.type === "expense") {
      if (NEEDS_COA.includes(t.coaId)) needs += t.amount;
      else if (WANTS_COA.includes(t.coaId)) wants += t.amount;
      else if (INVESTING_COA.includes(t.coaId)) investing += t.amount;
      else needs += t.amount;
    } else if (t.type === "income") {
      if (INVESTING_COA.includes(t.coaId)) savings += t.amount;
    }
  }

  let monthIncome = 0, monthExpense = 0;
  for (const t of data.transactions) {
    if (t.type === "transfer") continue;
    if (getMonthKey(t.date) !== thisMonthKey) continue;
    if (t.type === "income") monthIncome += t.amount;
    else monthExpense += t.amount;
  }
  savings = Math.max(savings, monthIncome - monthExpense);

  const totalExpense = needs + wants + investing + savings;
  const proportions = {
    needs: totalExpense > 0 ? (needs / totalExpense) * 100 : 0,
    wants: totalExpense > 0 ? (wants / totalExpense) * 100 : 0,
    savings: totalExpense > 0 ? (savings / totalExpense) * 100 : 0,
    investing: totalExpense > 0 ? (investing / totalExpense) * 100 : 0,
  };

  const recommendations: string[] = [];
  if (proportions.needs > 60) recommendations.push("Kebutuhan pokok >60% — kurangi biaya tetap (sewa, langganan)");
  if (proportions.wants > 30) recommendations.push(`Wants ${proportions.wants.toFixed(0)}% — batasi pengeluaran gaya hidup`);
  if (proportions.savings < 10) recommendations.push("Savings <10% — tingkatkan tabungan ke minimal 20% dari income");
  if (proportions.investing < 5) recommendations.push("Investing <5% — mulai investasi kecil-kecilan (reksadana)");
  if (recommendations.length === 0) recommendations.push("Komposisi pengeluaran Anda ideal! Pertahankan.");

  return { needs, wants, savings, investing, totalExpense, proportions, recommendations };
}

// === CASH FLOW FORECAST ===
export interface CashFlowForecast {
  months: { monthKey: string; label: string; projectedIncome: number; projectedExpense: number; projectedBalance: number; warning?: string }[];
  currentBalance: number;
  monthlyAvgIncome: number;
  monthlyAvgExpense: number;
}

export function computeCashFlowForecast(data: AppData): CashFlowForecast {
  const now = new Date();
  let totalIncome3m = 0, totalExpense3m = 0;
  for (let i = 0; i < 3; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    for (const t of data.transactions) {
      if (t.type === "transfer") continue;
      if (getMonthKey(t.date) !== mk) continue;
      if (t.type === "income") totalIncome3m += t.amount;
      else totalExpense3m += t.amount;
    }
  }
  const monthlyAvgIncome = totalIncome3m / 3;
  const monthlyAvgExpense = totalExpense3m / 3;
  const currentBalance = data.wallets
    .filter((w) => !w.archived)
    .reduce((a, w) => a + getWalletBalance(w.id, data.transactions, data.wallets), 0);

  const months: CashFlowForecast["months"] = [];
  let runningBalance = currentBalance;
  for (let i = 1; i <= 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = new Intl.DateTimeFormat("id-ID", { month: "short", year: "numeric" }).format(d);
    runningBalance = runningBalance + monthlyAvgIncome - monthlyAvgExpense;
    const warning = runningBalance < 0 ? `Saldo diproyeksi minus` : undefined;
    months.push({
      monthKey: mk,
      label,
      projectedIncome: monthlyAvgIncome,
      projectedExpense: monthlyAvgExpense,
      projectedBalance: runningBalance,
      warning,
    });
  }

  return {
    months,
    currentBalance,
    monthlyAvgIncome,
    monthlyAvgExpense,
  };
}

// === WHAT-IF SIMULATOR ===
export interface WhatIfResult {
  canAfford: boolean;
  newBalance: number;
  monthsToAfford: number | null;
  recommendation: string;
  breakdown: string;
}

export function simulateWhatIf(
  data: AppData,
  itemName: string,
  itemCost: number,
  timeframeMonths: number = 1
): WhatIfResult {
  const currentBalance = data.wallets
    .filter((w) => !w.archived)
    .reduce((a, w) => a + getWalletBalance(w.id, data.transactions, data.wallets), 0);

  const now = new Date();
  let totalIncome = 0, totalExpense = 0;
  for (let i = 0; i < 3; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    for (const t of data.transactions) {
      if (t.type === "transfer") continue;
      if (getMonthKey(t.date) !== mk) continue;
      if (t.type === "income") totalIncome += t.amount;
      else totalExpense += t.amount;
    }
  }
  const monthlySavings = (totalIncome - totalExpense) / 3;

  if (currentBalance >= itemCost) {
    return {
      canAfford: true,
      newBalance: currentBalance - itemCost,
      monthsToAfford: 0,
      recommendation: `Anda bisa beli ${itemName} sekarang! Saldo setelah beli: ${formatCurrency(currentBalance - itemCost)}`,
      breakdown: `Saldo: ${formatCurrency(currentBalance)} - ${formatCurrency(itemCost)} = ${formatCurrency(currentBalance - itemCost)}`,
    };
  }

  const shortfall = itemCost - currentBalance;
  if (monthlySavings <= 0) {
    return {
      canAfford: false,
      newBalance: currentBalance,
      monthsToAfford: null,
      recommendation: `Belum bisa beli ${itemName}. Savings rate bulanan negatif — perbaiki pengeluaran dulu.`,
      breakdown: `Kekurangan: ${formatCurrency(shortfall)}, savings: ${formatCurrency(monthlySavings)}/bln`,
    };
  }

  const monthsNeeded = Math.ceil(shortfall / monthlySavings);
  if (monthsNeeded > 12) {
    return {
      canAfford: false,
      newBalance: currentBalance,
      monthsToAfford: monthsNeeded,
      recommendation: `${itemName} terlalu mahal. Butuh ${monthsNeeded} bulan nabung (${formatCurrency(monthlySavings)}/bln).`,
      breakdown: `Kekurangan: ${formatCurrency(shortfall)}, estimasi ${monthsNeeded} bulan`,
    };
  }

  return {
    canAfford: true,
    newBalance: currentBalance + monthlySavings * monthsNeeded - itemCost,
    monthsToAfford: monthsNeeded,
    recommendation: `Bisa beli ${itemName} dalam ${monthsNeeded} bulan dengan savings ${formatCurrency(monthlySavings)}/bln.`,
    breakdown: `Saldo: ${formatCurrency(currentBalance)} + (${formatCurrency(monthlySavings)} x ${monthsNeeded} bln) - ${formatCurrency(itemCost)} = ${formatCurrency(currentBalance + monthlySavings * monthsNeeded - itemCost)}`,
  };
}

// === NET WORTH TRACKER ===
export interface NetWorthData {
  aset: {
    wallets: number;
    savings: number;
    investments: number;
    receivables: number;
    totalAset: number;
  };
  kewajiban: {
    payables: number;
    totalKewajiban: number;
  };
  netWorth: number;
  history: { monthKey: string; label: string; netWorth: number }[];
}

export function computeNetWorth(data: AppData): NetWorthData {
  const walletsTotal = data.wallets
    .filter((w) => !w.archived)
    .reduce((a, w) => a + getWalletBalance(w.id, data.transactions, data.wallets), 0);

  const savingsTotal = data.savingsGoals
    .filter((g) => !g.archived)
    .reduce((a, g) => a + g.currentAmount, 0);

  const investmentAcc = data.coa.filter((c) =>
    ["coa-1-1400", "coa-1-1401", "coa-1-1402", "coa-1-1403"].includes(c.id)
  );
  let investmentsTotal = 0;
  for (const t of data.transactions) {
    if (t.type !== "income") continue;
    if (!investmentAcc.some((a) => a.id === t.coaId)) continue;
    investmentsTotal += t.amount;
  }
  for (const t of data.transactions) {
    if (t.type !== "expense") continue;
    if (!investmentAcc.some((a) => a.id === t.coaId)) continue;
    investmentsTotal -= t.amount;
  }

  const receivablesTotal = data.debts
    .filter((d) => d.type === "receivable" && d.status !== "paid")
    .reduce((a, d) => a + (d.amount - d.paidAmount), 0);

  const totalAset = walletsTotal + savingsTotal + investmentsTotal + receivablesTotal;
  const totalKewajiban = data.debts
    .filter((d) => d.type === "payable" && d.status !== "paid")
    .reduce((a, d) => a + (d.amount - d.paidAmount), 0);

  const netWorth = totalAset - totalKewajiban;

  const now = new Date();
  const history: { monthKey: string; label: string; netWorth: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const label = new Intl.DateTimeFormat("id-ID", { month: "short" }).format(d);
    const endOfMonth = `${mk}-${new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate()}`;
    let monthWallets = 0;
    for (const w of data.wallets.filter((w) => !w.archived)) {
      let bal = w.initialBalance;
      for (const t of data.transactions) {
        if (t.date > endOfMonth) continue;
        if (t.walletId === w.id) {
          if (t.type === "income") bal += t.amount;
          else if (t.type === "expense") bal -= t.amount;
          else if (t.type === "transfer") bal -= t.amount;
        } else if (t.type === "transfer" && t.transferToWalletId === w.id) {
          bal += t.amount;
        }
      }
      monthWallets += bal;
    }
    history.push({
      monthKey: mk,
      label,
      netWorth: monthWallets + savingsTotal + investmentsTotal + receivablesTotal - totalKewajiban,
    });
  }

  return {
    aset: {
      wallets: walletsTotal,
      savings: savingsTotal,
      investments: investmentsTotal,
      receivables: receivablesTotal,
      totalAset,
    },
    kewajiban: {
      payables: totalKewajiban,
      totalKewajiban,
    },
    netWorth,
    history,
  };
}

// === LOAN CALCULATOR ===
export interface LoanCalc {
  principal: number;
  annualRate: number;
  years: number;
  monthlyPayment: number;
  totalPayment: number;
  totalInterest: number;
  amortizationSchedule: { month: number; payment: number; interest: number; principal: number; balance: number }[];
}

export function calculateLoan(
  principal: number,
  annualRate: number,
  years: number
): LoanCalc {
  const monthlyRate = annualRate / 100 / 12;
  const months = years * 12;
  if (monthlyRate === 0) {
    const monthlyPayment = principal / months;
    return {
      principal,
      annualRate,
      years,
      monthlyPayment,
      totalPayment: principal,
      totalInterest: 0,
      amortizationSchedule: [],
    };
  }
  const monthlyPayment =
    (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
    (Math.pow(1 + monthlyRate, months) - 1);
  const totalPayment = monthlyPayment * months;
  const totalInterest = totalPayment - principal;

  const schedule: LoanCalc["amortizationSchedule"] = [];
  let balance = principal;
  for (let m = 1; m <= Math.min(12, months); m++) {
    const interest = balance * monthlyRate;
    const principalPay = monthlyPayment - interest;
    balance -= principalPay;
    schedule.push({
      month: m,
      payment: monthlyPayment,
      interest,
      principal: principalPay,
      balance: Math.max(0, balance),
    });
  }

  return {
    principal,
    annualRate,
    years,
    monthlyPayment,
    totalPayment,
    totalInterest,
    amortizationSchedule: schedule,
  };
}
