// Data default: COA Full Pro (8 akun induk + sub-akun), 7 dompet Indonesia, settings default
import type {
  COAAccount,
  Wallet,
  Settings,
  AppData,
  Transaction,
  Budget,
  SavingsGoal,
  RecurringTransaction,
  AppNotification,
} from "./types";

// === COA DEFAULT: FULL PRO ===
// 8 akun induk standar akuntansi + sub-akun
// Format kode: <akun-induk>-<sub-akun>. Contoh "1-1001" = Aset > Kas

function makeCOA(
  code: string,
  name: string,
  type: COAAccount["type"],
  parentId: string | null = null,
  isDefault = true
): COAAccount {
  return {
    id: `coa-${code}`,
    code,
    name,
    type,
    parentId,
    isDefault,
  };
}

export const DEFAULT_COA: COAAccount[] = [
  // === 1. ASET (Asset) ===
  makeCOA("1", "Aset", "asset", null),
  makeCOA("1-1000", "Kas & Setara Kas", "asset", "coa-1"),
  makeCOA("1-1001", "Kas Tunai", "asset", "coa-1-1000"),
  makeCOA("1-1002", "Saldo Bank", "asset", "coa-1-1000"),
  makeCOA("1-1003", "E-Wallet", "asset", "coa-1-1000"),
  makeCOA("1-1100", "Piutang Usaha", "asset", "coa-1"),
  makeCOA("1-1200", "Persediaan/Inventory", "asset", "coa-1"),
  makeCOA("1-1300", "Aset Tetap", "asset", "coa-1"),
  makeCOA("1-1301", "Peralatan", "asset", "coa-1-1300"),
  makeCOA("1-1302", "Kendaraan", "asset", "coa-1-1300"),
  makeCOA("1-1303", "Bangunan/Properti", "asset", "coa-1-1300"),
  makeCOA("1-1400", "Investasi", "asset", "coa-1"),
  makeCOA("1-1401", "Reksadana", "asset", "coa-1-1400"),
  makeCOA("1-1402", "Saham", "asset", "coa-1-1400"),
  makeCOA("1-1403", "Deposito", "asset", "coa-1-1400"),

  // === 2. KEWAJIBAN (Liability) ===
  makeCOA("2", "Kewajiban", "liability", null),
  makeCOA("2-1000", "Utang Usaha", "liability", "coa-2"),
  makeCOA("2-1100", "Utang Bank/Cicilan", "liability", "coa-2"),
  makeCOA("2-1101", "Kartu Kredit", "liability", "coa-2-1100"),
  makeCOA("2-1102", "KPA/ Mortgage", "liability", "coa-2-1100"),
  makeCOA("2-1103", "Cicilan Kendaraan", "liability", "coa-2-1100"),
  makeCOA("2-1200", "Utang Pajak", "liability", "coa-2"),

  // === 3. EKUITAS (Equity) ===
  makeCOA("3", "Ekuitas", "equity", null),
  makeCOA("3-1000", "Saldo Laba Ditahan", "equity", "coa-3"),
  makeCOA("3-1100", "Laba Tahun Berjalan", "equity", "coa-3"),

  // === 4. MODAL (Capital - untuk UMKM) ===
  makeCOA("4", "Modal", "capital", null),
  makeCOA("4-1000", "Modal Disetor", "capital", "coa-4"),
  makeCOA("4-1100", "Modal Tambahan", "capital", "coa-4"),

  // === 5. PENDAPATAN (Income) ===
  makeCOA("5", "Pendapatan", "income", null),
  makeCOA("5-1000", "Pendapatan Operasional", "income", "coa-5"),
  makeCOA("5-1001", "Penjualan", "income", "coa-5-1000"),
  makeCOA("5-1002", "Jasa/Service", "income", "coa-5-1000"),
  makeCOA("5-1100", "Gaji/Upah", "income", "coa-5"),
  makeCOA("5-1200", "Bonus & Insentif", "income", "coa-5"),
  makeCOA("5-1300", "Pendapatan Investasi", "income", "coa-5"),
  makeCOA("5-1301", "Dividen", "income", "coa-5-1300"),
  makeCOA("5-1302", "Bunga", "income", "coa-5-1300"),
  makeCOA("5-1303", "Capital Gain", "income", "coa-5-1300"),

  // === 6. PENDAPATAN LAIN ===
  makeCOA("6", "Pendapatan Lain", "other_income", null),
  makeCOA("6-1000", "Hadiah", "other_income", "coa-6"),
  makeCOA("6-1100", "Penjualan Aset", "other_income", "coa-6"),
  makeCOA("6-1200", "Refund/Reimburse", "other_income", "coa-6"),

  // === 7. BEBAN (Expense) ===
  makeCOA("7", "Beban", "expense", null),
  makeCOA("7-1000", "Beban Pokok", "expense", "coa-7"),
  makeCOA("7-1001", "Pembelian Stok", "expense", "coa-7-1000"),
  makeCOA("7-1002", "HPP", "expense", "coa-7-1000"),

  // === 8. BEBAN OPERASIONAL ===
  makeCOA("8", "Beban Operasional", "operating_expense", null),
  makeCOA("8-1000", "Makanan & Minuman", "operating_expense", "coa-8"),
  makeCOA("8-1001", "Makan di Luar", "operating_expense", "coa-8-1000"),
  makeCOA("8-1002", "Groceries", "operating_expense", "coa-8-1000"),
  makeCOA("8-1100", "Transportasi", "operating_expense", "coa-8"),
  makeCOA("8-1101", "Bensin/BBM", "operating_expense", "coa-8-1100"),
  makeCOA("8-1102", "Parkir & Tol", "operating_expense", "coa-8-1100"),
  makeCOA("8-1103", "Transportasi Online", "operating_expense", "coa-8-1100"),
  makeCOA("8-1200", "Belanja", "operating_expense", "coa-8"),
  makeCOA("8-1201", "Pakaian", "operating_expense", "coa-8-1200"),
  makeCOA("8-1202", "Kebutuhan Rumah", "operating_expense", "coa-8-1200"),
  makeCOA("8-1300", "Tagihan Rutin", "operating_expense", "coa-8"),
  makeCOA("8-1301", "Listrik", "operating_expense", "coa-8-1300"),
  makeCOA("8-1302", "Air", "operating_expense", "coa-8-1300"),
  makeCOA("8-1303", "Internet/Streaming", "operating_expense", "coa-8-1300"),
  makeCOA("8-1304", "Pulsa/Paket Data", "operating_expense", "coa-8-1300"),
  makeCOA("8-1400", "Hiburan", "operating_expense", "coa-8"),
  makeCOA("8-1500", "Kesehatan", "operating_expense", "coa-8"),
  makeCOA("8-1501", "Obat & Vitamin", "operating_expense", "coa-8-1500"),
  makeCOA("8-1502", "Dokter/Rumah Sakit", "operating_expense", "coa-8-1500"),
  makeCOA("8-1600", "Pendidikan", "operating_expense", "coa-8"),
  makeCOA("8-1700", "Sewa/Kontrakan", "operating_expense", "coa-8"),
  makeCOA("8-1800", "Asuransi", "operating_expense", "coa-8"),
  makeCOA("8-1900", "Donasi/Sedekah", "operating_expense", "coa-8"),
  makeCOA("8-2000", "Biaya Admin Bank", "operating_expense", "coa-8"),
  makeCOA("8-9000", "Beban Lain-lain", "operating_expense", "coa-8"),

  // === 9. PRIVE (Drawings - untuk UMKM/solo entrepreneur) ===
  makeCOA("9", "Prive", "drawings", null),
  makeCOA("9-1000", "Penarikan Pribadi", "drawings", "coa-9"),
];

// === DOMPET DEFAULT: SET INDONESIA ===
export function makeWallet(
  type: Wallet["type"],
  name: string,
  icon: string,
  color: string,
  initialBalance = 0
): Wallet {
  return {
    id: `wallet-${type}`,
    name,
    type,
    icon,
    color,
    initialBalance,
    minAlert: type === "cash" ? 50000 : type === "investment" ? undefined : 100000,
    createdAt: new Date().toISOString(),
  };
}

export const DEFAULT_WALLETS: Wallet[] = [
  makeWallet("cash", "Dompet Tunai", "💵", "#10b981", 500000),
  makeWallet("bank_bca", "BCA", "🏦", "#0a6cf5", 5000000),
  makeWallet("bank_mandiri", "Mandiri", "🏦", "#f59e0b", 0),
  makeWallet("ewallet_gopay", "GoPay", "📱", "#10b981", 0),
  makeWallet("ewallet_ovo", "OVO", "📱", "#8b5cf6", 0),
  makeWallet("ewallet_dana", "DANA", "📱", "#3b82f6", 0),
  makeWallet("ewallet_shopeepay", "ShopeePay", "🛍️", "#ef4444", 0),
  makeWallet("qris", "QRIS", "📱", "#0ea5e9", 0),
  makeWallet("investment", "Reksadana", "📈", "#ec4899", 0),
];

// === TAG POPULER untuk dropdown ===
export const POPULAR_TAGS = [
  "liburan",
  "urgent",
  "reimburse",
  "keluarga",
  "bisnis",
  "investasi",
  "hadiah",
  "kantor",
  "darurat",
];

export const DEFAULT_SETTINGS: Settings = {
  ownerName: "Saya",
  currency: "IDR",
  dailyReminderHour: 20,
  dailyReminderEnabled: true,
  budgetAlertThreshold: 80,
  notificationsEnabled: false, // default off sampat user opt-in
  // Keamanan
  biometricEnabled: false,
  pinEnabled: false,
  autoLockMinutes: 0,
  // Privacy & Security
  privacyBlurMode: false,
  largeTxConfirmation: true,
  largeTxThreshold: 1000000, // Rp 1jt
  // Sync
  syncEnabled: false,
  // Auto-backup
  autoBackupEnabled: false,
  // Tema
  themeMode: "auto",
  themeChoice: "navy-gold",
};

export function createInitialData(): AppData {
  return {
    schemaVersion: 4,
    wallets: DEFAULT_WALLETS,
    coa: DEFAULT_COA,
    transactions: [],
    budgets: [],
    savingsGoals: [],
    recurring: [],
    notifications: [],
    debts: [],
    activityLogs: [],
    settings: DEFAULT_SETTINGS,
  };
}

// === Helper akses cepat ===
export function getCOAAccount(coa: COAAccount[], id: string): COAAccount | undefined {
  return coa.find((c) => c.id === id);
}

export function getCOAAccountByCode(coa: COAAccount[], code: string): COAAccount | undefined {
  return coa.find((c) => c.code === code);
}

export function getWallet(wallets: Wallet[], id: string): Wallet | undefined {
  return wallets.find((w) => w.id === id);
}

// Ambil sub-akun di bawah akun induk
export function getSubAccounts(coa: COAAccount[], parentId: string): COAAccount[] {
  return coa
    .filter((c) => c.parentId === parentId && !c.archived)
    .sort((a, b) => a.code.localeCompare(b.code));
}

// Ambil akun induk (parentId === null)
export function getRootAccounts(coa: COAAccount[]): COAAccount[] {
  return coa
    .filter((c) => c.parentId === null && !c.archived)
    .sort((a, b) => a.code.localeCompare(b.code));
}

// Leaf accounts (tidak punya child) — yang bisa dipakai di form transaksi
export function getLeafAccounts(coa: COAAccount[]): COAAccount[] {
  return coa
    .filter((c) => !c.archived && c.parentId !== null)
    .sort((a, b) => a.code.localeCompare(b.code));
}
