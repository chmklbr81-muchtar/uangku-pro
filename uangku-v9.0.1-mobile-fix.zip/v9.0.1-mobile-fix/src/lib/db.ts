// [v9.0] Dead code — Prisma tidak dipakai (lihat storage.ts). Dihapus di v9.1
// atau di-enable saat migrasi ke SQLite native.
//
// Catatan audit: file ini menginstantiasi PrismaClient dengan pola globalForPrisma
// (template Next.js) tetapi TIDAK ada `import { db } from "@/lib/db"` di seluruh src/.
// Tidak ada direktori `prisma/` maupun `schema.prisma`. Script `db:*` di package.json
// akan fail bila dijalankan. File dibiarkan agar tidak break import path yang mungkin
// masih dirujuk tooling; akan di-remove bersama dependency `@prisma/client`+`prisma`
// pada v9.1.
/* eslint-disable @typescript-eslint/no-var-requires */
import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ["query"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db;
