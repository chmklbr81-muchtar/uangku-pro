// Activity Log & Privacy Security helpers (v8.1 — upgraded to Web Crypto AES-GCM + PBKDF2)
import type { AppData, ActivityLog, ActivityType, Settings } from "./types";
import { genId } from "./finance";

// === Activity Log ===
// Side-effect free: caller is responsible for persisting returned AppData.
export function addActivityLog(
  data: AppData,
  type: ActivityType,
  description: string,
  metadata?: Record<string, unknown>
): AppData {
  const log: ActivityLog = {
    id: genId(),
    type,
    description,
    timestamp: new Date().toISOString(),
    metadata,
  };
  const logs = [log, ...(data.activityLogs ?? [])].slice(0, 200);
  return { ...data, activityLogs: logs };
}

// Convenience: produce a new AppData with the log appended, without mutating input.
// Use this in React setState callbacks: setData(d => logActivity(d, "tx_add", "..."))
export function logActivity(
  data: AppData,
  type: ActivityType,
  description: string,
  metadata?: Record<string, unknown>
): AppData {
  return addActivityLog(data, type, description, metadata);
}

// === Encrypted Backup — Web Crypto AES-GCM (v8.1) ===
// Format: "UANGKU-ENC-V2\n<salt_hex>:<iv_hex>:<base64_ciphertext>"
// - salt: 16 bytes random (PBKDF2)
// - iv: 12 bytes random (AES-GCM nonce)
// - key: PBKDF2-SHA256, 150k iterations, 256-bit
// Backward-compat: still reads V1 (XOR) for restore from older backups.

const V2_HEADER = "UANGKU-ENC-V2";
const V1_HEADER = "UANGKU-ENCRYPTED-V1";
const PBKDF2_ITERATIONS = 150_000;
const SALT_BYTES = 16;
const IV_BYTES = 12;

async function deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveKey"]
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt as unknown as BufferSource,
      iterations: PBKDF2_ITERATIONS,
      hash: "SHA-256",
    },
    baseKey,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

function bufToHex(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let out = "";
  for (let i = 0; i < bytes.length; i++) out += bytes[i].toString(16).padStart(2, "0");
  return out;
}

function hexToBuf(hex: string): Uint8Array {
  const arr = new Uint8Array(hex.length / 2);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return arr;
}

function bufToBase64(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
}

function base64ToBuf(b64: string): Uint8Array {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export async function createEncryptedBackup(
  data: AppData,
  password: string
): Promise<Blob> {
  const json = JSON.stringify(data);
  const enc = new TextEncoder();
  const plaintext = enc.encode(json);

  const salt = crypto.getRandomValues(new Uint8Array(SALT_BYTES));
  const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
  const key = await deriveKey(password, salt);

  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    plaintext
  );

  const payload = `${V2_HEADER}\n${bufToHex(salt)}:${bufToHex(iv)}:${bufToBase64(ciphertext)}`;
  return new Blob([payload], { type: "application/octet-stream" });
}

export async function decryptBackup(
  encryptedText: string,
  password: string
): Promise<AppData | null> {
  // [v9.0 fix] C3: hanya menerima file .enc yang dibuat oleh UangkuPro (V1 atau V2).
  // Plaintext JSON fallback dihapus total — sebelumnya attacker bisa restore
  // { transactions: [...], settings: { supabaseUrl: attacker, ... } } tanpa password.
  const startsWithV2 = encryptedText.startsWith(V2_HEADER + "\n");
  const startsWithV1 = encryptedText.startsWith(V1_HEADER + "\n");
  if (!startsWithV2 && !startsWithV1) {
    // Refuse input yang tidak diawali header resmi UangkuPro.
    throw new Error(
      "Format backup tidak dikenali. Hanya file .enc yang dibuat oleh UangkuPro yang didukung."
    );
  }
  try {
    if (startsWithV2) {
      const payload = encryptedText.slice((V2_HEADER + "\n").length);
      const [saltHex, ivHex, b64] = payload.split(":");
      if (!saltHex || !ivHex || !b64) throw new Error("Format V2 rusak");
      const salt = hexToBuf(saltHex);
      const iv = hexToBuf(ivHex);
      const ciphertext = base64ToBuf(b64);
      const key = await deriveKey(password, salt);
      const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: iv as unknown as BufferSource },
        key,
        ciphertext as unknown as BufferSource
      );
      const json = new TextDecoder().decode(plaintext);
      const data = JSON.parse(json) as AppData;
      if (!data.transactions || !Array.isArray(data.transactions)) {
        throw new Error("Data hasil dekripsi tidak valid");
      }
      return data;
    }
    // Legacy V1 (XOR cipher) — backward-compat for older backups
    const legacy = encryptedText.slice((V1_HEADER + "\n").length);
    const text = await xorLegacyDecrypt(legacy, password);
    const data = JSON.parse(text) as AppData;
    if (!data.transactions || !Array.isArray(data.transactions)) {
      throw new Error("Data hasil dekripsi tidak valid");
    }
    return data;
  } catch {
    return null;
  }
}

// Legacy V1 XOR decryptor (kept for backward-compat with v8.0 backups)
async function xorLegacyDecrypt(base64: string, password: string): Promise<string> {
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const encryptedBytes = Uint8Array.from(atob(base64), (c) => c.charCodeAt(0));
  const passwordBytes = encoder.encode(password);
  const result = new Uint8Array(encryptedBytes.length);
  for (let i = 0; i < encryptedBytes.length; i++) {
    result[i] = encryptedBytes[i] ^ passwordBytes[i % passwordBytes.length];
  }
  return decoder.decode(result);
}

// === Hash password (Web Crypto SHA-256, kept for legacy API) ===
// @deprecated v8.x — tidak dipakai, dihapus di v9.1
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode("uangku-salt-" + password);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return bufToHex(hashBuffer);
}

// === PIN hashing — PBKDF2-SHA256 (replaces simpleHash) ===
// Format: "pbkdf2$<iterations>$<salt_hex>$<hash_hex>"
// Returns a self-describing string so verification knows how to recompute.
export async function hashPin(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(SALT_BYTES));
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    { name: "PBKDF2" },
    false,
    ["deriveBits"]
  );
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: salt as unknown as BufferSource, iterations: PBKDF2_ITERATIONS, hash: "SHA-256" },
    baseKey,
    256
  );
  return `pbkdf2$${PBKDF2_ITERATIONS}$${bufToHex(salt)}$${bufToHex(bits)}`;
}

export async function verifyPin(
  password: string,
  stored: string,
  // [v9.0 fix] C4: callback dipanggil sekali setelah PIN lama (simpleHash 32-bit)
  // berhasil diverifikasi. Pemanggil wajib persist newHash ke storage agar migrasi
  // terjadi satu kali (lazy upgrade) — bukan re-hash tiap login.
  onUpgrade?: (newHash: string) => void
): Promise<boolean> {
  try {
    if (stored.startsWith("pbkdf2$")) {
      const [, iterStr, saltHex, hashHex] = stored.split("$");
      const iterations = parseInt(iterStr, 10);
      const salt = hexToBuf(saltHex);
      const enc = new TextEncoder();
      const baseKey = await crypto.subtle.importKey(
        "raw",
        enc.encode(password),
        { name: "PBKDF2" },
        false,
        ["deriveBits"]
      );
      const bits = await crypto.subtle.deriveBits(
        { name: "PBKDF2", salt: salt as unknown as BufferSource, iterations, hash: "SHA-256" },
        baseKey,
        256
      );
      return bufToHex(bits) === hashHex;
    }
    // Backward-compat: PIN lama (simpleHash 32-bit) di-upgrade ke PBKDF2 otomatis setelah verify berhasil.
    // simpleHash tetap rentan brute-force (2^32 entropi), tapi upgrade lazy memastikan PIN
    // lama tidak selamanya tertinggal di format lemah — selesai migrasi setelah user login sekali.
    const legacyOk = simpleHash(password) === stored;
    if (legacyOk && onUpgrade) {
      const newHash = await hashPin(password);
      try {
        onUpgrade(newHash);
      } catch {
        // Pemanggil gagal persist — tidak fatal, verify tetap true.
      }
    }
    return legacyOk;
  } catch {
    return false;
  }
}

// simpleHash — retained ONLY for backward-compat with old PIN hashes.
// Not for new use. Use hashPin() + verifyPin() instead.
// @deprecated v8.x — tidak dipakai, dihapus di v9.1
export function simpleHash(input: string): string {
  let hash = 0;
  for (let i = 0; i < input.length; i++) {
    const chr = input.charCodeAt(i);
    hash = (hash << 5) - hash + chr;
    hash |= 0;
  }
  return String(hash);
}

// === Privacy blur toggle ===
export function togglePrivacyBlur(active: boolean) {
  if (typeof document === "undefined") return;
  if (active) {
    document.body.classList.add("privacy-blur");
  } else {
    document.body.classList.remove("privacy-blur");
  }
}

// === Large transaction confirmation check ===
export function shouldConfirmLargeTx(
  amount: number,
  settings: Settings
): boolean {
  return (
    settings.largeTxConfirmation &&
    amount >= settings.largeTxThreshold
  );
}
