// Logic keuangan: format, summary, MTD/YTD, drilldown, savings, budget usage
import type {
  AppData,
  Transaction,
  COAAccount,
  Wallet,
  Budget,
  SavingsGoal,
  RecurringTransaction,
  DebtLoan,
} from "./types";

// === FORMAT ===
// [v9.0 fix] L-x: currency precision helper. Semua akumulasi floating-point
// di-bulatkan ke 2 desimal (Math.round(x*100)/100) untuk hindari rounding drift
// (mis. 0.1+0.2 = 0.30000000000000004). Aman untuk IDR (integer rupiah, 0 desimal)
// maupun valas USD/EUR/SGD/GBP/JPY.
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function formatCurrency(amount: number, currency = "IDR"): string {
  if (currency === "IDR") {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  }
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatCompact(amount: number): string {
  const abs = Math.abs(amount);
  const sign = amount < 0 ? "−" : "";
  if (abs >= 1_000_000_000) return `${sign}Rp ${(abs / 1_000_000_000).toFixed(1)} M`;
  if (abs >= 1_000_000) return `${sign}Rp ${(abs / 1_000_000).toFixed(1)} jt`;
  if (abs >= 1_000) return `${sign}Rp ${(abs / 1_000).toFixed(0)} rb`;
  return `${sign}${abs}`;
}

export function formatDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export function formatDateShort(iso: string): string {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      day: "2-digit",
      month: "short",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export function todayISO(): string {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export function getMonthKey(iso: string): string {
  return iso.slice(0, 7); // yyyy-mm
}

export function getYear(iso: string): number {
  return Number(iso.slice(0, 4));
}

export function getMonthLabel(monthKey: string): string {
  try {
    const [y, m] = monthKey.split("-").map(Number);
    return new Intl.DateTimeFormat("id-ID", {
      month: "long",
      year: "numeric",
    }).format(new Date(y, m - 1, 1));
  } catch {
    return monthKey;
  }
}

export function getMonthShortLabel(monthKey: string): string {
  try {
    const [y, m] = monthKey.split("-").map(Number);
    return new Intl.DateTimeFormat("id-ID", { month: "short" }).format(
      new Date(y, m - 1, 1)
    );
  } catch {
    return monthKey;
  }
}

// === RINGKASAN ===
export interface Summary {
  totalIncome: number;
  totalExpense: number;
  totalTransfer: number; // nilai transfer (asli, bukan ganda)
  balance: number;
  // MTD = Month-to-Date
  mtdIncome: number;
  mtdExpense: number;
  mtdBalance: number;
  mtdSavingsRate: number;
  // YTD = Year-to-Date
  ytdIncome: number;
  ytdExpense: number;
  ytdBalance: number;
  ytdSavingsRate: number;
}

export function computeSummary(
  txs: Transaction[],
  wallets: Wallet[],
  monthKey: string,
  year: number
): Summary {
  let totalIncome = 0,
    totalExpense = 0,
    totalTransfer = 0;
  let mtdIncome = 0,
    mtdExpense = 0;
  let ytdIncome = 0,
    ytdExpense = 0;

  for (const t of txs) {
    if (t.type === "transfer") {
      totalTransfer += t.amount;
      continue; // transfer tidak masuk income/expense
    }
    if (t.type === "income") {
      totalIncome += t.amount;
      if (getMonthKey(t.date) === monthKey) mtdIncome += t.amount;
      if (getYear(t.date) === year) ytdIncome += t.amount;
    } else {
      totalExpense += t.amount;
      if (getMonthKey(t.date) === monthKey) mtdExpense += t.amount;
      if (getYear(t.date) === year) ytdExpense += t.amount;
    }
  }

  // Saldo = saldo awal semua dompet + selisih income/expense
  const totalInitial = wallets
    .filter((w) => !w.archived)
    .reduce((a, w) => a + w.initialBalance, 0);
  const balance = totalInitial + totalIncome - totalExpense;

  const savingsRate = (income: number, expense: number) =>
    income > 0 ? ((income - expense) / income) * 100 : 0;

  // [v9.0 fix] L-x: round balance components to 2 decimals for currency precision.
  return {
    totalIncome: round2(totalIncome),
    totalExpense: round2(totalExpense),
    totalTransfer: round2(totalTransfer),
    balance: round2(balance),
    mtdIncome: round2(mtdIncome),
    mtdExpense: round2(mtdExpense),
    mtdBalance: round2(mtdIncome - mtdExpense),
    mtdSavingsRate: round2(savingsRate(mtdIncome, mtdExpense)),
    ytdIncome: round2(ytdIncome),
    ytdExpense: round2(ytdExpense),
    ytdBalance: round2(ytdIncome - ytdExpense),
    ytdSavingsRate: round2(savingsRate(ytdIncome, ytdExpense)),
  };
}

// Saldo per dompet
export function getWalletBalance(
  walletId: string,
  txs: Transaction[],
  wallets: Wallet[]
): number {
  const wallet = wallets.find((w) => w.id === walletId);
  if (!wallet) return 0;
  let bal = wallet.initialBalance;
  for (const t of txs) {
    if (t.walletId === walletId) {
      if (t.type === "income") bal += t.amount;
      else if (t.type === "expense") bal -= t.amount;
      // transfer: walletId = sumber, transferToWalletId = tujuan
      else if (t.type === "transfer") bal -= t.amount;
    } else if (t.type === "transfer" && t.transferToWalletId === walletId) {
      bal += t.amount;
    }
  }
  // [v9.0 fix] L-x: round to 2 decimals — hindari floating drift di display saldo.
  return round2(bal);
}

// === DRILLDOWN (sesuai permintaan user: klik bulan/tahun = keluar semua data) ===
export function getTransactionsForMonth(
  txs: Transaction[],
  monthKey: string
): Transaction[] {
  return txs
    .filter((t) => getMonthKey(t.date) === monthKey)
    .sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.createdAt.localeCompare(a.createdAt);
    });
}

export function getTransactionsForYear(
  txs: Transaction[],
  year: number
): Transaction[] {
  return txs
    .filter((t) => getYear(t.date) === year)
    .sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.createdAt.localeCompare(a.createdAt);
    });
}

// === MULTI-YEAR: ringkasan per bulan untuk line chart ===
export interface MonthlyPoint {
  monthKey: string;
  monthLabel: string;
  income: number;
  expense: number;
  balance: number;
  savingsRate: number;
}

export function getMonthlySeries(
  txs: Transaction[],
  year: number
): MonthlyPoint[] {
  const result: MonthlyPoint[] = [];
  for (let m = 0; m < 12; m++) {
    const monthKey = `${year}-${String(m + 1).padStart(2, "0")}`;
    let income = 0,
      expense = 0;
    for (const t of txs) {
      if (t.type === "transfer") continue;
      if (getMonthKey(t.date) !== monthKey) continue;
      if (t.type === "income") income += t.amount;
      else expense += t.amount;
    }
    result.push({
      monthKey,
      monthLabel: new Intl.DateTimeFormat("id-ID", { month: "short" }).format(
        new Date(year, m, 1)
      ),
      // [v9.0 fix] L-x: round to 2 decimals for currency precision.
      income: round2(income),
      expense: round2(expense),
      balance: round2(income - expense),
      savingsRate: round2(income > 0 ? ((income - expense) / income) * 100 : 0),
    });
  }
  return result;
}

// Rata-rata historis 12 bulan terakhir (untuk bar MTD vs avg)
export function getHistoricalAvg(txs: Transaction[], endMonthKey: string): number {
  const [y, m] = endMonthKey.split("-").map(Number);
  let total = 0;
  let count = 0;
  for (let i = 11; i >= 1; i--) {
    const d = new Date(y, m - 1 - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    let monthExpense = 0;
    for (const t of txs) {
      if (t.type !== "expense") continue;
      if (getMonthKey(t.date) === mk) monthExpense += t.amount;
    }
    if (monthExpense > 0) {
      total += monthExpense;
      count++;
    }
  }
  // [v9.0 fix] L-x: round average to 2 decimals — sebelumnya raw float division.
  return round2(count > 0 ? total / count : 0);
}

// === BUDGET USAGE ===
export interface BudgetUsage {
  budget: Budget;
  used: number;
  remaining: number;
  percent: number;
  coaName: string;
  coaCode: string;
}

export function getBudgetUsage(
  budgets: Budget[],
  txs: Transaction[],
  coa: COAAccount[],
  monthKey: string
): BudgetUsage[] {
  return budgets
    .filter((b) => b.monthKey === monthKey)
    .map((b) => {
      const account = coa.find((c) => c.id === b.coaId);
      // Hitung pemakaian: semua transaksi expense dengan coaId ini di bulan itu
      const used = txs
        .filter(
          (t) =>
            t.coaId === b.coaId &&
            getMonthKey(t.date) === monthKey &&
            (t.type === "expense" || t.type === "income")
        )
        .reduce((sum, t) => {
          if (t.type === "expense") return sum + t.amount;
          // jika budget untuk income akun, hitung masuk sebagai "tercapai"
          return sum + t.amount;
        }, 0);
      const percent = b.amount > 0 ? (used / b.amount) * 100 : 0;
      // [v9.0 fix] L-x: round used / remaining / percent to 2 decimals.
      return {
        budget: b,
        used: round2(used),
        remaining: round2(b.amount - used),
        percent: round2(percent),
        coaName: account?.name ?? "—",
        coaCode: account?.code ?? "",
      };
    })
    .sort((a, b) => b.percent - a.percent);
}

// === SAVINGS GOAL ===
export function getSavingsProgress(
  goal: SavingsGoal,
  txs: Transaction[],
  wallets: Wallet[]
): {
  percent: number;
  monthsRemaining: number | null;
  estimatedDate: string | null;
  monthlyContribution: number;
} {
  // Asumsi: kontribusi = semua income ke dompet sumber (jika diset)
  // atau lebih sederhana: perubahan currentAmount manual. Untuk simulasi:
  // kontribusi bulanan rata-rata = total income 3 bulan terakhir - total expense 3 bulan terakhir
  const now = new Date();
  let totalNet = 0;
  for (let i = 0; i < 3; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mk = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    for (const t of txs) {
      if (t.type === "transfer") continue;
      if (getMonthKey(t.date) !== mk) continue;
      if (t.type === "income") totalNet += t.amount;
      else totalNet -= t.amount;
    }
  }
  const monthlyContribution = totalNet / 3;
  const percent =
    goal.targetAmount > 0
      ? Math.min(100, (goal.currentAmount / goal.targetAmount) * 100)
      : 0;

  let monthsRemaining: number | null = null;
  let estimatedDate: string | null = null;
  const remaining = goal.targetAmount - goal.currentAmount;
  if (remaining > 0 && monthlyContribution > 0) {
    monthsRemaining = Math.ceil(remaining / monthlyContribution);
    const est = new Date(
      now.getFullYear(),
      now.getMonth() + monthsRemaining,
      1
    );
    estimatedDate = `${est.getFullYear()}-${String(est.getMonth() + 1).padStart(
      2,
      "0"
    )}-01`;
  }

  // [v9.0 fix] L-x: round contribution & percent to 2 decimals.
  return {
    percent: round2(percent),
    monthsRemaining,
    estimatedDate,
    monthlyContribution: round2(monthlyContribution),
  };
}

// === RECURRING: cek jadwal ===
export function getDueRecurring(
  recurring: RecurringTransaction[],
  untilDate: string
): RecurringTransaction[] {
  return recurring
    .filter((r) => !r.archived && r.nextRunDate <= untilDate)
    .sort((a, b) => a.nextRunDate.localeCompare(b.nextRunDate));
}

// === NOTIFIKASI LOGIC ===
// Tagihan jatuh tempo H-3 (cek dari transaksi recurring dengan type expense)
export function getUpcomingBills(
  recurring: RecurringTransaction[],
  daysAhead = 3
): RecurringTransaction[] {
  const now = new Date();
  const until = new Date(now.getTime() + daysAhead * 24 * 60 * 60 * 1000);
  const untilISO = `${until.getFullYear()}-${String(until.getMonth() + 1).padStart(
    2,
    "0"
  )}-${String(until.getDate()).padStart(2, "0")}`;
  return recurring
    .filter(
      (r) =>
        !r.archived &&
        r.type === "expense" &&
        r.nextRunDate <= untilISO &&
        r.nextRunDate >= todayISO()
    )
    .sort((a, b) => a.nextRunDate.localeCompare(b.nextRunDate));
}

// Saldo minimum dompet
export function getLowBalanceWallets(
  wallets: Wallet[],
  txs: Transaction[]
): Wallet[] {
  return wallets
    .filter((w) => !w.archived && w.minAlert !== undefined && w.minAlert > 0)
    .filter((w) => getWalletBalance(w.id, txs, wallets) < (w.minAlert ?? 0))
    .map((w) => ({
      ...w,
      // tag original wallet
    }));
}

// === KELOMPOK TRANSAKSI per tanggal ===
export function groupByDate(txs: Transaction[]): Record<string, Transaction[]> {
  const groups: Record<string, Transaction[]> = {};
  const sorted = [...txs].sort((a, b) => {
    if (a.date !== b.date) return b.date.localeCompare(a.date);
    return b.createdAt.localeCompare(a.createdAt);
  });
  for (const t of sorted) {
    if (!groups[t.date]) groups[t.date] = [];
    groups[t.date].push(t);
  }
  return groups;
}

// === Total per kategori untuk pie ===
export function sumByCOA(
  txs: Transaction[],
  type: "income" | "expense",
  monthKey?: string
): { coaId: string; total: number; count: number }[] {
  const map: Record<string, { total: number; count: number }> = {};
  for (const t of txs) {
    if (t.type !== type) continue;
    if (monthKey && getMonthKey(t.date) !== monthKey) continue;
    if (!map[t.coaId]) map[t.coaId] = { total: 0, count: 0 };
    map[t.coaId].total += t.amount;
    map[t.coaId].count += 1;
  }
  return Object.entries(map)
    .map(([coaId, v]) => ({ coaId, total: v.total, count: v.count }))
    .sort((a, b) => b.total - a.total);
}

// === Helpers ID generator ===
export function genId(): string {
  return (
    Date.now().toString(36) + Math.random().toString(36).slice(2, 10)
  );
}

// === Helpers akses cepat (wallet & COA) ===

export function getWallet(wallets: Wallet[], id: string): Wallet | undefined {
  return wallets.find((w) => w.id === id);
}

export function getCOAAccount(coa: COAAccount[], id: string): COAAccount | undefined {
  return coa.find((c) => c.id === id);
}

// === NERACA (Balance Sheet) ===
// Aset = Kewajiban + Ekuitas (rumus akuntansi dasar)
export interface BalanceSheet {
  assets: { account: COAAccount; balance: number }[];
  liabilities: { account: COAAccount; balance: number }[];
  equity: { account: COAAccount; balance: number }[];
  totalAssets: number;
  totalLiabilities: number;
  totalEquity: number;
  // L/R yang belum ditutup ke ekuitas
  netIncome: number;
  // Pembuktian: TotalAset harusnya = TotalKewajiban + TotalEkuitas + NetIncome
  balanced: boolean;
  difference: number;
}

export function computeBalanceSheet(
  data: AppData,
  untilDate: string
): BalanceSheet {
  const { transactions, wallets, coa } = data;
  // v8.1: map wallet type → specific asset sub-account (instead of always "1-1000" parent)
  // - cash → "1-1001" Kas Tunai
  // - bank_* → "1-1002" Saldo Bank
  // - ewallet_*, qris → "1-1003" E-Wallet
  // - investment → "1-1400" Investasi (parent, since investment wallets feed multiple sub-accounts)
  // [v9.0 fix] L-x: konfirmasi mapping v8.1 sudah benar (cash → 1-1001, bank → 1-1002,
  // e-wallet → 1-1003, investment → 1-1400). Tidak ada perubahan mapping; hanya verifikasi.
  const cashAccount = coa.find((c) => c.code === "1-1001");
  const bankAccount = coa.find((c) => c.code === "1-1002");
  const ewalletAccount = coa.find((c) => c.code === "1-1003");
  const investmentAccount = coa.find((c) => c.code === "1-1400");
  const fallbackKasAccount = coa.find((c) => c.code === "1-1000"); // legacy fallback
  const balances: Record<string, number> = {};

  // Helper: resolve which asset sub-account a wallet maps to
  function resolveWalletAssetAccount(walletType: string): COAAccount | undefined {
    if (walletType === "cash") return cashAccount ?? fallbackKasAccount;
    if (walletType.startsWith("bank_")) return bankAccount ?? fallbackKasAccount;
    if (walletType.startsWith("ewallet_") || walletType === "qris") return ewalletAccount ?? fallbackKasAccount;
    if (walletType === "investment") return investmentAccount ?? fallbackKasAccount;
    return fallbackKasAccount;
  }

  // Inisialisasi saldo akun aset dengan saldo awal dompet (per wallet type)
  for (const w of wallets) {
    if (w.archived) continue;
    const acc = resolveWalletAssetAccount(w.type);
    if (!acc) continue;
    if (!balances[acc.id]) balances[acc.id] = 0;
    balances[acc.id] += w.initialBalance;
  }

  // Iterasi semua transaksi sampai untilDate
  for (const t of transactions) {
    if (t.date > untilDate) continue;
    if (t.type === "transfer") continue; // transfer tidak menggerakkan posisi neraca
    const acc = coa.find((c) => c.id === t.coaId);
    if (!acc) continue;
    // Resolve wallet-side asset account for this transaction
    const wallet = wallets.find((w) => w.id === t.walletId);
    const walletAssetAcc = wallet ? resolveWalletAssetAccount(wallet.type) : undefined;
    if (t.type === "income") {
      // Income menambah saldo akun income (credit normal untuk akuntansi)
      if (!balances[acc.id]) balances[acc.id] = 0;
      balances[acc.id] += t.amount;
      // Juga menambah saldo akun aset (kas/bank/ewallet) yang dikaitkan dengan dompet transaksi
      if (walletAssetAcc) {
        if (!balances[walletAssetAcc.id]) balances[walletAssetAcc.id] = 0;
        balances[walletAssetAcc.id] += t.amount;
      }
    } else if (t.type === "expense") {
      // Expense menambah saldo akun expense (debit normal)
      if (!balances[acc.id]) balances[acc.id] = 0;
      balances[acc.id] += t.amount;
      // Berkurang dari akun aset terkait dompet
      if (walletAssetAcc) {
        if (!balances[walletAssetAcc.id]) balances[walletAssetAcc.id] = 0;
        balances[walletAssetAcc.id] -= t.amount;
      }
    }
  }

  // Bangun neraca
  const assets: { account: COAAccount; balance: number }[] = [];
  const liabilities: { account: COAAccount; balance: number }[] = [];
  const equity: { account: COAAccount; balance: number }[] = [];

  for (const acc of coa) {
    if (acc.archived) continue;
    if (acc.parentId === null) continue; // skip root, hanya leaf + sub-akun
    const bal = balances[acc.id] ?? 0;
    // [v9.0 fix] L-x: round per-account balance to 2 decimals.
    const balR = round2(bal);
    if (acc.type === "asset") assets.push({ account: acc, balance: balR });
    else if (acc.type === "liability") liabilities.push({ account: acc, balance: balR });
    else if (acc.type === "equity" || acc.type === "capital") equity.push({ account: acc, balance: balR });
  }

  // Hitung Net Income = Total Income - Total Expense (untuk akun income/expense/operating_expense/other_income)
  let netIncome = 0;
  for (const acc of coa) {
    if (acc.archived) continue;
    const bal = balances[acc.id] ?? 0;
    if (acc.type === "income" || acc.type === "other_income") netIncome += bal;
    else if (acc.type === "expense" || acc.type === "operating_expense") netIncome -= bal;
  }

  const totalAssets = assets.reduce((a, x) => a + x.balance, 0);
  const totalLiabilities = liabilities.reduce((a, x) => a + x.balance, 0);
  const totalEquity = equity.reduce((a, x) => a + x.balance, 0);
  const difference = totalAssets - (totalLiabilities + totalEquity + netIncome);

  // [v9.0 fix] L-x: round totals & netIncome to 2 decimals.
  return {
    assets,
    liabilities,
    equity,
    totalAssets: round2(totalAssets),
    totalLiabilities: round2(totalLiabilities),
    totalEquity: round2(totalEquity),
    netIncome: round2(netIncome),
    balanced: Math.abs(difference) < 0.01, // [v9.0 fix] L-x: threshold tight (2-decimal precision)
    difference: round2(difference),
  };
}

// === LABA RUGI (Income Statement) ===
export interface IncomeStatement {
  income: { account: COAAccount; balance: number }[];
  expenses: { account: COAAccount; balance: number }[];
  totalIncome: number;
  totalExpense: number;
  netIncome: number;
  // Untuk periode tertentu
  periodLabel: string;
}

export function computeIncomeStatement(
  data: AppData,
  startDate: string,
  endDate: string,
  periodLabel: string
): IncomeStatement {
  const { transactions, coa } = data;
  const balances: Record<string, number> = {};

  for (const t of transactions) {
    if (t.date < startDate || t.date > endDate) continue;
    if (t.type === "transfer") continue;
    const acc = coa.find((c) => c.id === t.coaId);
    if (!acc) continue;
    if (t.type === "income" && (acc.type === "income" || acc.type === "other_income")) {
      if (!balances[acc.id]) balances[acc.id] = 0;
      balances[acc.id] += t.amount;
    } else if (t.type === "expense" && (acc.type === "expense" || acc.type === "operating_expense")) {
      if (!balances[acc.id]) balances[acc.id] = 0;
      balances[acc.id] += t.amount;
    }
  }

  const income: { account: COAAccount; balance: number }[] = [];
  const expenses: { account: COAAccount; balance: number }[] = [];
  for (const acc of coa) {
    if (acc.archived) continue;
    if (acc.parentId === null) continue;
    const bal = balances[acc.id] ?? 0;
    if (bal === 0) continue;
    // [v9.0 fix] L-x: round per-account balance to 2 decimals.
    const balR = round2(bal);
    if (acc.type === "income" || acc.type === "other_income") income.push({ account: acc, balance: balR });
    else if (acc.type === "expense" || acc.type === "operating_expense") expenses.push({ account: acc, balance: balR });
  }

  income.sort((a, b) => b.balance - a.balance);
  expenses.sort((a, b) => b.balance - a.balance);
  const totalIncome = income.reduce((a, x) => a + x.balance, 0);
  const totalExpense = expenses.reduce((a, x) => a + x.balance, 0);

  // [v9.0 fix] L-x: round totals & netIncome to 2 decimals.
  return {
    income,
    expenses,
    totalIncome: round2(totalIncome),
    totalExpense: round2(totalExpense),
    netIncome: round2(totalIncome - totalExpense),
    periodLabel,
  };
}

// === DEBT TRACKER ===
export interface DebtSummary {
  totalReceivable: number; // total piutang (orang utang ke saya)
  totalPayable: number; // total utang (saya utang ke orang)
  totalPaidReceivable: number;
  totalPaidPayable: number;
  outstandingReceivable: number;
  outstandingPayable: number;
}

export function computeDebtSummary(debts: DebtLoan[]): DebtSummary {
  const active = debts.filter((d) => d.status !== "paid");
  let totalReceivable = 0, totalPayable = 0;
  let totalPaidReceivable = 0, totalPaidPayable = 0;
  let outstandingReceivable = 0, outstandingPayable = 0;
  for (const d of active) {
    if (d.type === "receivable") {
      totalReceivable += d.amount;
      totalPaidReceivable += d.paidAmount;
      outstandingReceivable += d.amount - d.paidAmount;
    } else {
      totalPayable += d.amount;
      totalPaidPayable += d.paidAmount;
      outstandingPayable += d.amount - d.paidAmount;
    }
  }
  return {
    totalReceivable: round2(totalReceivable),
    totalPayable: round2(totalPayable),
    totalPaidReceivable: round2(totalPaidReceivable),
    totalPaidPayable: round2(totalPaidPayable),
    outstandingReceivable: round2(outstandingReceivable),
    outstandingPayable: round2(outstandingPayable),
  };
}

// Palet warna chart
export const CHART_COLORS = [
  "#a855f7", // violet-500
  "#ec4899", // pink-500
  "#f59e0b", // amber-500
  "#10b981", // emerald-500
  "#06b6d4", // cyan-500
  "#ef4444", // red-500
  "#8b5cf6", // violet-400
  "#14b8a6", // teal-500
  "#f97316", // orange-500
  "#3b82f6", // blue-500
];
