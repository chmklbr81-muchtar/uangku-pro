"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { type AppData } from "@/lib/types";
import {
  exportToExcel,
  DEFAULT_EXPORT_OPTIONS,
  type ExportOptions,
} from "@/lib/excel-export";
import { todayISO } from "@/lib/finance";
import { Download, Loader2, FileSpreadsheet } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  data: AppData;
}

export function ExportDialog({ open, onOpenChange, data }: ExportDialogProps) {
  const [options, setOptions] = useState<ExportOptions>({
    ...DEFAULT_EXPORT_OPTIONS,
    rangeStart: `${new Date().getFullYear()}-01-01`,
    rangeEnd: todayISO(),
  });
  const [loading, setLoading] = useState(false);

  async function handleExport() {
    setLoading(true);
    try {
      const filename = await exportToExcel(data, options);
      toast.success(`Berhasil diekspor: ${filename}`);
      onOpenChange(false);
    } catch (e) {
      console.error(e);
      toast.error("Gagal ekspor Excel. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[440px] max-h-[92vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-violet-400" />
            Ekspor ke Excel
          </DialogTitle>
          <DialogDescription>
            Pilih periode & sheet yang ingin diekspor ke file Excel profesional.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Range tanggal */}
          <div className="space-y-1.5">
            <Label>Periode</Label>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">
                  Dari
                </label>
                <Input
                  type="date"
                  value={options.rangeStart}
                  onChange={(e) =>
                    setOptions((o) => ({ ...o, rangeStart: e.target.value }))
                  }
                  className="bg-input/50 border-border/50"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">
                  Sampai
                </label>
                <Input
                  type="date"
                  value={options.rangeEnd}
                  onChange={(e) =>
                    setOptions((o) => ({ ...o, rangeEnd: e.target.value }))
                  }
                  className="bg-input/50 border-border/50"
                />
              </div>
            </div>
            {/* Quick presets */}
            <div className="mt-2 flex flex-wrap gap-1.5">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  const d = new Date();
                  setOptions((o) => ({
                    ...o,
                    rangeStart: `${d.getFullYear()}-${String(
                      d.getMonth() + 1
                    ).padStart(2, "0")}-01`,
                    rangeEnd: todayISO(),
                  }));
                }}
                className="border-border/50 h-7 text-xs"
              >
                Bulan Ini
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  setOptions((o) => ({
                    ...o,
                    rangeStart: `${new Date().getFullYear()}-01-01`,
                    rangeEnd: todayISO(),
                  }));
                }}
                className="border-border/50 h-7 text-xs"
              >
                Tahun Ini (YTD)
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  const d = new Date();
                  setOptions((o) => ({
                    ...o,
                    rangeStart: `${d.getFullYear()}-01-01`,
                    rangeEnd: `${d.getFullYear()}-12-31`,
                  }));
                }}
                className="border-border/50 h-7 text-xs"
              >
                Sepanjang Tahun
              </Button>
            </div>
          </div>

          {/* Pilihan sheet */}
          <div className="space-y-2">
            <Label>Sheet yang diikutsertakan</Label>
            <div className="space-y-2">
              {/* [v9.0 fix] M-x: typed ExportOptionKey — sebelumnya `(options as any)[s.key]`. */}
              {([
                {
                  key: "includeDashboard",
                  label: "📊 Dashboard",
                  desc: "Ringkasan + saldo per dompet",
                },
                {
                  key: "includeTransactions",
                  label: "📋 Transaksi",
                  desc: "Daftar lengkap semua transaksi",
                },
                {
                  key: "includeMonthlyReport",
                  label: "📅 Laporan Bulanan",
                  desc: "Income/expense/selisih per bulan",
                },
                {
                  key: "includeYearlyReport",
                  label: "📆 Laporan Tahunan",
                  desc: "Multi-tahun + perubahan YoY",
                },
                {
                  key: "includeCOA",
                  label: "🗂️ COA",
                  desc: "Chart of Account lengkap",
                },
                {
                  key: "includeBudget",
                  label: "💰 Anggaran",
                  desc: "Penggunaan anggaran per kategori",
                },
                {
                  key: "includeSavings",
                  label: "🎯 Savings Goals",
                  desc: "Target tabungan & progress",
                },
              ] as { key: keyof ExportOptions; label: string; desc: string }[]).map((s) => (
                <label
                  key={s.key}
                  className="flex items-start gap-2 cursor-pointer rounded-lg border border-border/50 p-2.5 hover:bg-accent transition-colors"
                >
                  <Checkbox
                    checked={options[s.key] as boolean}
                    onCheckedChange={(v) =>
                      setOptions((o) => ({ ...o, [s.key]: v }))
                    }
                  />
                  <div className="flex-1">
                    <p className="text-sm font-medium">{s.label}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {s.desc}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Info preview */}
          <div className="rounded-lg bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
            💡 File Excel akan punya cover berdesain, header berwarna, freeze
            panes, currency format, & alternating row untuk tampilan
            profesional.
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-border/50"
            disabled={loading}
          >
            Batal
          </Button>
          <Button
            onClick={handleExport}
            disabled={loading}
            className="bg-emerald-600 hover:bg-emerald-700 text-white border-0"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
            ) : (
              <Download className="h-4 w-4 mr-1" />
            )}
            {loading ? "Menyiapkan..." : "Download Excel"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
