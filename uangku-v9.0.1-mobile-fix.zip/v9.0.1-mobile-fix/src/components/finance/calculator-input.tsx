"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calculator, Plus, Minus, Equal, X, Delete } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatCurrency } from "@/lib/finance";

interface CalculatorInputProps {
  onResult: (total: number) => void;
}

// Kalkulator mini untuk split bill: ketik beberapa angka dengan operasi +, hasil auto-isi ke field jumlah
export function CalculatorInput({ onResult }: CalculatorInputProps) {
  const [open, setOpen] = useState(false);
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState<number | null>(null);

  function append(val: string) {
    setExpression((prev) => prev + val);
    evaluate();
  }

  function clear() {
    setExpression("");
    setResult(null);
  }

  function evaluate() {
    try {
      const expr = expression.replace(/[^0-9+\-*/.() ]/g, "");
      if (!expr) {
        setResult(null);
        return;
      }
      // eslint-disable-next-line no-new-func
      const r = Function(`"use strict"; return (${expr})`)();
      if (typeof r === "number" && !isNaN(r) && isFinite(r)) {
        setResult(r);
      } else {
        setResult(null);
      }
    } catch {
      setResult(null);
    }
  }

  function applyResult() {
    if (result !== null && result > 0) {
      onResult(Math.round(result));
      setOpen(false);
      setExpression("");
      setResult(null);
    }
  }

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex items-center gap-1.5 rounded-lg bg-muted/40 px-2.5 py-1.5 text-xs text-muted-foreground hover:bg-accent transition-colors w-full"
      >
        <Calculator className="h-3.5 w-3.5" />
        <span>Kalkulator split bill</span>
        <span className="ml-auto text-[10px]">+</span>
      </button>
    );
  }

  return (
    <div className="rounded-xl glass border border-border/50 p-3 animate-card-in">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <Calculator className="h-3.5 w-3.5 text-gold" />
          <span className="text-xs font-semibold">Kalkulator</span>
        </div>
        <button
          type="button"
          onClick={() => {
            setOpen(false);
            setExpression("");
            setResult(null);
          }}
          className="text-muted-foreground hover:text-foreground"
          aria-label="Tutup"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      <Input
        value={expression}
        onChange={(e) => {
          setExpression(e.target.value.replace(/[^0-9+\-*/.() ]/g, ""));
          evaluate();
        }}
        placeholder="50000+7500+3000"
        className="bg-input/50 border-border/50 text-base font-mono tabular-nums"
        autoFocus
      />

      {result !== null && (
        <p className="mt-1.5 text-xs text-muted-foreground">
          = <span className="font-bold text-gold tabular-nums">{formatCurrency(result)}</span>
        </p>
      )}

      {/* Tombol cepat */}
      <div className="mt-2 grid grid-cols-4 gap-1">
        {["7", "8", "9", "+"].map((k) => (
          <CalcKey key={k} value={k} onClick={() => append(k)} />
        ))}
        {["4", "5", "6", "-"].map((k) => (
          <CalcKey key={k} value={k} onClick={() => append(k)} />
        ))}
        {["1", "2", "3", "*"].map((k) => (
          <CalcKey key={k} value={k} onClick={() => append(k)} />
        ))}
        {["0", ".", "/", "("].map((k) => (
          <CalcKey key={k} value={k} onClick={() => append(k)} />
        ))}
      </div>

      <div className="mt-2 grid grid-cols-3 gap-1">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={clear}
          className="border-border/50 h-9 text-xs"
        >
          <Delete className="h-3.5 w-3.5" />
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setExpression((p) => p.slice(0, -1))}
          className="border-border/50 h-9 text-xs"
        >
          ⌫
        </Button>
        <Button
          type="button"
          size="sm"
          onClick={applyResult}
          disabled={result === null || result <= 0}
          className="gradient-gold text-primary-foreground border-0 h-9 text-xs"
        >
          <Equal className="h-3.5 w-3.5 mr-1" />
          Apply
        </Button>
      </div>
    </div>
  );
}

function CalcKey({ value, onClick }: { value: string; onClick: () => void }) {
  const isOperator = ["+", "-", "*", "/", "(", ")"].includes(value);
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-lg border border-border/40 py-2 text-sm font-semibold transition-colors hover:bg-accent",
        isOperator
          ? "bg-muted/30 text-gold"
          : "bg-muted/20 text-foreground"
      )}
    >
      {value}
    </button>
  );
}
