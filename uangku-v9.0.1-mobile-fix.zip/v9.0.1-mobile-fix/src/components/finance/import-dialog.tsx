"use client";

import { useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
// [v9.0 fix] Hapus unused imports (LOW priority cleanup) — Wallet type dan todayISO tidak dipakai.
import { type AppData, type Transaction } from "@/lib/types";
import {
  parseImportFile,
  applyImport,
  downloadImportTemplate,
  type ImportResult,
} from "@/lib/excel-import";
import { formatCurrency } from "@/lib/finance";
import {
  Upload,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";

interface ImportDialogProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  data: AppData;
  onImport: (txs: Transaction[]) => void;
}

export function ImportDialog({
  open,
  onOpenChange,
  data,
  onImport,
}: ImportDialogProps) {
  const [preview, setPreview] = useState<ImportResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [defaultWalletId, setDefaultWalletId] = useState<string>(
    data.wallets[0]?.id ?? ""
  );
  const [fileName, setFileName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  function reset() {
    setPreview(null);
    setFileName("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  async function handleFile(file: File) {
    // [v9.0 fix] Batasi ukuran file maksimal 10 MB (cegah memory exhaustion / hang)
    if (file.size > 10 * 1024 * 1024) {
      toast.error("Ukuran file maksimal 10 MB");
      return;
    }
    setFileName(file.name);
    setLoading(true);
    try {
      const result = await parseImportFile(file);
      setPreview(result);
      if (result.format === "unknown") {
        toast.warning("Format tidak dikenali. Tetap bisa diimport sebagai generic.");
      } else {
        toast.success(`Format terdeteksi: ${result.formatLabel}`);
      }
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message ?? "Gagal membaca file");
    } finally {
      setLoading(false);
    }
  }

  async function handleApplyImport() {
    if (!preview) return;
    setLoading(true);
    try {
      const txs = applyImport(preview, data.coa, defaultWalletId);
      onImport(txs);
      toast.success(`Berhasil import ${txs.length} transaksi`);
      onOpenChange(false);
      reset();
    } catch (e: any) {
      console.error(e);
      toast.error("Gagal import");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) reset();
      }}
    >
      <DialogContent className="sm:max-w-[480px] max-h-[92vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-violet-400" />
            Import Data
          </DialogTitle>
          <DialogDescription>
            Upload file Excel/CSV dari Money Lover, Monefy, atau Wallet. Format
            terdeteksi otomatis.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Download template */}
          <div className="rounded-lg border border-dashed border-border/60 p-3">
            <div className="flex items-start gap-2">
              <Download className="h-4 w-4 text-violet-400 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-medium">Butuh template contoh?</p>
                <p className="text-[11px] text-muted-foreground mb-2">
                  Download format Excel yang langsung kompatibel dengan Uangku.
                </p>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    downloadImportTemplate();
                    toast.success("Template diunduh");
                  }}
                  className="border-border/50 h-7 text-xs"
                >
                  Download Template
                </Button>
              </div>
            </div>
          </div>

          {/* Upload area */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="rounded-xl border-2 border-dashed border-border/60 p-6 text-center cursor-pointer hover:bg-accent transition-colors"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
              }}
            />
            {loading ? (
              <Loader2 className="h-8 w-8 mx-auto animate-spin text-violet-400" />
            ) : (
              <Upload className="h-8 w-8 mx-auto text-muted-foreground" />
            )}
            <p className="mt-2 text-sm font-medium">
              {fileName ? fileName : "Klik untuk pilih file"}
            </p>
            <p className="text-[11px] text-muted-foreground">
              Mendukung: .xlsx, .xls, .csv
            </p>
          </div>

          {/* Preview */}
          {preview && (
            <div className="space-y-3">
              {/* Format info */}
              <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <div>
                    <p className="text-xs font-semibold text-emerald-400">
                      Format Terdeteksi
                    </p>
                    <p className="text-sm font-bold">{preview.formatLabel}</p>
                  </div>
                  <div className="ml-auto text-right">
                    <p className="text-[11px] text-muted-foreground">Total baris</p>
                    <p className="text-lg font-bold text-emerald-400">
                      {preview.totalRows}
                    </p>
                  </div>
                </div>
              </div>

              {/* Default wallet */}
              <div className="space-y-1.5">
                <Label>Dompet Tujuan Default</Label>
                <Select
                  value={defaultWalletId}
                  onValueChange={setDefaultWalletId}
                >
                  <SelectTrigger className="bg-input/50 border-border/50">
                    <SelectValue placeholder="Pilih dompet" />
                  </SelectTrigger>
                  <SelectContent className="glass-strong border-border/50">
                    {data.wallets.filter((w) => !w.archived).map((w) => (
                      <SelectItem key={w.id} value={w.id}>
                        {w.icon} {w.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-muted-foreground">
                  Semua transaksi import akan dimasukkan ke dompet ini. Anda bisa
                  edit satu per satu setelah import.
                </p>
              </div>

              {/* Sample rows preview */}
              <div className="space-y-1.5">
                <Label>Preview 5 baris pertama</Label>
                <div className="rounded-lg border border-border/50 overflow-hidden">
                  <div className="grid grid-cols-12 gap-1 bg-muted/40 px-2 py-1.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                    <span className="col-span-2">Tgl</span>
                    <span className="col-span-2">Tipe</span>
                    <span className="col-span-3">Jumlah</span>
                    <span className="col-span-5">Kategori</span>
                  </div>
                  {preview.rows.slice(0, 5).map((r, i) => (
                    <div
                      key={i}
                      className="grid grid-cols-12 gap-1 px-2 py-1.5 text-xs border-t border-border/40"
                    >
                      <span className="col-span-2 font-mono text-[11px]">
                        {r.date.slice(5)}
                      </span>
                      <span
                        className={
                          r.type === "income"
                            ? "col-span-2 text-emerald-400"
                            : "col-span-2 text-pink-400"
                        }
                      >
                        {r.type === "income" ? "Masuk" : "Keluar"}
                      </span>
                      <span className="col-span-3 tabular-nums">
                        {formatCurrency(r.amount)}
                      </span>
                      <span className="col-span-5 truncate text-muted-foreground">
                        {r.category} {r.note ? `· ${r.note}` : ""}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Warning unmapped */}
              {preview.unmappedCategories.length > 0 && (
                <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="h-4 w-4 text-amber-400 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-amber-400">
                        Kategori belum terpetakan
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {preview.unmappedCategories.slice(0, 5).join(", ")}
                        {preview.unmappedCategories.length > 5 && "..."} — akan
                        otomatis masuk ke &quot;Beban Lain-lain&quot; atau bisa
                        edit setelah import.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-border/50"
            disabled={loading}
          >
            Batal
          </Button>
          <Button
            onClick={handleApplyImport}
            disabled={!preview || preview.totalRows === 0 || loading}
            className="bg-violet-600 hover:bg-violet-700 text-white border-0"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 mr-1 animate-spin" />
            ) : (
              <Upload className="h-4 w-4 mr-1" />
            )}
            Import {preview?.totalRows ?? 0} Transaksi
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
