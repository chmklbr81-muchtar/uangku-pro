"use client";

import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  type AppData,
  type Transaction,
} from "@/lib/types";
import {
  formatCurrency,
  formatCompact,
  formatDate,
  getMonthKey,
  getYear,
  getMonthlySeries,
  getHistoricalAvg,
  getTransactionsForMonth,
  getTransactionsForYear,
  getWallet,
  getCOAAccount,
  sumByCOA,
  getMonthLabel,
  getMonthShortLabel,
  todayISO,
} from "@/lib/finance";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  BarChart,
  Bar,
  Legend,
  Cell,
} from "recharts";
import {
  CalendarDays,
  CalendarRange,
  TrendingUp,
  TrendingDown,
  Wallet as WalletIcon,
  ChevronLeft,
  ChevronRight,
  X,
  PieChart as PieIcon,
  Receipt,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface MtdYtdDashboardProps {
  data: AppData;
  onOpenTransaction: (tx: Transaction) => void;
}

// [v9.0 fix] Pakai timezone Asia/Jakarta untuk perhitungan MTD/YTD.
// `new Date()` di browser/SSR bisa pakai timezone mesin (UTC di server, local di client),
// yang menyebabkan perbedaan tanggal "hari ini" antara server-side render dan client hydration.
// Helper ini selalu mengembalikan tanggal hari ini dalam timezone Asia/Jakarta (WIB, UTC+7).
function getJakartaDateParts(): { year: number; month: number; day: number } {
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
  // en-CA locale menghasilkan format YYYY-MM-DD
  const parts = fmt.formatToParts(new Date());
  const get = (t: string) =>
    Number(parts.find((p) => p.type === t)?.value ?? "0");
  return { year: get("year"), month: get("month"), day: get("day") };
}

export function MtdYtdDashboard({
  data,
  onOpenTransaction,
}: MtdYtdDashboardProps) {
  // [v9.0 fix] Pakai timezone Asia/Jakarta untuk perhitungan MTD/YTD — sebelumnya `new Date().getFullYear()`
  // bisa menghasilkan tahun yang salah di edge case pergantian tahun UTC (31 Dec 23:00 WIB = 1 Jan 06:00 UTC).
  const jakartaNow = getJakartaDateParts();
  const currentYear = jakartaNow.year;
  const [year, setYear] = useState(currentYear);
  const [view, setView] = useState<"MTD" | "YTD">("MTD");
  const [drilldown, setDrilldown] = useState<{
    title: string;
    txs: Transaction[];
  } | null>(null);

  // [v9.0 fix] T-1.2: filter soft-deleted transaksi (< 30 hari) supaya MTD/YTD dan drilldown konsisten.
  const SOFT_DELETE_WINDOW_MS = 30 * 24 * 60 * 60 * 1000;
  const visibleTransactions = useMemo(() => {
    return data.transactions.filter((t) => {
      if (!t.deletedAt) return true;
      return Date.now() - new Date(t.deletedAt).getTime() >= SOFT_DELETE_WINDOW_MS;
    });
  }, [data.transactions]);

  const monthlyData = useMemo(() => getMonthlySeries(visibleTransactions, year), [
    visibleTransactions,
    year,
  ]);
  // [v9.0 fix] currentMonthKey dihitung dari Jakarta timezone (bukan todayISO() yang pakai local).
  const currentMonthKey = `${jakartaNow.year}-${String(jakartaNow.month).padStart(2, "0")}`;
  const currentMTD = monthlyData.find((m) => m.monthKey === currentMonthKey);

  // YTD totals
  const ytdIncome = monthlyData.reduce((a, m) => a + m.income, 0);
  const ytdExpense = monthlyData.reduce((a, m) => a + m.expense, 0);
  const ytdBalance = ytdIncome - ytdExpense;
  const ytdSavingsRate = ytdIncome > 0 ? (ytdBalance / ytdIncome) * 100 : 0;

  // MTD totals
  const mtdIncome = currentMTD?.income ?? 0;
  const mtdExpense = currentMTD?.expense ?? 0;
  const mtdBalance = mtdIncome - mtdExpense;
  const mtdSavingsRate = mtdIncome > 0 ? (mtdBalance / mtdIncome) * 100 : 0;

  // Historical avg (12 bulan terakhir sebelum bulan ini)
  const historicalAvg = useMemo(
    () => getHistoricalAvg(visibleTransactions, currentMonthKey),
    [visibleTransactions, currentMonthKey]
  );

  // Pie data untuk bulan/tahun ini
  const pieData = useMemo(() => {
    const monthKey = view === "MTD" ? currentMonthKey : null;
    const yr = view === "YTD" ? year : null;
    const filtered = visibleTransactions.filter((t) => {
      if (t.type !== "expense") return false;
      if (monthKey) return getMonthKey(t.date) === monthKey;
      if (yr) return getYear(t.date) === yr;
      return false;
    });
    const byCat = sumByCOA(filtered, "expense", monthKey ?? undefined);
    return byCat.slice(0, 6).map((c, i) => ({
      name: getCOAAccount(data.coa, c.coaId)?.name ?? c.coaId,
      value: c.total,
      coaId: c.coaId,
      monthKey: monthKey ?? `${year}-total`,
    }));
  }, [data, visibleTransactions, view, currentMonthKey, year]);

  const yearsWithData = useMemo(() => {
    const years = new Set<number>();
    visibleTransactions.forEach((t) => years.add(getYear(t.date)));
    years.add(currentYear);
    return Array.from(years).sort((a, b) => b - a);
  }, [visibleTransactions, currentYear]);

  function handleBarClick(monthKey: string) {
    // Drilldown: tampilkan semua transaksi di bulan itu
    const txs = getTransactionsForMonth(visibleTransactions, monthKey);
    if (txs.length === 0) return;
    setDrilldown({
      title: `Transaksi ${getMonthLabel(monthKey)}`,
      txs,
    });
  }

  function handleYearClick() {
    // Drilldown: tampilkan semua transaksi tahun ini
    const txs = getTransactionsForYear(visibleTransactions, year);
    if (txs.length === 0) return;
    setDrilldown({
      title: `Semua Transaksi Tahun ${year}`,
      txs,
    });
  }

  return (
    <div className="space-y-4 pb-4">
      {/* Year selector + view toggle */}
      <Card className="glass p-3 border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setYear((y) => y - 1)}
              aria-label="Tahun sebelumnya"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-base font-bold tabular-nums">{year}</span>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={() => setYear((y) => y + 1)}
              aria-label="Tahun berikutnya"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex gap-1 rounded-lg bg-muted/40 p-1">
            <button
              onClick={() => setView("MTD")}
              className={cn(
                "rounded-md px-3 py-1 text-xs font-semibold transition-colors",
                view === "MTD"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground"
              )}
            >
              MTD
            </button>
            <button
              onClick={() => setView("YTD")}
              className={cn(
                "rounded-md px-3 py-1 text-xs font-semibold transition-colors",
                view === "YTD"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground"
              )}
            >
              YTD
            </button>
          </div>
        </div>
      </Card>

      {/* Stat Cards untuk View Aktif */}
      {view === "MTD" ? (
        <div className="grid grid-cols-2 gap-3">
          <StatCardMini
            icon={<TrendingUp className="h-4 w-4" />}
            label="MTD Pemasukan"
            value={formatCurrency(mtdIncome)}
            color="emerald"
          />
          <StatCardMini
            icon={<TrendingDown className="h-4 w-4" />}
            label="MTD Pengeluaran"
            value={formatCurrency(mtdExpense)}
            color="pink"
          />
          <StatCardMini
            icon={<WalletIcon className="h-4 w-4" />}
            label="MTD Selisih"
            value={formatCurrency(mtdBalance)}
            color={mtdBalance >= 0 ? "emerald" : "pink"}
          />
          <StatCardMini
            icon={<CalendarDays className="h-4 w-4" />}
            label="Savings Rate"
            value={`${mtdSavingsRate.toFixed(1)}%`}
            color={mtdSavingsRate >= 20 ? "violet" : "amber"}
          />
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <StatCardMini
            icon={<TrendingUp className="h-4 w-4" />}
            label="YTD Pemasukan"
            value={formatCurrency(ytdIncome)}
            color="emerald"
          />
          <StatCardMini
            icon={<TrendingDown className="h-4 w-4" />}
            label="YTD Pengeluaran"
            value={formatCurrency(ytdExpense)}
            color="pink"
          />
          <StatCardMini
            icon={<WalletIcon className="h-4 w-4" />}
            label="YTD Selisih"
            value={formatCurrency(ytdBalance)}
            color={ytdBalance >= 0 ? "emerald" : "pink"}
          />
          <StatCardMini
            icon={<CalendarRange className="h-4 w-4" />}
            label="YTD Savings Rate"
            value={`${ytdSavingsRate.toFixed(1)}%`}
            color={ytdSavingsRate >= 20 ? "violet" : "amber"}
          />
        </div>
      )}

      {/* Line chart 12 bulan */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-violet-400" />
            <h2 className="text-sm font-semibold">Tren 12 Bulan {year}</h2>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleYearClick}
            className="border-border/50 text-xs h-7"
          >
            Lihat semua {year}
          </Button>
        </div>
        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={monthlyData}
              margin={{ top: 4, right: 4, bottom: 0, left: -16 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis
                dataKey="monthLabel"
                tick={{ fontSize: 11, fill: "rgba(255,255,255,0.6)" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 10, fill: "rgba(255,255,255,0.6)" }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => formatCompact(Number(v)).replace("Rp ", "")}
                width={48}
              />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                contentStyle={{
                  borderRadius: "12px",
                  fontSize: "12px",
                  background: "rgba(20,15,40,0.92)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  color: "#fff",
                }}
                labelStyle={{ color: "rgba(255,255,255,0.8)" }}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
              <Line
                type="monotone"
                dataKey="income"
                name="Masuk"
                stroke="#10b981"
                strokeWidth={2.5}
                dot={{ r: 3, fill: "#10b981" }}
                activeDot={{ r: 5 }}
              />
              <Line
                type="monotone"
                dataKey="expense"
                name="Keluar"
                stroke="#ec4899"
                strokeWidth={2.5}
                dot={{ r: 3, fill: "#ec4899" }}
                activeDot={{ r: 5 }}
              />
              <Line
                type="monotone"
                dataKey="balance"
                name="Selisih"
                stroke="#a855f7"
                strokeWidth={2}
                strokeDasharray="4 4"
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Bar chart MTD vs Historical Avg */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-3">
          <TrendingDown className="h-4 w-4 text-pink-400" />
          <h2 className="text-sm font-semibold">Bulan Ini vs Rata-rata Historis</h2>
        </div>
        <div className="h-44 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={[
                {
                  name: "MTD",
                  Pengeluaran: mtdExpense,
                  "Rata-rata 12 bln": historicalAvg,
                },
              ]}
              margin={{ top: 4, right: 4, bottom: 0, left: -16 }}
              barCategoryGap="20%"
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
              <XAxis
                dataKey="name"
                tick={{ fontSize: 12, fill: "rgba(255,255,255,0.7)" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 10, fill: "rgba(255,255,255,0.6)" }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => formatCompact(Number(v)).replace("Rp ", "")}
                width={48}
              />
              <Tooltip
                formatter={(value: number) => formatCurrency(value)}
                contentStyle={{
                  borderRadius: "12px",
                  fontSize: "12px",
                  background: "rgba(20,15,40,0.92)",
                  border: "1px solid rgba(255,255,255,0.12)",
                  color: "#fff",
                }}
                labelStyle={{ color: "rgba(255,255,255,0.8)" }}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
              <Bar dataKey="Pengeluaran" fill="#ec4899" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Rata-rata 12 bln" fill="#6b7280" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        {historicalAvg > 0 && (
          <p className="mt-2 text-xs text-muted-foreground">
            {mtdExpense > historicalAvg ? (
              <span className="text-pink-400">
                ⚠ Pengeluaran MTD{" "}
                <span className="font-bold">
                  {((mtdExpense / historicalAvg - 1) * 100).toFixed(0)}% lebih tinggi
                </span>{" "}
                dari rata-rata
              </span>
            ) : (
              <span className="text-emerald-400">
                ✓ Pengeluaran MTD{" "}
                <span className="font-bold">
                  {((1 - mtdExpense / historicalAvg) * 100).toFixed(0)}% lebih hemat
                </span>{" "}
                dari rata-rata
              </span>
            )}
          </p>
        )}
      </Card>

      {/* Drilldown ke bulan: 12 bar untuk tiap bulan (klikable) */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-3">
          <CalendarRange className="h-4 w-4 text-violet-400" />
          <h2 className="text-sm font-semibold">Klik Bulan untuk Lihat Detail</h2>
        </div>
        <div className="grid grid-cols-4 gap-1.5">
          {monthlyData.map((m) => {
            const isCurrent = m.monthKey === currentMonthKey;
            const hasData = m.income > 0 || m.expense > 0;
            return (
              <button
                key={m.monthKey}
                onClick={() => handleBarClick(m.monthKey)}
                disabled={!hasData}
                className={cn(
                  "rounded-lg border p-2 text-center transition-colors",
                  isCurrent
                    ? "border-violet-500/60 bg-violet-500/10"
                    : "border-border/40 hover:bg-accent",
                  !hasData && "opacity-40 cursor-not-allowed"
                )}
              >
                <p className="text-[10px] font-medium text-muted-foreground">
                  {m.monthLabel}
                </p>
                <p className="mt-0.5 text-xs font-bold text-emerald-400 truncate">
                  {formatCompact(m.income)}
                </p>
                <p className="text-xs font-bold text-pink-400 truncate">
                  {formatCompact(m.expense)}
                </p>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Pie chart pengeluaran */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-3">
          <PieIcon className="h-4 w-4 text-pink-400" />
          <h2 className="text-sm font-semibold">
            Top 6 Pengeluaran ({view === "MTD" ? "Bulan Ini" : `Tahun ${year}`})
          </h2>
        </div>
        {pieData.length === 0 ? (
          <p className="py-8 text-center text-sm text-muted-foreground">
            Belum ada pengeluaran {view === "MTD" ? "bulan ini" : `tahun ${year}`}.
          </p>
        ) : (
          <div className="space-y-2">
            {pieData.map((p, idx) => {
              const total = pieData.reduce((a, x) => a + x.value, 0);
              const pct = (p.value / total) * 100;
              const colors = [
                "#a855f7",
                "#ec4899",
                "#10b981",
                "#f59e0b",
                "#06b6d4",
                "#ef4444",
              ];
              const color = colors[idx % colors.length];
              return (
                <div key={p.coaId} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 font-medium">
                      <span
                        className="inline-block h-2.5 w-2.5 rounded-full"
                        style={{ backgroundColor: color }}
                      />
                      {p.name}
                    </span>
                    <span className="tabular-nums text-muted-foreground">
                      {formatCurrency(p.value)} ({pct.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${pct}%`, backgroundColor: color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Drilldown Dialog */}
      <DrilldownDialog
        title={drilldown?.title ?? ""}
        txs={drilldown?.txs ?? []}
        open={!!drilldown}
        onOpenChange={(o) => !o && setDrilldown(null)}
        data={data}
        onOpenTransaction={onOpenTransaction}
      />
    </div>
  );
}

function StatCardMini({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: "emerald" | "pink" | "violet" | "amber";
}) {
  const colorMap = {
    emerald: "text-emerald-400 bg-emerald-500/10",
    pink: "text-pink-400 bg-pink-500/10",
    violet: "text-violet-400 bg-violet-500/10",
    amber: "text-amber-400 bg-amber-500/10",
  };
  return (
    <Card className="glass p-3 border-border/50">
      <div
        className={cn(
          "inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5",
          colorMap[color]
        )}
      >
        {icon}
        <span className="text-[10px] font-semibold uppercase tracking-wide">
          {label}
        </span>
      </div>
      <p className="mt-1.5 text-sm font-bold tabular-nums truncate">{value}</p>
    </Card>
  );
}

function DrilldownDialog({
  title,
  txs,
  open,
  onOpenChange,
  data,
  onOpenTransaction,
}: {
  title: string;
  txs: Transaction[];
  open: boolean;
  onOpenChange: (o: boolean) => void;
  data: AppData;
  onOpenTransaction: (tx: Transaction) => void;
}) {
  const totalIncome = txs
    .filter((t) => t.type === "income")
    .reduce((a, t) => a + t.amount, 0);
  const totalExpense = txs
    .filter((t) => t.type === "expense")
    .reduce((a, t) => a + t.amount, 0);
  const totalTransfer = txs
    .filter((t) => t.type === "transfer")
    .reduce((a, t) => a + t.amount, 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Receipt className="h-5 w-5 text-violet-400" />
            {title}
          </DialogTitle>
          <DialogDescription>
            {txs.length} transaksi ·{" "}
            <span className="text-emerald-400">
              +{formatCurrency(totalIncome)}
            </span>{" "}
            ·{" "}
            <span className="text-pink-400">
              −{formatCurrency(totalExpense)}
            </span>
            {totalTransfer > 0 && (
              <>
                {" "}
                ·{" "}
                <span className="text-violet-400">
                  ↔ {formatCurrency(totalTransfer)}
                </span>
              </>
            )}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          {txs.map((t) => {
            const wallet = getWallet(data.wallets, t.walletId);
            const coa = getCOAAccount(data.coa, t.coaId);
            const isIncome = t.type === "income";
            const isTransfer = t.type === "transfer";
            const color = isIncome
              ? "text-emerald-400"
              : isTransfer
              ? "text-violet-400"
              : "text-pink-400";
            const bg = isIncome
              ? "bg-emerald-500/10"
              : isTransfer
              ? "bg-violet-500/10"
              : "bg-pink-500/10";
            const targetWallet = isTransfer
              ? getWallet(data.wallets, t.transferToWalletId ?? "")
              : null;
            return (
              <button
                key={t.id}
                onClick={() => onOpenTransaction(t)}
                className="flex w-full items-center gap-3 rounded-xl glass p-3 text-left hover:bg-accent transition-colors border-border/50"
              >
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-lg",
                    bg
                  )}
                >
                  {wallet?.icon ?? "💵"}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">
                    {coa?.name ?? t.category}
                    {isTransfer && targetWallet && (
                      <span className="text-muted-foreground">
                        {" "}
                        → {targetWallet.icon} {targetWallet.name}
                      </span>
                    )}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {t.note ?? formatDate(t.date)} · {formatDate(t.date)}
                  </p>
                </div>
                <div className="text-right">
                  <p className={cn("text-sm font-bold tabular-nums", color)}>
                    {isIncome ? "+" : isTransfer ? "↔" : "−"}
                    {formatCurrency(t.amount)}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
