"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
  type COAAccount,
  type COAType,
} from "@/lib/types";
import { getRootAccounts, getSubAccounts } from "@/lib/default-data";
import { genId } from "@/lib/finance";
import {
  ChevronDown,
  ChevronRight,
  Plus,
  Edit2,
  Trash2,
  Folder,
  FileText,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface COAManagerProps {
  data: AppData;
  onUpdate: (coa: COAAccount[]) => void;
}

const TYPE_LABELS: Record<COAType, string> = {
  asset: "Aset",
  liability: "Kewajiban",
  equity: "Ekuitas",
  income: "Pendapatan",
  expense: "Beban",
  capital: "Modal",
  drawings: "Prive",
  other_income: "Pendapatan Lain",
  operating_expense: "Beban Operasional",
};

const TYPE_COLORS: Record<COAType, string> = {
  asset: "text-emerald-400 bg-emerald-500/10",
  liability: "text-red-400 bg-red-500/10",
  equity: "text-violet-400 bg-violet-500/10",
  income: "text-cyan-400 bg-cyan-500/10",
  expense: "text-pink-400 bg-pink-500/10",
  capital: "text-amber-400 bg-amber-500/10",
  drawings: "text-orange-400 bg-orange-500/10",
  other_income: "text-teal-400 bg-teal-500/10",
  operating_expense: "text-pink-400 bg-pink-500/10",
};

export function COAManager({ data, onUpdate }: COAManagerProps) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>(() => {
    const map: Record<string, boolean> = {};
    getRootAccounts(data.coa).forEach((r) => (map[r.id] = true));
    return map;
  });
  const [editing, setEditing] = useState<COAAccount | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newParent, setNewParent] = useState<string | null>(null);

  function toggle(id: string) {
    setExpanded((p) => ({ ...p, [id]: !p[id] }));
  }

  function handleEdit(acc: COAAccount) {
    setEditing(acc);
    setNewParent(null);
    setDialogOpen(true);
  }

  function handleAddSub(parent: COAAccount) {
    setEditing(null);
    setNewParent(parent.id);
    setDialogOpen(true);
  }

  function handleDelete(acc: COAAccount) {
    if (acc.isDefault) {
      toast.error("Akun default tidak bisa dihapus");
      return;
    }
    const hasChildren = data.coa.some((c) => c.parentId === acc.id);
    if (hasChildren) {
      toast.error("Tidak bisa hapus akun yang masih punya sub-akun");
      return;
    }
    const hasTx = data.transactions.some((t) => t.coaId === acc.id);
    if (hasTx) {
      // archive instead of delete
      const updated = data.coa.map((c) =>
        c.id === acc.id ? { ...c, archived: true } : c
      );
      onUpdate(updated);
      toast.success("Akun diarsipkan (masih dipakai transaksi)");
      return;
    }
    const updated = data.coa.filter((c) => c.id !== acc.id);
    onUpdate(updated);
    toast.success("Akun dihapus");
  }

  function handleSave(acc: COAAccount) {
    let updated: COAAccount[];
    const exists = data.coa.some((c) => c.id === acc.id);
    if (exists) {
      updated = data.coa.map((c) => (c.id === acc.id ? acc : c));
    } else {
      updated = [...data.coa, acc];
    }
    onUpdate(updated);
    setDialogOpen(false);
    setEditing(null);
    setNewParent(null);
    toast.success(exists ? "Akun diperbarui" : "Akun ditambah");
  }

  const roots = getRootAccounts(data.coa);

  return (
    <div className="space-y-3 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Chart of Account</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {data.coa.filter((c) => !c.archived).length} akun aktif ·{" "}
              {roots.length} akun induk
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setEditing(null);
              setNewParent(null);
              setDialogOpen(true);
            }}
            className="border-border/50"
          >
            <Plus className="h-4 w-4 mr-1" />
            Akun Baru
          </Button>
        </div>
      </Card>

      {/* Tree View */}
      <div className="space-y-2">
        {roots.map((root) => {
          const isExpanded = expanded[root.id] ?? true;
          const subs = getSubAccounts(data.coa, root.id);
          return (
            <div key={root.id} className="rounded-2xl glass overflow-hidden border-border/50">
              {/* Root */}
              <div className="flex items-center gap-2 p-3 hover:bg-accent transition-colors">
                <button
                  onClick={() => toggle(root.id)}
                  className="text-muted-foreground hover:text-foreground"
                  aria-label="Toggle"
                >
                  {isExpanded ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </button>
                <Folder className={cn("h-4 w-4", TYPE_COLORS[root.type].split(" ")[0])} />
                <span className="font-mono text-xs text-muted-foreground">
                  {root.code}
                </span>
                <span className="flex-1 text-sm font-semibold uppercase tracking-wide">
                  {root.name}
                </span>
                <span
                  className={cn(
                    "rounded-md px-2 py-0.5 text-[10px] font-medium",
                    TYPE_COLORS[root.type]
                  )}
                >
                  {TYPE_LABELS[root.type]}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7"
                  onClick={() => handleAddSub(root)}
                  aria-label="Tambah sub-akun"
                >
                  <Plus className="h-3.5 w-3.5" />
                </Button>
              </div>

              {/* Sub-accounts */}
              {isExpanded && (
                <div className="border-t border-border/50">
                  {subs.length === 0 ? (
                    <p className="px-4 py-3 text-xs text-muted-foreground italic">
                      Belum ada sub-akun
                    </p>
                  ) : (
                    <SubAccountList
                      parent={root}
                      data={data}
                      expanded={expanded}
                      onToggle={toggle}
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onAddSub={handleAddSub}
                    />
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <COAEditDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) {
            setEditing(null);
            setNewParent(null);
          }
        }}
        editing={editing}
        data={data}
        newParent={newParent}
        onSave={handleSave}
      />
    </div>
  );
}

function SubAccountList({
  parent,
  data,
  expanded,
  onToggle,
  onEdit,
  onDelete,
  onAddSub,
}: {
  parent: COAAccount;
  data: AppData;
  expanded: Record<string, boolean>;
  onToggle: (id: string) => void;
  onEdit: (acc: COAAccount) => void;
  onDelete: (acc: COAAccount) => void;
  onAddSub: (parent: COAAccount) => void;
}) {
  const subs = getSubAccounts(data.coa, parent.id);
  return (
    <div className="space-y-0.5">
      {subs.map((sub) => {
        const hasChildren = data.coa.some((c) => c.parentId === sub.id);
        const isExpanded = expanded[sub.id];
        const grandChildren = hasChildren ? getSubAccounts(data.coa, sub.id) : [];
        return (
          <div key={sub.id}>
            <div className="flex items-center gap-2 px-3 py-2 hover:bg-accent transition-colors">
              <div className="w-4">
                {hasChildren ? (
                  <button
                    onClick={() => onToggle(sub.id)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronRight className="h-3.5 w-3.5" />
                    )}
                  </button>
                ) : (
                  <FileText className="h-3.5 w-3.5 text-muted-foreground/60 ml-0.5" />
                )}
              </div>
              <span className="font-mono text-xs text-muted-foreground">
                {sub.code}
              </span>
              <span className="flex-1 text-sm">{sub.name}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => onAddSub(sub)}
                aria-label="Tambah sub"
              >
                <Plus className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7"
                onClick={() => onEdit(sub)}
                aria-label="Edit"
              >
                <Edit2 className="h-3.5 w-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-red-400 hover:text-red-500"
                onClick={() => onDelete(sub)}
                aria-label="Hapus"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
            {hasChildren && isExpanded && (
              <div className="pl-8">
                {grandChildren.map((gc) => (
                  <div
                    key={gc.id}
                    className="flex items-center gap-2 px-3 py-1.5 hover:bg-accent transition-colors"
                  >
                    <FileText className="h-3.5 w-3.5 text-muted-foreground/60" />
                    <span className="font-mono text-xs text-muted-foreground">
                      {gc.code}
                    </span>
                    <span className="flex-1 text-sm">{gc.name}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => onEdit(gc)}
                      aria-label="Edit"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-red-400 hover:text-red-500"
                      onClick={() => onDelete(gc)}
                      aria-label="Hapus"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function COAEditDialog({
  open,
  onOpenChange,
  editing,
  data,
  newParent,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editing: COAAccount | null;
  data: AppData;
  newParent: string | null;
  onSave: (acc: COAAccount) => void;
}) {
  const [code, setCode] = useState(editing?.code ?? "");
  const [name, setName] = useState(editing?.name ?? "");
  const [type, setType] = useState<COAType>(editing?.type ?? "expense");
  const [parentId, setParentId] = useState<string>(
    editing?.parentId ?? newParent ?? ""
  );

  // [v9.0 fix] setState-during-render anti-pattern (lastOpen) -> useEffect
  // Sinkronisasi state lokal saat dialog dibuka, editing berubah, atau newParent berubah.
  useEffect(() => {
    if (!open) return;
    setCode(editing?.code ?? "");
    setName(editing?.name ?? "");
    setType(editing?.type ?? "expense");
    setParentId(editing?.parentId ?? newParent ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing, newParent]);

  const parentOptions = data.coa.filter((c) => !c.archived);

  function handleSubmit() {
    if (!code.trim() || !name.trim()) return;
    const acc: COAAccount = {
      id: editing?.id ?? `coa-${code.trim()}-${genId().slice(0, 6)}`,
      code: code.trim(),
      name: name.trim(),
      type,
      parentId: parentId || null,
      isDefault: editing?.isDefault ?? false,
    };
    onSave(acc);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[420px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle>
            {editing ? "Edit Akun" : "Tambah Akun COA"}
          </DialogTitle>
          <DialogDescription>
            {editing
              ? "Ubah nama, kode, atau struktur akun."
              : "Buat akun baru atau sub-akun di bawah akun induk."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="coa-code">Kode Akun</Label>
            <Input
              id="coa-code"
              placeholder="Contoh: 8-2100"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="coa-name">Nama Akun</Label>
            <Input
              id="coa-name"
              placeholder="Contoh: Pengeluaran Marketing"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Tipe Akun</Label>
            <Select value={type} onValueChange={(v) => setType(v as COAType)}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50">
                {(Object.keys(TYPE_LABELS) as COAType[]).map((t) => (
                  <SelectItem key={t} value={t}>
                    {TYPE_LABELS[t]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Akun Induk (opsional)</Label>
            <Select
              value={parentId}
              onValueChange={(v) => setParentId(v === "none" ? "" : v)}
            >
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="(Tidak ada / akun induk)" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50 max-h-72">
                <SelectItem value="none">(Akun Induk Baru)</SelectItem>
                {parentOptions
                  .filter((c) => c.id !== editing?.id)
                  .map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.code} — {c.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!code.trim() || !name.trim()}
            className="bg-primary text-primary-foreground"
          >
            Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
