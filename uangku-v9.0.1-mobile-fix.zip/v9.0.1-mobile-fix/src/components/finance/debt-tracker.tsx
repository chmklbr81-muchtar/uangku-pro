"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
  type DebtLoan,
  type DebtType,
  type DebtStatus,
} from "@/lib/types";
import {
  formatCurrency,
  formatDate,
  computeDebtSummary,
  todayISO,
  genId,
} from "@/lib/finance";
import {
  Plus,
  Trash2,
  Edit2,
  ArrowDownLeft,
  ArrowUpRight,
  HandCoins,
  Check,
  X,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface DebtTrackerProps {
  data: AppData;
  onUpdate: (debts: DebtLoan[]) => void;
}

export function DebtTracker({ data, onUpdate }: DebtTrackerProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<DebtLoan | null>(null);
  const [paymentOpen, setPaymentOpen] = useState<DebtLoan | null>(null);
  const [filter, setFilter] = useState<"all" | "receivable" | "payable">("all");

  const summary = computeDebtSummary(data.debts);
  const active = data.debts.filter((d) => d.status !== "paid");
  const filtered = active.filter((d) => filter === "all" || d.type === filter);

  function handleSave(d: DebtLoan) {
    const exists = data.debts.some((x) => x.id === d.id);
    const updated = exists
      ? data.debts.map((x) => (x.id === d.id ? d : x))
      : [...data.debts, d];
    onUpdate(updated);
    setDialogOpen(false);
    setEditing(null);
    toast.success(exists ? "Utang/piutang diperbarui" : "Utang/piutang ditambahkan");
  }

  function handleDelete(id: string) {
    onUpdate(data.debts.filter((d) => d.id !== id));
    toast.success("Dihapus");
  }

  function handleMarkPaid(d: DebtLoan) {
    const updated: DebtLoan = {
      ...d,
      paidAmount: d.amount,
      status: "paid",
      updatedAt: new Date().toISOString(),
    };
    onUpdate(data.debts.map((x) => (x.id === d.id ? updated : x)));
    setPaymentOpen(null);
    toast.success("Ditandai lunas 🎉");
  }

  function handleAddPayment(d: DebtLoan, amount: number) {
    const newPaid = d.paidAmount + amount;
    const updated: DebtLoan = {
      ...d,
      paidAmount: newPaid,
      status: newPaid >= d.amount ? "paid" : "partial",
      updatedAt: new Date().toISOString(),
    };
    onUpdate(data.debts.map((x) => (x.id === d.id ? updated : x)));
    setPaymentOpen(null);
    toast.success(`Pembayaran ${formatCurrency(amount)} ditambahkan`);
  }

  return (
    <div className="space-y-4 pb-4">
      {/* Ringkasan */}
      <div className="grid grid-cols-2 gap-2">
        <Card className="glass p-3 border-emerald-500/30">
          <div className="flex items-center gap-1.5 text-emerald-400">
            <ArrowDownLeft className="h-3.5 w-3.5" />
            <span className="text-[10px] font-semibold uppercase">Piutang Saya</span>
          </div>
          <p className="mt-1 text-base font-bold text-emerald-400">
            {formatCurrency(summary.outstandingReceivable)}
          </p>
          <p className="text-[10px] text-muted-foreground">
            dari total {formatCurrency(summary.totalReceivable)}
          </p>
        </Card>
        <Card className="glass p-3 border-red-500/30">
          <div className="flex items-center gap-1.5 text-red-400">
            <ArrowUpRight className="h-3.5 w-3.5" />
            <span className="text-[10px] font-semibold uppercase">Saya Utang</span>
          </div>
          <p className="mt-1 text-base font-bold text-red-400">
            {formatCurrency(summary.outstandingPayable)}
          </p>
          <p className="text-[10px] text-muted-foreground">
            dari total {formatCurrency(summary.totalPayable)}
          </p>
        </Card>
      </div>

      {/* Action & filter */}
      <div className="flex items-center gap-2">
        <Button
          onClick={() => {
            setEditing(null);
            setDialogOpen(true);
          }}
          size="sm"
          className="bg-primary text-primary-foreground h-9"
        >
          <Plus className="h-4 w-4 mr-1" />
          Tambah
        </Button>
        <div className="flex gap-1 rounded-lg bg-muted/40 p-1 ml-auto">
          {(
            [
              { id: "all", label: "Semua" },
              { id: "receivable", label: "Piutang" },
              { id: "payable", label: "Utang" },
            ] as { id: typeof filter; label: string }[]
          ).map((opt) => (
            <button
              key={opt.id}
              onClick={() => setFilter(opt.id)}
              className={cn(
                "rounded-md px-2 py-1 text-[11px] font-semibold transition-colors",
                filter === opt.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent"
              )}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Daftar */}
      {filtered.length === 0 ? (
        <Card className="glass flex flex-col items-center justify-center gap-3 p-10 text-center border-border/50">
          <div className="rounded-full bg-muted/40 p-4">
            <HandCoins className="h-8 w-8 text-muted-foreground" />
          </div>
          <div>
            <p className="font-medium">Belum ada utang/piutang</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              Catat siapa yang utang ke Anda, atau Anda utang ke siapa.
            </p>
          </div>
        </Card>
      ) : (
        <div className="space-y-2">
          {filtered.map((d) => {
            const isReceivable = d.type === "receivable";
            const outstanding = d.amount - d.paidAmount;
            const percent = d.amount > 0 ? (d.paidAmount / d.amount) * 100 : 0;
            const daysToDue = d.dueDate
              ? Math.ceil(
                  (new Date(d.dueDate).getTime() - Date.now()) /
                    (24 * 60 * 60 * 1000)
                )
              : null;
            const isOverdue = daysToDue !== null && daysToDue < 0;
            return (
              <Card
                key={d.id}
                className={cn(
                  "glass p-3 border-border/50",
                  isOverdue && "border-red-500/40 bg-red-500/5"
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <div
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-full text-lg",
                        isReceivable
                          ? "bg-emerald-500/10"
                          : "bg-red-500/10"
                      )}
                    >
                      {isReceivable ? "💵" : "💸"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {d.personName}
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {isReceivable ? "Utang ke saya" : "Saya utang"} ·{" "}
                        {formatDate(d.date)}
                      </p>
                      {d.dueDate && (
                        <p
                          className={cn(
                            "text-[11px]",
                            isOverdue
                              ? "text-red-400 font-semibold"
                              : daysToDue !== null && daysToDue <= 3
                              ? "text-amber-400"
                              : "text-muted-foreground"
                          )}
                        >
                          {isOverdue
                            ? `⚠ Terlambat ${Math.abs(daysToDue!)} hari`
                            : `Jatuh tempo ${formatDate(d.dueDate)}`}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => {
                        setEditing(d);
                        setDialogOpen(true);
                      }}
                      aria-label="Edit"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-red-400 hover:text-red-500"
                      onClick={() => handleDelete(d.id)}
                      aria-label="Hapus"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs">
                    <span
                      className={cn(
                        "font-bold tabular-nums",
                        isReceivable ? "text-emerald-400" : "text-red-400"
                      )}
                    >
                      {formatCurrency(outstanding)}
                    </span>
                    <span className="text-muted-foreground">
                      dibayar {formatCurrency(d.paidAmount)} / {formatCurrency(d.amount)}
                    </span>
                  </div>
                  <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        isReceivable ? "bg-emerald-500" : "bg-red-500"
                      )}
                      style={{ width: `${Math.min(100, percent)}%` }}
                    />
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <span
                      className={cn(
                        "text-[10px] font-semibold",
                        d.status === "partial"
                          ? "text-amber-400"
                          : d.status === "paid"
                          ? "text-emerald-400"
                          : "text-muted-foreground"
                      )}
                    >
                      {d.status === "partial"
                        ? `Sebagian (${percent.toFixed(0)}%)`
                        : d.status === "paid"
                        ? "Lunas ✓"
                        : "Belum dibayar"}
                    </span>
                    {d.status !== "paid" && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPaymentOpen(d)}
                        className="h-7 text-xs border-border/50"
                      >
                        <Check className="h-3 w-3 mr-1" />
                        {d.status === "partial" ? "Bayar lagi" : "Tandai Bayar"}
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Sudah lunas (collapsed section) */}
      {data.debts.filter((d) => d.status === "paid").length > 0 && (
        <div className="pt-2">
          <p className="text-xs text-muted-foreground mb-2">
            Riwayat lunas: {data.debts.filter((d) => d.status === "paid").length} item
          </p>
        </div>
      )}

      <DebtEditDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) setEditing(null);
        }}
        editing={editing}
        data={data}
        onSave={handleSave}
      />

      {/* [v9.0 fix] Rules of Hooks: render PaymentDialog hanya saat debt non-null
          agar jumlah hook konsisten tiap render instance (sebelumnya useState
          dipanggil sebelum `if (!debt) return null` -> crash saat debt null <-> object). */}
      {paymentOpen && (
        <PaymentDialog
          debt={paymentOpen}
          onOpenChange={(o) => !o && setPaymentOpen(null)}
          onAddPayment={handleAddPayment}
          onMarkPaid={handleMarkPaid}
        />
      )}
    </div>
  );
}

function DebtEditDialog({
  open,
  onOpenChange,
  editing,
  data,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editing: DebtLoan | null;
  data: AppData;
  onSave: (d: DebtLoan) => void;
}) {
  const [type, setType] = useState<DebtType>(editing?.type ?? "receivable");
  const [personName, setPersonName] = useState(editing?.personName ?? "");
  const [amount, setAmount] = useState(
    editing ? String(editing.amount) : ""
  );
  const [paidAmount, setPaidAmount] = useState(
    editing ? String(editing.paidAmount) : ""
  );
  const [date, setDate] = useState(editing?.date ?? todayISO());
  const [dueDate, setDueDate] = useState(editing?.dueDate ?? "");
  const [walletId, setWalletId] = useState(editing?.walletId ?? "");
  const [note, setNote] = useState(editing?.note ?? "");

  // [v9.0 fix] setState-during-render anti-pattern (lastOpen) -> useEffect
  // Sinkronisasi state lokal saat dialog dibuka atau editing berubah.
  useEffect(() => {
    if (!open) return;
    setType(editing?.type ?? "receivable");
    setPersonName(editing?.personName ?? "");
    setAmount(editing ? String(editing.amount) : "");
    setPaidAmount(editing ? String(editing.paidAmount) : "");
    setDate(editing?.date ?? todayISO());
    setDueDate(editing?.dueDate ?? "");
    setWalletId(editing?.walletId ?? "");
    setNote(editing?.note ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  function handleSubmit() {
    const numAmount = Number(amount.replace(/[^0-9]/g, ""));
    const numPaid = Number(paidAmount.replace(/[^0-9]/g, "")) || 0;
    if (!personName.trim() || !numAmount) return;
    const status: DebtStatus =
      numPaid >= numAmount ? "paid" : numPaid > 0 ? "partial" : "active";
    onSave({
      id: editing?.id ?? genId(),
      type,
      personName: personName.trim(),
      amount: numAmount,
      paidAmount: numPaid,
      date,
      dueDate: dueDate || undefined,
      walletId: walletId || undefined,
      note: note.trim() || undefined,
      status,
      createdAt: editing?.createdAt ?? new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[440px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <HandCoins className="h-5 w-5 text-violet-400" />
            {editing ? "Edit Utang/Piutang" : "Catat Utang/Piutang"}
          </DialogTitle>
          <DialogDescription>
            Catat siapa utang ke Anda atau Anda utang ke siapa.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setType("receivable")}
              className={cn(
                "rounded-lg border-2 py-2.5 text-sm font-semibold transition-colors",
                type === "receivable"
                  ? "border-emerald-500 bg-emerald-500/15 text-emerald-400"
                  : "border-border text-muted-foreground"
              )}
            >
              <ArrowDownLeft className="h-4 w-4 inline mr-1" />
              Piutang (utang ke saya)
            </button>
            <button
              type="button"
              onClick={() => setType("payable")}
              className={cn(
                "rounded-lg border-2 py-2.5 text-sm font-semibold transition-colors",
                type === "payable"
                  ? "border-red-500 bg-red-500/15 text-red-400"
                  : "border-border text-muted-foreground"
              )}
            >
              <ArrowUpRight className="h-4 w-4 inline mr-1" />
              Utang (saya utang)
            </button>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="debt-person">Nama Orang</Label>
            <Input
              id="debt-person"
              placeholder="Contoh: Budi, Andi, Toko Semba Jaya"
              value={personName}
              onChange={(e) => setPersonName(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label>Jumlah</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">Rp</span>
                <Input
                  inputMode="numeric"
                  placeholder="0"
                  value={amount}
                  onChange={(e) => {
                    const only = e.target.value.replace(/[^0-9]/g, "");
                    setAmount(only ? Number(only).toLocaleString("id-ID") : "");
                  }}
                  className="pl-10 bg-input/50 border-border/50"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Sudah Dibayar</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">Rp</span>
                <Input
                  inputMode="numeric"
                  placeholder="0"
                  value={paidAmount}
                  onChange={(e) => {
                    const only = e.target.value.replace(/[^0-9]/g, "");
                    setPaidAmount(only ? Number(only).toLocaleString("id-ID") : "");
                  }}
                  className="pl-10 bg-input/50 border-border/50"
                />
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label htmlFor="debt-date">Tanggal Pinjam</Label>
              <Input
                id="debt-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="bg-input/50 border-border/50"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="debt-due">Jatuh Tempo (opsional)</Label>
              <Input
                id="debt-due"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="bg-input/50 border-border/50"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Dompet Terkait (opsional)</Label>
            <Select value={walletId} onValueChange={setWalletId}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="Pilih dompet" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50">
                <SelectItem value="_none">(Tidak terikat dompet)</SelectItem>
                {data.wallets.filter((w) => !w.archived).map((w) => (
                  <SelectItem key={w.id} value={w.id}>
                    {w.icon} {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="debt-note">Catatan (opsional)</Label>
            <Textarea
              id="debt-note"
              placeholder="Contoh: Untuk biaya kos bulan Oktober"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              className="bg-input/50 border-border/50"
            />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!personName.trim() || !amount}
            className="bg-primary text-primary-foreground"
          >
            Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PaymentDialog({
  debt,
  onOpenChange,
  onAddPayment,
  onMarkPaid,
}: {
  // [v9.0 fix] Rules of Hooks: debt non-null (parent hanya render saat debt non-null)
  debt: DebtLoan;
  onOpenChange: (o: boolean) => void;
  onAddPayment: (d: DebtLoan, amount: number) => void;
  onMarkPaid: (d: DebtLoan) => void;
}) {
  const [amount, setAmount] = useState("");
  const outstanding = debt.amount - debt.paidAmount;

  function handleSubmit() {
    const n = Number(amount.replace(/[^0-9]/g, ""));
    if (!n || n <= 0) return;
    onAddPayment(debt, n);
    setAmount("");
  }

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[360px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle>Catat Pembayaran</DialogTitle>
          <DialogDescription>
            {debt.type === "receivable" ? "Penerimaan dari" : "Pembayaran ke"}{" "}
            <span className="font-semibold text-foreground">{debt.personName}</span>
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-lg bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
            <div className="flex justify-between">
              <span>Total: {formatCurrency(debt.amount)}</span>
              <span>Sudah dibayar: {formatCurrency(debt.paidAmount)}</span>
            </div>
            <div className="flex justify-between mt-1 font-semibold text-foreground">
              <span>Sisa:</span>
              <span>{formatCurrency(outstanding)}</span>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="pay-amount">Jumlah Pembayaran</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="pay-amount"
                inputMode="numeric"
                placeholder="0"
                value={amount}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setAmount(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 text-base font-semibold bg-input/50 border-border/50"
                autoFocus
              />
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            variant="outline"
            onClick={() => onMarkPaid(debt)}
            className="border-emerald-500/40 text-emerald-400"
          >
            <Check className="h-4 w-4 mr-1" />
            Lunas
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!amount}
            className="bg-primary text-primary-foreground"
          >
            Tambah
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
