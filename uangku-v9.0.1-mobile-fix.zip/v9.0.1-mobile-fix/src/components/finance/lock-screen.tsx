"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Fingerprint, Lock, ShieldCheck, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface LockScreenProps {
  enabled: boolean; // apakah biometrik/pin aktif
  biometricAvailable: boolean;
  biometricEnabled: boolean;
  pinEnabled: boolean;
  onBiometricUnlock: () => Promise<boolean>;
  onPinUnlock: (pin: string) => Promise<boolean>; // v8.1: async (PBKDF2)
}

export function LockScreen({
  enabled,
  biometricAvailable,
  biometricEnabled,
  pinEnabled,
  onBiometricUnlock,
  onPinUnlock,
}: LockScreenProps) {
  const [showPin, setShowPin] = useState(false);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // Auto-coba biometrik saat mount kalau aktif
  useEffect(() => {
    if (enabled && biometricAvailable && biometricEnabled) {
      tryBiometric();
    }
  }, []);

  async function tryBiometric() {
    setLoading(true);
    setError("");
    try {
      const ok = await onBiometricUnlock();
      if (!ok) {
        setError("Verifikasi biometrik gagal");
      }
    } catch (e: any) {
      setError(e?.message ?? "Gagal");
    } finally {
      setLoading(false);
    }
  }

  async function submitPin() {
    if (pin.length < 4) {
      setError("PIN minimal 4 digit");
      return;
    }
    setLoading(true);
    try {
      const ok = await onPinUnlock(pin);
      if (!ok) {
        setError("PIN salah");
        setPin("");
      }
    } catch {
      setError("PIN salah");
      setPin("");
    } finally {
      setLoading(false);
    }
  }

  if (!enabled) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur-xl">
      <div className="flex w-full max-w-sm flex-col items-center gap-6 px-6">
        {/* Logo */}
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-violet-500 to-pink-500 text-white shadow-2xl shadow-violet-900/50">
          <Lock className="h-10 w-10" />
        </div>

        <div className="text-center">
          <h1 className="text-xl font-bold bg-gradient-to-r from-violet-300 to-pink-300 bg-clip-text text-transparent">
            Uangku Pro Terkunci
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Verifikasi untuk membuka aplikasi
          </p>
        </div>

        {error && (
          <div className="rounded-lg bg-red-500/10 border border-red-500/30 px-4 py-2 text-sm text-red-400">
            {error}
          </div>
        )}

        {/* Tombol Biometrik */}
        {biometricAvailable && biometricEnabled && (
          <Button
            onClick={tryBiometric}
            disabled={loading}
            size="lg"
            className="w-full h-14 rounded-2xl bg-gradient-to-br from-violet-600 to-pink-600 text-white shadow-lg"
          >
            <Fingerprint className="h-6 w-6 mr-2" />
            {loading ? "Memverifikasi..." : "Buka dengan Biometrik"}
          </Button>
        )}

        {/* Atau PIN */}
        {pinEnabled && (
          <div className="w-full space-y-2">
            {biometricAvailable && biometricEnabled && !showPin ? (
              <Button
                variant="outline"
                onClick={() => setShowPin(true)}
                className="w-full h-12 rounded-xl border-border/50"
              >
                <ShieldCheck className="h-4 w-4 mr-2" />
                Gunakan PIN
              </Button>
            ) : (
              <>
                <Input
                  type="password"
                  inputMode="numeric"
                  placeholder="Masukkan PIN"
                  value={pin}
                  onChange={(e) => setPin(e.target.value.replace(/[^0-9]/g, ""))}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") submitPin();
                  }}
                  className="h-12 text-center text-lg tracking-widest bg-input/50 border-border/50"
                  autoFocus
                  maxLength={6}
                />
                <Button
                  onClick={submitPin}
                  className="w-full h-12 rounded-xl bg-primary text-primary-foreground"
                >
                  Buka
                </Button>
              </>
            )}
          </div>
        )}

        {/* Info keamanan */}
        <div className="rounded-xl glass p-3 border-border/50 w-full">
          <div className="flex items-start gap-2">
            <ShieldCheck className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
            <div className="text-xs text-muted-foreground">
              <p className="font-medium text-foreground">Aplikasi Terlindungi</p>
              <p className="mt-0.5">
                Data Anda tetap aman. Hanya Anda bisa membuka aplikasi dengan
                biometrik atau PIN.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
