"use client";

import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { useOCRReceipt, type OCRResult } from "@/hooks/use-ocr";
import { Camera, Loader2, X, ScanLine, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ReceiptScannerProps {
  onScanResult: (result: OCRResult) => void;
}

export function ReceiptScanner({ onScanResult }: ReceiptScannerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const { loading, result, error, scanImage } = useOCRReceipt();

  async function handleFile(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error("File harus gambar");
      return;
    }
    // [v9.0 fix] OCR-12: batasi ukuran gambar maksimal 5 MB untuk cegah OOM
    // WebView Android & payload base64 berlebih di server Next.js.
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Ukuran gambar maksimal 5 MB");
      return;
    }
    // [v9.0 TODO] Strip EXIF metadata (GPS, device info) sebelum upload untuk privacy
    // (audit OCR-11). Implementasi: re-encode via <canvas> dengan toDataURL("image/jpeg", 0.8).
    // Preview image
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(file);
    // Scan
    const res = await scanImage(file);
    if (res) {
      toast.success("Struk berhasil dibaca! Cek & sesuaikan data di bawah.");
      onScanResult(res);
    } else {
      toast.error("Gagal baca struk, isi manual saja");
    }
  }

  function clear() {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }

  return (
    <div className="space-y-2">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
        }}
      />

      {!preview && !loading && (
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="w-full rounded-xl border-2 border-dashed border-violet-500/40 bg-violet-500/5 p-4 text-center hover:bg-violet-500/10 transition-colors"
        >
          <Camera className="h-8 w-8 mx-auto text-violet-400" />
          <p className="mt-2 text-sm font-medium text-violet-400">
            Scan Struk/Nota
          </p>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            Foto struk belanja → AI ekstrak otomatis tanggal, total, & kategori
          </p>
        </button>
      )}

      {preview && (
        <div className="relative rounded-xl overflow-hidden border border-border/50">
          <img
            src={preview}
            alt="Struk preview"
            className="w-full h-32 object-cover"
          />
          {loading && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
              <div className="flex flex-col items-center gap-2 text-white">
                <Loader2 className="h-8 w-8 animate-spin" />
                <p className="text-xs">Sedang membaca struk...</p>
                <ScanLine className="h-4 w-4 animate-pulse" />
              </div>
            </div>
          )}
          <button
            type="button"
            onClick={clear}
            className="absolute top-1 right-1 rounded-full bg-black/60 p-1 text-white"
            aria-label="Hapus foto"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {error && (
        <p className="text-xs text-red-400">{error}</p>
      )}

      {result && !loading && (
        <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/30 p-2.5">
          <div className="flex items-center gap-1.5 text-emerald-400 mb-1">
            <Check className="h-3.5 w-3.5" />
            <span className="text-xs font-semibold">Hasil Scan</span>
          </div>
          <div className="space-y-0.5 text-xs">
            {result.merchant && (
              <div>
                <span className="text-muted-foreground">Merchant:</span>{" "}
                <span className="font-medium">{result.merchant}</span>
              </div>
            )}
            {result.date && (
              <div>
                <span className="text-muted-foreground">Tanggal:</span>{" "}
                <span className="font-medium">{result.date}</span>
              </div>
            )}
            {result.total !== undefined && (
              <div>
                <span className="text-muted-foreground">Total:</span>{" "}
                <span className="font-medium">
                  Rp {result.total.toLocaleString("id-ID")}
                </span>
              </div>
            )}
            {result.category && (
              <div>
                <span className="text-muted-foreground">Kategori:</span>{" "}
                <span className="font-medium">{result.category}</span>
              </div>
            )}
            {result.items && result.items.length > 0 && (
              <div className="text-muted-foreground">
                {result.items.length} item terdeteksi
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
