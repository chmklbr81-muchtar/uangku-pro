"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  type AppData,
  type Settings,
} from "@/lib/types";
import { useBiometric, simpleHash } from "@/hooks/use-biometric";
import { SupabaseAuthDialog } from "@/components/finance/supabase-auth-dialog";
import { ThemePicker } from "@/components/finance/theme-picker";
import { ActivityLogViewer } from "@/components/finance/activity-log-viewer";
import {
  hashPin,
  togglePrivacyBlur,
  createEncryptedBackup,
  decryptBackup,
  logActivity,
} from "@/lib/security-utils";
import {
  backupToGDrive,
  getStoredToken,
  parseTokenFromUrl,
  getOAuthUrl,
} from "@/lib/gdrive";
import {
  Fingerprint,
  Lock,
  ShieldCheck,
  Cloud,
  Database,
  RefreshCw,
  Check,
  X,
  Loader2,
  HelpCircle,
  ExternalLink,
  AlertCircle,
  LogIn,
  Palette,
  History,
  EyeOff,
  FileLock2,
  Upload,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface SecuritySettingsProps {
  data: AppData;
  onUpdateSettings: (s: Settings) => void;
  // [v9.0 fix] Prop baru untuk clear activityLogs (sebelumnya placeholder di onClear).
  onClearActivityLogs?: () => void;
}

export function SecuritySettingsPanel({
  data,
  onUpdateSettings,
  onClearActivityLogs,
}: SecuritySettingsProps) {
  const { isAvailable, register } = useBiometric();
  const [pinDialogOpen, setPinDialogOpen] = useState(false);
  const [newPin, setNewPin] = useState("");
  const [confirmPin, setConfirmPin] = useState("");
  const [pinSaving, setPinSaving] = useState(false);

  const settings = data.settings;

  async function toggleBiometric() {
    if (!isAvailable) {
      toast.error("Biometrik tidak tersedia di perangkat ini. Gunakan PIN.");
      return;
    }
    if (settings.biometricEnabled) {
      onUpdateSettings({ ...settings, biometricEnabled: false });
      localStorage.removeItem("uangku.biometricCredId");
      toast.success("Biometrik dimatikan");
      return;
    }
    try {
      await register();
      onUpdateSettings({ ...settings, biometricEnabled: true });
      toast.success("Biometrik diaktifkan");
    } catch (e: any) {
      toast.error(e?.message ?? "Gagal mendaftarkan biometrik");
    }
  }

  function togglePin() {
    if (settings.pinEnabled) {
      onUpdateSettings({ ...settings, pinEnabled: false, pinHash: undefined });
      localStorage.removeItem("uangku.pinHash");
      toast.success("PIN dimatikan");
      return;
    }
    setNewPin("");
    setConfirmPin("");
    setPinDialogOpen(true);
  }

  async function savePin() {
    if (newPin.length < 4) {
      toast.error("PIN minimal 4 digit");
      return;
    }
    if (newPin !== confirmPin) {
      toast.error("PIN tidak cocok");
      return;
    }
    setPinSaving(true);
    try {
      const hash = await hashPin(newPin);
      onUpdateSettings({ ...settings, pinEnabled: true, pinHash: hash });
      localStorage.setItem("uangku.pinHash", hash);
      setPinDialogOpen(false);
      toast.success("PIN diaktifkan (PBKDF2-SHA256, 150k iterasi)");
    } catch (e: any) {
      toast.error(e?.message ?? "Gagal menyimpan PIN");
    } finally {
      setPinSaving(false);
    }
  }

  function togglePrivacyBlurMode() {
    const newVal = !settings.privacyBlurMode;
    onUpdateSettings({ ...settings, privacyBlurMode: newVal });
    togglePrivacyBlur(newVal);
    toast.success(newVal ? "Mode privacy blur aktif" : "Mode privacy blur dimatikan");
  }

  function toggleLargeTxConfirm() {
    onUpdateSettings({
      ...settings,
      largeTxConfirmation: !settings.largeTxConfirmation,
    });
    toast.success(settings.largeTxConfirmation ? "Konfirmasi transaksi besar dimatikan" : "Konfirmasi transaksi besar diaktifkan");
  }

  return (
    <div className="space-y-3 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-1">
          <Lock className="h-4 w-4 text-violet-400" />
          <h2 className="text-sm font-semibold">Keamanan Aplikasi</h2>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          Lindungi data keuangan Anda dengan biometrik, PIN, atau privacy mode.
        </p>
      </Card>

      {/* Biometric */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl",
              settings.biometricEnabled ? "bg-emerald-500/10" : "bg-muted/40"
            )}>
              <Fingerprint className={cn(
                "h-5 w-5",
                settings.biometricEnabled ? "text-emerald-400" : "text-muted-foreground"
              )} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Biometrik (Fingerprint/Face)</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                {isAvailable
                  ? settings.biometricEnabled
                    ? "Aktif — buka aplikasi dengan sidik jari/Face Unlock"
                    : "Tersedia di perangkat ini"
                  : "Tidak tersedia di perangkat ini"}
              </p>
            </div>
          </div>
          <Button
            variant={settings.biometricEnabled ? "destructive" : "default"}
            size="sm"
            onClick={toggleBiometric}
            disabled={!isAvailable}
            className="h-8"
          >
            {settings.biometricEnabled ? "Matikan" : "Aktifkan"}
          </Button>
        </div>
      </Card>

      {/* PIN */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl",
              settings.pinEnabled ? "bg-emerald-500/10" : "bg-muted/40"
            )}>
              <Lock className={cn(
                "h-5 w-5",
                settings.pinEnabled ? "text-emerald-400" : "text-muted-foreground"
              )} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">PIN Aplikasi</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                {settings.pinEnabled
                  ? "Aktif — PBKDF2-SHA256 (150k iterasi)"
                  : "Cadangan kalau biometrik gagal"}
              </p>
            </div>
          </div>
          <Button
            variant={settings.pinEnabled ? "destructive" : "default"}
            size="sm"
            onClick={togglePin}
            className="h-8"
          >
            {settings.pinEnabled ? "Matikan" : "Aktifkan"}
          </Button>
        </div>
      </Card>

      {/* Privacy Blur Mode */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl",
              settings.privacyBlurMode ? "bg-emerald-500/10" : "bg-muted/40"
            )}>
              <EyeOff className={cn(
                "h-5 w-5",
                settings.privacyBlurMode ? "text-emerald-400" : "text-muted-foreground"
              )} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Mode Privacy (Blur Nominal)</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Sembunyikan nominal saat screenshot / screen recording.
              </p>
            </div>
          </div>
          <Button
            variant={settings.privacyBlurMode ? "destructive" : "default"}
            size="sm"
            onClick={togglePrivacyBlurMode}
            className="h-8"
          >
            {settings.privacyBlurMode ? "Matikan" : "Aktifkan"}
          </Button>
        </div>
      </Card>

      {/* Large Transaction Confirmation */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3 flex-1">
            <div className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl",
              settings.largeTxConfirmation ? "bg-emerald-500/10" : "bg-muted/40"
            )}>
              <ShieldCheck className={cn(
                "h-5 w-5",
                settings.largeTxConfirmation ? "text-emerald-400" : "text-muted-foreground"
              )} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">Konfirmasi Transaksi Besar</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                Minta konfirmasi kedua untuk transaksi ≥{" "}
                {new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR" }).format(settings.largeTxThreshold)}
              </p>
            </div>
          </div>
          <Button
            variant={settings.largeTxConfirmation ? "destructive" : "default"}
            size="sm"
            onClick={toggleLargeTxConfirm}
            className="h-8"
          >
            {settings.largeTxConfirmation ? "Matikan" : "Aktifkan"}
          </Button>
        </div>
        {settings.largeTxConfirmation && (
          <div className="mt-3 space-y-1.5">
            <Label htmlFor="large-tx-threshold" className="text-xs">Threshold (Rp)</Label>
            <Input
              id="large-tx-threshold"
              inputMode="numeric"
              value={String(settings.largeTxThreshold ?? 1_000_000)}
              onChange={(e) => {
                const n = Number(e.target.value.replace(/[^0-9]/g, ""));
                if (!isNaN(n) && n > 0) {
                  onUpdateSettings({ ...settings, largeTxThreshold: n });
                }
              }}
              className="bg-input/50 border-border/50 text-sm"
            />
          </div>
        )}
      </Card>

      {/* Info keamanan */}
      <Card className="glass p-3 border-emerald-500/30 bg-emerald-500/5">
        <div className="flex items-start gap-2">
          <ShieldCheck className="h-4 w-4 text-emerald-400 mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">
            <span className="font-medium text-foreground">100% Lokal & Privat.</span>{" "}
            Biometrik & PIN diverifikasi di perangkat Anda. PIN menggunakan PBKDF2-SHA256
            (150.000 iterasi). Tidak ada data yang dikirim ke server.
          </p>
        </div>
      </Card>

      {/* Activity Log */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-3">
          <History className="h-4 w-4 text-violet-400" />
          <h3 className="text-sm font-semibold">Riwayat Aktivitas</h3>
        </div>
        <ActivityLogViewer
          logs={data.activityLogs ?? []}
          // [v9.0 fix] Sebelumnya placeholder `() => onUpdateSettings(settings)` yang tidak
          // menghapus activityLogs. Sekarang panggil onClearActivityLogs dari parent (page.tsx)
          // yang melakukan setData(d => ({ ...d, activityLogs: [] })).
          onClear={() => {
            if (onClearActivityLogs) {
              onClearActivityLogs();
            } else {
              toast.error("Tidak bisa menghapus log dari sini.");
            }
          }}
        />
      </Card>

      {/* PIN Dialog */}
      <Dialog open={pinDialogOpen} onOpenChange={setPinDialogOpen}>
        <DialogContent className="sm:max-w-[360px] glass-strong border-0">
          <DialogHeader>
            <DialogTitle>Atur PIN Aplikasi</DialogTitle>
            <DialogDescription>
              Pilih PIN 4-6 digit. Hashing: PBKDF2-SHA256 (150.000 iterasi).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="new-pin">PIN Baru (4-6 digit)</Label>
              <Input
                id="new-pin"
                type="password"
                inputMode="numeric"
                value={newPin}
                onChange={(e) => setNewPin(e.target.value.replace(/[^0-9]/g, ""))}
                maxLength={6}
                className="text-center text-xl tracking-widest bg-input/50 border-border/50"
                placeholder="••••"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="confirm-pin">Konfirmasi PIN</Label>
              <Input
                id="confirm-pin"
                type="password"
                inputMode="numeric"
                value={confirmPin}
                onChange={(e) => setConfirmPin(e.target.value.replace(/[^0-9]/g, ""))}
                maxLength={6}
                className="text-center text-xl tracking-widest bg-input/50 border-border/50"
                placeholder="••••"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPinDialogOpen(false)} className="border-border/50" disabled={pinSaving}>
              Batal
            </Button>
            <Button onClick={savePin} className="bg-primary text-primary-foreground" disabled={pinSaving}>
              {pinSaving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : null}
              Simpan PIN
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// === Cloud & Sync Settings ===
interface CloudSettingsProps {
  data: AppData;
  onUpdateSettings: (s: Settings) => void;
  onBackupComplete?: () => void;
}

export function CloudSettingsPanel({ data, onUpdateSettings, onBackupComplete }: CloudSettingsProps) {
  const settings = data.settings;
  const [supabaseUrl, setSupabaseUrl] = useState(settings.supabaseUrl ?? "");
  const [supabaseKey, setSupabaseKey] = useState(settings.supabaseAnonKey ?? "");
  const [gdriveClientId, setGdriveClientId] = useState(settings.gdriveClientId ?? "");
  const [testing, setTesting] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [backupPasswordOpen, setBackupPasswordOpen] = useState(false);
  const [backupPassword, setBackupPassword] = useState("");
  const [restorePasswordOpen, setRestorePasswordOpen] = useState(false);
  const [restorePassword, setRestorePassword] = useState("");
  const [encryptedBackup, setEncryptedBackup] = useState("");
  const [gdriveBackingUp, setGdriveBackingUp] = useState(false);

  function saveSupabaseConfig() {
    onUpdateSettings({
      ...settings,
      supabaseUrl: supabaseUrl.trim() || undefined,
      supabaseAnonKey: supabaseKey.trim() || undefined,
    });
    toast.success("Konfigurasi Supabase disimpan");
  }

  async function testSupabase() {
    if (!supabaseUrl || !supabaseKey) {
      toast.error("Isi URL dan anon key dulu");
      return;
    }
    setTesting(true);
    try {
      const res = await fetch(`${supabaseUrl}/auth/v1/settings`, {
        method: "GET",
        headers: { apikey: supabaseKey },
      });
      if (res.ok) {
        toast.success("Koneksi Supabase berhasil!");
      } else {
        toast.error(`Gagal: Status ${res.status}`);
      }
    } catch (e: any) {
      toast.error(e?.message ?? "Network error");
    } finally {
      setTesting(false);
    }
  }

  function setupGDrive() {
    if (!gdriveClientId) {
      toast.error("Isi Google Client ID dulu");
      return;
    }
    onUpdateSettings({
      ...settings,
      gdriveClientId: gdriveClientId.trim(),
      autoBackupEnabled: true,
      autoBackupProvider: "gdrive",
    });
    const redirectUri = window.location.origin + window.location.pathname;
    // [v9.0 fix] T-2.3: pakai getOAuthUrl() dari gdrive.ts — generate random state nonce,
    // simpan ke sessionStorage, divalidasi di parseTokenFromUrl() untuk cegah CSRF/token substitution.
    const url = getOAuthUrl(gdriveClientId.trim(), redirectUri);
    window.location.href = url;
  }

  // v8.1: Backup ke GDrive setelah OAuth redirect
  // Dipanggil saat komponen mount jika URL mengandung hash access_token
  async function maybeCaptureGDriveToken() {
    if (typeof window === "undefined") return;
    const hash = window.location.hash;
    if (!hash || !(hash.includes("access_token") || hash.includes("error"))) return;
    // [v9.0 fix] T-2.3: parseTokenFromUrl sekarang bisa throw jika state mismatch / OAuth error.
    let tokenInfo;
    try {
      tokenInfo = parseTokenFromUrl();
    } catch (e: any) {
      // State mismatch → kemungkinan CSRF/token substitution; tampilkan error jelas ke user.
      toast.error(`Keamanan OAuth: ${e?.message ?? "validasi state gagal"}`);
      return;
    }
    if (!tokenInfo) return;
    toast.success("Login Google berhasil! Backup dimulai...");
    setGdriveBackingUp(true);
    try {
      const result = await backupToGDrive(data, tokenInfo.access_token);
      if (result.success) {
        toast.success("Backup ke Google Drive berhasil");
        onUpdateSettings({
          ...settings,
          lastBackupAt: new Date().toISOString(),
        });
        onBackupComplete?.();
      } else {
        toast.error(`Backup GDrive gagal: ${result.error ?? "unknown"}`);
      }
    } catch (e: any) {
      toast.error(e?.message ?? "Backup gagal");
    } finally {
      setGdriveBackingUp(false);
    }
  }

  // Trigger token capture on mount (run once)
  useEffect(() => {
    maybeCaptureGDriveToken();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleEncryptedBackup() {
    if (!backupPassword || backupPassword.length < 6) {
      toast.error("Password minimal 6 karakter");
      return;
    }
    try {
      const blob = await createEncryptedBackup(data, backupPassword);
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      const dateStr = new Date().toISOString().slice(0, 10);
      a.download = `uangku-encrypted-${dateStr}.enc`;
      a.click();
      URL.revokeObjectURL(url);
      setBackupPassword("");
      setBackupPasswordOpen(false);
      toast.success("Backup terenkripsi (AES-GCM) dibuat");
    } catch (e: any) {
      toast.error(e?.message ?? "Gagal membuat backup");
    }
  }

  async function handleEncryptedRestore(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!restorePassword) {
      toast.error("Masukkan password dulu");
      return;
    }
    try {
      const text = await f.text();
      const decrypted = await decryptBackup(text, restorePassword);
      if (!decrypted) {
        toast.error("Dekripsi gagal — password salah atau file rusak");
        return;
      }
      // Restore via parent
      const event = new CustomEvent("uangku-restore-encrypted", { detail: decrypted });
      window.dispatchEvent(event);
      setRestorePasswordOpen(false);
      toast.success("Backup terdekripsi, mengembalikan data...");
    } catch (e: any) {
      toast.error(e?.message ?? "Gagal restore");
    }
  }

  return (
    <div className="space-y-3 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-1">
          <Cloud className="h-4 w-4 text-violet-400" />
          <h2 className="text-sm font-semibold">Sinkronisasi Cloud</h2>
        </div>
        <p className="text-xs text-muted-foreground">
          Sync antar device (Supabase), backup otomatis (Google Drive), dan backup terenkripsi (AES-GCM).
        </p>
      </Card>

      {/* Supabase Sync Setup */}
      <Card className="glass p-4 border-border/50 space-y-3">
        <div className="flex items-center gap-2">
          <Database className="h-4 w-4 text-emerald-400" />
          <h3 className="text-sm font-semibold">Sync via Supabase (Granular v2.1)</h3>
          {settings.syncEnabled && (
            <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold text-emerald-400">
              <Check className="h-3 w-3" /> Aktif
            </span>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground">
          v2.1: per-collection merge dengan last-write-wins per item + soft-delete (30 hari).
          Backward-compat dengan skema v1.
        </p>
        <div className="space-y-1.5">
          <Label htmlFor="supabase-url" className="text-xs">Supabase Project URL</Label>
          <Input
            id="supabase-url"
            placeholder="https://xxxx.supabase.co"
            value={supabaseUrl}
            onChange={(e) => setSupabaseUrl(e.target.value)}
            className="bg-input/50 border-border/50 text-sm"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="supabase-key" className="text-xs">Anon Key (Public)</Label>
          <Input
            id="supabase-key"
            type="password"
            placeholder="eyJ..."
            value={supabaseKey}
            onChange={(e) => setSupabaseKey(e.target.value)}
            className="bg-input/50 border-border/50 text-sm"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={saveSupabaseConfig}
            className="border-border/50 flex-1 h-8"
          >
            Simpan
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={testSupabase}
            disabled={testing}
            className="border-border/50 flex-1 h-8"
          >
            {testing ? (
              <Loader2 className="h-3 w-3 mr-1 animate-spin" />
            ) : (
              <RefreshCw className="h-3 w-3 mr-1" />
            )}
            Test
          </Button>
        </div>
        <Button
          size="sm"
          onClick={() => setAuthOpen(true)}
          disabled={!settings.supabaseUrl || !settings.supabaseAnonKey}
          className="w-full h-10 gradient-gold text-primary-foreground border-0"
        >
          <LogIn className="h-4 w-4 mr-1" />
          {settings.syncEnabled ? "Kelola Sync" : "Login / Daftar untuk Sync"}
        </Button>
        <SupabaseAuthDialog
          open={authOpen}
          onOpenChange={setAuthOpen}
          settings={settings}
          data={data}
          onUpdateSettings={onUpdateSettings}
          onSyncComplete={(merged) => {
            window.dispatchEvent(new CustomEvent("uangku-sync-complete", { detail: merged }));
          }}
        />
        <a
          href="https://supabase.com/docs/guides/getting-started"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-[11px] text-violet-400 hover:underline"
        >
          <HelpCircle className="h-3 w-3" />
          Cara setup akun Supabase gratis
          <ExternalLink className="h-2.5 w-2.5" />
        </a>
      </Card>

      {/* Google Drive Backup Setup */}
      <Card className="glass p-4 border-border/50 space-y-3">
        <div className="flex items-center gap-2">
          <Cloud className="h-4 w-4 text-blue-400" />
          <h3 className="text-sm font-semibold">Auto-Backup Google Drive</h3>
          {settings.autoBackupEnabled && (
            <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold text-emerald-400">
              <Check className="h-3 w-3" /> Aktif
            </span>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground">
          Backup JSON ke folder "Uangku Pro" di Drive Anda. Token OAuth di-capture otomatis setelah redirect.
        </p>
        <div className="space-y-1.5">
          <Label htmlFor="gdrive-client" className="text-xs">Google OAuth Client ID</Label>
          <Input
            id="gdrive-client"
            placeholder="xxxx.apps.googleusercontent.com"
            value={gdriveClientId}
            onChange={(e) => setGdriveClientId(e.target.value)}
            className="bg-input/50 border-border/50 text-sm"
          />
        </div>
        <Button
          size="sm"
          onClick={setupGDrive}
          disabled={gdriveBackingUp}
          className="w-full h-8 bg-blue-600 hover:bg-blue-700 text-white"
        >
          {gdriveBackingUp ? (
            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
          ) : (
            <Cloud className="h-3 w-3 mr-1" />
          )}
          {gdriveBackingUp ? "Sedang backup..." : "Aktifkan & Backup Sekarang"}
        </Button>
        <a
          href="https://console.cloud.google.com/apis/credentials"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-[11px] text-violet-400 hover:underline"
        >
          <HelpCircle className="h-3 w-3" />
          Cara buat Google Client ID
          <ExternalLink className="h-2.5 w-2.5" />
        </a>
      </Card>

      {/* Encrypted Backup (AES-GCM) — v8.1 */}
      <Card className="glass p-4 border-border/50 space-y-3">
        <div className="flex items-center gap-2">
          <FileLock2 className="h-4 w-4 text-emerald-400" />
          <h3 className="text-sm font-semibold">Backup Terenkripsi (AES-GCM)</h3>
        </div>
        <p className="text-[11px] text-muted-foreground">
          Enkripsi seluruh data dengan password. Pakai AES-GCM 256-bit + PBKDF2-SHA256 (150k iterasi).
          Kompatibel dengan backup V1 (XOR cipher lama, tetap bisa di-restore).
        </p>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setBackupPassword("");
              setBackupPasswordOpen(true);
            }}
            className="border-border/50 flex-1 h-8"
          >
            <FileLock2 className="h-3 w-3 mr-1" />
            Buat Backup .enc
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              setRestorePassword("");
              setRestorePasswordOpen(true);
            }}
            className="border-border/50 flex-1 h-8"
          >
            <Upload className="h-3 w-3 mr-1" />
            Restore .enc
          </Button>
        </div>
      </Card>

      {/* Last sync / backup info */}
      {(settings.lastSyncAt || settings.lastBackupAt) && (
        <Card className="glass p-3 border-border/50">
          <p className="text-[10px] text-muted-foreground">
            {settings.lastSyncAt && (
              <div>
                <span className="font-semibold">Last sync:</span>{" "}
                {new Date(settings.lastSyncAt).toLocaleString("id-ID")}
              </div>
            )}
            {settings.lastBackupAt && (
              <div>
                <span className="font-semibold">Last backup:</span>{" "}
                {new Date(settings.lastBackupAt).toLocaleString("id-ID")}
              </div>
            )}
          </p>
        </Card>
      )}

      <Card className="glass p-3 border-amber-500/30 bg-amber-500/5">
        <div className="flex items-start gap-2">
          <AlertCircle className="h-4 w-4 text-amber-400 mt-0.5 shrink-0" />
          <p className="text-[11px] text-muted-foreground">
            <span className="font-medium text-foreground">Catatan:</span>{" "}
            Karena fitur ini butuh konfigurasi eksternal (akun Supabase/Google),
            ikuti panduan setup. Tanpa setup, aplikasi tetap jalan normal dengan backup JSON manual.
          </p>
        </div>
      </Card>

      {/* Encrypted Backup Dialog */}
      <Dialog open={backupPasswordOpen} onOpenChange={setBackupPasswordOpen}>
        <DialogContent className="sm:max-w-[360px] glass-strong border-0">
          <DialogHeader>
            <DialogTitle>Password Backup Terenkripsi</DialogTitle>
            <DialogDescription>
              Password ini dipakai untuk enkripsi AES-GCM. Tanpa password, data tidak bisa dipulihkan.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="bk-pwd">Password (min 6 karakter)</Label>
            <Input
              id="bk-pwd"
              type="password"
              value={backupPassword}
              onChange={(e) => setBackupPassword(e.target.value)}
              className="bg-input/50 border-border/50"
              autoFocus
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setBackupPasswordOpen(false)} className="border-border/50">
              Batal
            </Button>
            <Button onClick={handleEncryptedBackup} className="bg-primary text-primary-foreground">
              Buat Backup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Restore Dialog */}
      <Dialog open={restorePasswordOpen} onOpenChange={setRestorePasswordOpen}>
        <DialogContent className="sm:max-w-[360px] glass-strong border-0">
          <DialogHeader>
            <DialogTitle>Restore Backup Terenkripsi</DialogTitle>
            <DialogDescription>
              Masukkan password yang dipakai saat backup dibuat.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="rs-pwd">Password</Label>
            <Input
              id="rs-pwd"
              type="password"
              value={restorePassword}
              onChange={(e) => setRestorePassword(e.target.value)}
              className="bg-input/50 border-border/50"
              autoFocus
            />
            <Label htmlFor="rs-file" className="text-xs mt-2 block">File .enc</Label>
            <input
              id="rs-file"
              type="file"
              accept=".enc,.txt,application/octet-stream"
              onChange={handleEncryptedRestore}
              className="w-full text-xs"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRestorePasswordOpen(false)} className="border-border/50">
              Tutup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Theme Picker */}
      <ThemePicker
        currentTheme={settings.themeChoice}
        onChange={(theme) => {
          onUpdateSettings({ ...settings, themeChoice: theme });
        }}
      />
    </div>
  );
}
