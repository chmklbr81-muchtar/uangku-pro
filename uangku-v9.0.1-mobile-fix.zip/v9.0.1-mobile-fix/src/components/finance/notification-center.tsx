"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  type AppData,
  type AppNotification,
} from "@/lib/types";
import {
  getUpcomingBills,
  getLowBalanceWallets,
  getBudgetUsage,
  getWalletBalance,
  getMonthKey,
  todayISO,
  formatCurrency,
  formatDate,
} from "@/lib/finance";
import { generateSmartNotifications } from "@/lib/auto-categorize";
import {
  Bell,
  Calendar,
  PiggyBank,
  Wallet as WalletIcon,
  Trash2,
  Check,
  AlertTriangle,
  Settings2,
  Sparkles,
  Lightbulb,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface NotificationCenterProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  data: AppData;
  onUpdateSettings: (settings: AppData["settings"]) => void;
  onMarkAllRead: () => void;
  onClearNotifications: () => void;
}

export function NotificationCenter({
  open,
  onOpenChange,
  data,
  onUpdateSettings,
  onMarkAllRead,
  onClearNotifications,
}: NotificationCenterProps) {
  const [showSettings, setShowSettings] = useState(false);

  // Generate dynamic notifications
  const upcomingBills = getUpcomingBills(data.recurring, 3);
  const lowWallets = getLowBalanceWallets(data.wallets, data.transactions);
  const budgetUsage = getBudgetUsage(
    data.budgets,
    data.transactions,
    data.coa,
    getMonthKey(todayISO())
  );
  const budgetAlerts = budgetUsage.filter((b) => b.percent >= 80);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[440px] max-h-[90vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-violet-400" />
            Notifikasi
          </DialogTitle>
          <DialogDescription>
            Pengingat transaksi, anggaran, tagihan, & saldo dompet.
          </DialogDescription>
        </DialogHeader>

        {/* Quick stats */}
        <div className="grid grid-cols-4 gap-2">
          <StatCount
            icon={<Calendar className="h-3.5 w-3.5" />}
            count={upcomingBills.length}
            color="amber"
            label="Tagihan"
          />
          <StatCount
            icon={<AlertTriangle className="h-3.5 w-3.5" />}
            count={budgetAlerts.length}
            color="pink"
            label="Anggaran"
          />
          <StatCount
            icon={<WalletIcon className="h-3.5 w-3.5" />}
            count={lowWallets.length}
            color="red"
            label="Saldo"
          />
          <StatCount
            icon={<Bell className="h-3.5 w-3.5" />}
            count={data.notifications.filter((n) => !n.read).length}
            color="violet"
            label="Belum Dibaca"
          />
        </div>

        {/* Tabs: notifications / settings */}
        <div className="flex gap-1 rounded-lg bg-muted/40 p-1">
          <button
            onClick={() => setShowSettings(false)}
            className={cn(
              "flex-1 rounded-md py-1.5 text-xs font-semibold transition-colors",
              !showSettings
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground"
            )}
          >
            Pengingat Aktif
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className={cn(
              "flex-1 rounded-md py-1.5 text-xs font-semibold transition-colors",
              showSettings
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground"
            )}
          >
            Pengaturan
          </button>
        </div>

        {showSettings ? (
          <NotificationSettings
            data={data}
            onUpdateSettings={onUpdateSettings}
          />
        ) : (
          <ActiveNotifications
            data={data}
            upcomingBills={upcomingBills}
            budgetAlerts={budgetAlerts}
            lowWallets={lowWallets}
            onMarkAllRead={onMarkAllRead}
            onClearNotifications={onClearNotifications}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}

function StatCount({
  icon,
  count,
  color,
  label,
}: {
  icon: React.ReactNode;
  count: number;
  color: "amber" | "pink" | "red" | "violet";
  label: string;
}) {
  const colorMap = {
    amber: "text-amber-400 bg-amber-500/10",
    pink: "text-pink-400 bg-pink-500/10",
    red: "text-red-400 bg-red-500/10",
    violet: "text-violet-400 bg-violet-500/10",
  };
  return (
    <div className="rounded-lg border border-border/50 bg-muted/20 p-2 text-center">
      <div
        className={cn(
          "inline-flex items-center justify-center h-6 w-6 rounded-full mb-1",
          colorMap[color]
        )}
      >
        {icon}
      </div>
      <p className="text-sm font-bold tabular-nums">{count}</p>
      <p className="text-[9px] text-muted-foreground">{label}</p>
    </div>
  );
}

function ActiveNotifications({
  data,
  upcomingBills,
  budgetAlerts,
  lowWallets,
  onMarkAllRead,
  onClearNotifications,
}: {
  data: AppData;
  upcomingBills: ReturnType<typeof getUpcomingBills>;
  budgetAlerts: ReturnType<typeof getBudgetUsage>;
  lowWallets: ReturnType<typeof getLowBalanceWallets>;
  onMarkAllRead: () => void;
  onClearNotifications: () => void;
}) {
  const hasAny =
    upcomingBills.length > 0 ||
    budgetAlerts.length > 0 ||
    lowWallets.length > 0 ||
    data.notifications.length > 0;

  if (!hasAny) {
    return (
      <div className="py-10 text-center text-sm text-muted-foreground">
        <Bell className="h-10 w-10 mx-auto mb-2 text-muted-foreground/40" />
        Tidak ada pengingat aktif. Semua aman! 🎉
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Bill due */}
      {upcomingBills.length > 0 && (
        <div className="space-y-1.5">
          <h3 className="text-[11px] font-semibold uppercase tracking-wide text-amber-400">
            Tagihan Jatuh Tempo
          </h3>
          {upcomingBills.map((b) => {
            const days = Math.ceil(
              (new Date(b.nextRunDate).getTime() - Date.now()) /
                (24 * 60 * 60 * 1000)
            );
            return (
              <Card
                key={b.id}
                className="glass p-2.5 border-amber-500/30 border"
              >
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-amber-500/15">
                    <Calendar className="h-4 w-4 text-amber-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{b.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      Jatuh tempo {formatDate(b.nextRunDate)} ·{" "}
                      <span
                        className={
                          days <= 1
                            ? "text-red-400 font-semibold"
                            : "text-amber-400"
                        }
                      >
                        {days <= 0
                          ? "Hari ini!"
                          : days === 1
                          ? "Besok"
                          : `${days} hari lagi`}
                      </span>
                    </p>
                  </div>
                  <p className="text-sm font-bold text-pink-400 tabular-nums">
                    {formatCurrency(b.amount)}
                  </p>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Budget alerts */}
      {budgetAlerts.length > 0 && (
        <div className="space-y-1.5">
          <h3 className="text-[11px] font-semibold uppercase tracking-wide text-pink-400">
            Anggaran Hampir Habis
          </h3>
          {budgetAlerts.slice(0, 5).map((b) => (
            <Card
              key={b.budget.id}
              className={cn(
                "glass p-2.5 border",
                b.percent >= 100
                  ? "border-red-500/40"
                  : "border-amber-500/30"
              )}
            >
              <div className="flex items-center gap-2">
                <div
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-full",
                    b.percent >= 100
                      ? "bg-red-500/15"
                      : "bg-amber-500/15"
                  )}
                >
                  <AlertTriangle
                    className={cn(
                      "h-4 w-4",
                      b.percent >= 100
                        ? "text-red-400"
                        : "text-amber-400"
                    )}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{b.coaName}</p>
                  <p className="text-[11px] text-muted-foreground">
                    Terpakai {formatCurrency(b.used)} / {formatCurrency(b.budget.amount)}
                  </p>
                </div>
                <p
                  className={cn(
                    "text-sm font-bold tabular-nums",
                    b.percent >= 100 ? "text-red-400" : "text-amber-400"
                  )}
                >
                  {b.percent.toFixed(0)}%
                </p>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Low balance wallets */}
      {lowWallets.length > 0 && (
        <div className="space-y-1.5">
          <h3 className="text-[11px] font-semibold uppercase tracking-wide text-red-400">
            Saldo Minimum Terlampaui
          </h3>
          {lowWallets.map((w) => {
            const balance = getWalletBalance(w.id, data.transactions, data.wallets);
            return (
              <Card key={w.id} className="glass p-2.5 border-red-500/30 border">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-500/15">
                    <WalletIcon className="h-4 w-4 text-red-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">
                      {w.icon} {w.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      Saldo saat ini di bawah minimum ({formatCurrency(w.minAlert!)})
                    </p>
                  </div>
                  <p className="text-sm font-bold text-red-400 tabular-nums">
                    {formatCurrency(balance)}
                  </p>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Manual notifications */}
      {data.notifications.length > 0 && (
        <div className="space-y-1.5">
          <h3 className="text-[11px] font-semibold uppercase tracking-wide text-violet-400">
            Riwayat Notifikasi
          </h3>
          {data.notifications.slice(0, 10).map((n) => (
            <Card key={n.id} className="glass p-2.5 border-border/50">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-violet-500/15">
                  <Bell className="h-4 w-4 text-violet-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{n.title}</p>
                  <p className="text-[11px] text-muted-foreground truncate">
                    {n.message}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Smart Notifications — AI-generated insights */}
      <SmartNotificationsSection data={data} />

      {/* Action buttons */}
      {data.notifications.length > 0 && (
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onMarkAllRead}
            className="flex-1 border-border/50 h-8"
          >
            <Check className="h-3.5 w-3.5 mr-1" />
            Tandai Dibaca
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onClearNotifications}
            className="border-border/50 h-8 text-red-400 hover:text-red-500"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      )}
    </div>
  );
}

// === Smart Notifications Section ===
function SmartNotificationsSection({ data }: { data: AppData }) {
  const smartNotifs = generateSmartNotifications(data);
  if (smartNotifs.length === 0) return null;

  return (
    <div className="space-y-1.5">
      <h3 className="text-[11px] font-semibold uppercase tracking-wide text-gold flex items-center gap-1">
        <Sparkles className="h-3 w-3" />
        Smart Insights
      </h3>
      {smartNotifs.map((n) => {
        const Icon =
          n.type === "warning" ? AlertTriangle :
          n.type === "tip" ? Lightbulb :
          Bell;
        const color =
          n.type === "warning" ? "text-amber-400 bg-amber-500/10" :
          n.type === "tip" ? "text-gold bg-[oklch(0.78_0.16_85/0.10)]" :
          "text-blue-400 bg-blue-500/10";
        return (
          <Card key={n.id} className={cn("glass p-2.5 border-border/50 flex items-start gap-2", n.type === "tip" && "border-gold/30")}>
            <div className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-full", color)}>
              <Icon className="h-3.5 w-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium truncate">{n.title}</p>
              <p className="text-[11px] text-muted-foreground">{n.message}</p>
            </div>
          </Card>
        );
      })}
    </div>
  );
}

function NotificationSettings({
  data,
  onUpdateSettings,
}: {
  data: AppData;
  onUpdateSettings: (settings: AppData["settings"]) => void;
}) {
  const settings = data.settings;

  function requestNotificationPermission() {
    if (typeof window === "undefined" || !("Notification" in window)) {
      alert("Browser Anda tidak mendukung notifikasi.");
      return;
    }
    Notification.requestPermission().then((perm) => {
      if (perm === "granted") {
        onUpdateSettings({ ...settings, notificationsEnabled: true });
        new Notification("Uangku Pro", {
          body: "Notifikasi berhasil diaktifkan. Anda akan menerima pengingat transaksi, tagihan, dan anggaran.",
          icon: "/icon-192.png",
        });
      } else {
        onUpdateSettings({ ...settings, notificationsEnabled: false });
        alert("Notifikasi ditolak. Aktifkan dari pengaturan browser untuk menerima pengingat.");
      }
    });
  }

  return (
    <div className="space-y-3">
      {/* Enable notifications */}
      <Card className="glass p-3 border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4 text-violet-400" />
            <div>
              <p className="text-sm font-medium">Notifikasi Browser</p>
              <p className="text-[11px] text-muted-foreground">
                {settings.notificationsEnabled
                  ? "Aktif — pengingat akan dikirim via browser"
                  : "Klik untuk aktifkan & beri izin notifikasi"}
              </p>
            </div>
          </div>
          {settings.notificationsEnabled ? (
            <Check className="h-5 w-5 text-emerald-400" />
          ) : (
            <Button size="sm" onClick={requestNotificationPermission}>
              Aktifkan
            </Button>
          )}
        </div>
      </Card>

      {/* Daily reminder */}
      <Card className="glass p-3 border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="h-4 w-4 text-violet-400" />
            <div>
              <p className="text-sm font-medium">Pengingat Catat Harian</p>
              <p className="text-[11px] text-muted-foreground">
                Notifikasi harian untuk catat transaksi
              </p>
            </div>
          </div>
          <Switch
            checked={settings.dailyReminderEnabled}
            onCheckedChange={(v) =>
              onUpdateSettings({ ...settings, dailyReminderEnabled: v })
            }
          />
        </div>
        {settings.dailyReminderEnabled && (
          <div className="mt-3 flex items-center gap-2">
            <Label htmlFor="reminder-hour" className="text-xs">
              Jam pengingat:
            </Label>
            <Input
              id="reminder-hour"
              type="number"
              min={0}
              max={23}
              value={settings.dailyReminderHour}
              onChange={(e) =>
                onUpdateSettings({
                  ...settings,
                  dailyReminderHour: Number(e.target.value),
                })
              }
              className="w-20 bg-input/50 border-border/50"
            />
            <span className="text-xs text-muted-foreground">
              (0-23, format 24 jam)
            </span>
          </div>
        )}
      </Card>

      {/* Budget threshold */}
      <Card className="glass p-3 border-border/50">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="h-4 w-4 text-amber-400" />
          <div>
            <p className="text-sm font-medium">Ambang Anggaran</p>
            <p className="text-[11px] text-muted-foreground">
              Kapan alert anggaran muncul
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor="threshold" className="text-xs">
            Alert jika pemakaian ≥
          </Label>
          <Input
            id="threshold"
            type="number"
            min={50}
            max={100}
            value={settings.budgetAlertThreshold}
            onChange={(e) =>
              onUpdateSettings({
                ...settings,
                budgetAlertThreshold: Number(e.target.value),
              })
            }
            className="w-20 bg-input/50 border-border/50"
          />
          <span className="text-xs text-muted-foreground">%</span>
        </div>
      </Card>

      {/* Info */}
      <div className="rounded-lg bg-violet-500/10 border border-violet-500/20 p-3 text-xs text-muted-foreground">
        💡 <span className="text-foreground">Tips:</span> Untuk menerima
        pengingat tagihan, pastikan Anda sudah membuat template Transaksi
        Berulang di tab Anggaran. Pengingat akan muncul saat aplikasi dibuka.
      </div>
    </div>
  );
}
