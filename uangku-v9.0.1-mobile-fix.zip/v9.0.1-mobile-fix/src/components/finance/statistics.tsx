"use client";

// [v9.0] Dead code — signature mismatch dengan caller. To remove in v9.1.
// Komponen ini tidak diimpor mana pun dan signature props ({ transactions, onAdd })
// tidak match dengan caller mana pun di page.tsx (sudah diganti AnalyticsDashboard).
// Tetap dipertahankan di v9.0 untuk hindari break import path; akan dihapus di v9.1.
// v8.1: Statistics — rewritten to use real exports from finance.ts
// (was dead code referencing getCategory/sumByCategory/sumByMonth/CHART_COLORS which never existed)
//
// This component is optional / orphaned — not imported anywhere in the app —
// but kept functional in case a future view wants to embed it.
// Audit trail: file ini tetap dipertahankan untuk konsistensi riwayat perbaikan (task 12-D A-09).

import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import {
  type Transaction,
} from "@/lib/types";
import {
  formatCurrency,
  formatCompact,
  getMonthKey,
  getMonthLabel,
  getMonthlySeries,
  sumByCOA,
  todayISO,
} from "@/lib/finance";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { PieChart as PieIcon, BarChart3, TrendingUp, Wallet } from "lucide-react";

const CHART_COLORS = [
  "#f59e0b", "#10b981", "#3b82f6", "#a855f7",
  "#ec4899", "#ef4444", "#06b6d4", "#84cc16",
  "#f97316", "#6366f1", "#14b8a6", "#eab308",
];

interface StatisticsProps {
  transactions: Transaction[];
  onAdd: () => void;
}

export function Statistics({ transactions, onAdd }: StatisticsProps) {
  // 6-month series (income vs expense)
  const monthlyData = useMemo(() => {
    const series = getMonthlySeries(transactions, 6);
    return series.map((m) => ({
      month: getMonthLabel(m.monthKey).split(" ")[0],
      Masuk: m.income,
      Keluar: m.expense,
    }));
  }, [transactions]);

  // Spending per COA category for current month
  const monthKey = getMonthKey(todayISO());
  const monthExpenses = useMemo(
    () => transactions.filter((t) => t.type === "expense" && getMonthKey(t.date) === monthKey),
    [transactions, monthKey]
  );
  const byCategory = useMemo(() => sumByCOA(monthExpenses, "expense"), [monthExpenses]);
  const pieData = useMemo(
    () =>
      byCategory
        .sort((a, b) => b.total - a.total)
        .slice(0, 8)
        .map((c) => ({ name: c.coaId, value: c.total })),
    [byCategory]
  );

  const totalExpense = monthExpenses.reduce((a, t) => a + t.amount, 0);
  const totalIncome = transactions
    .filter((t) => t.type === "income" && getMonthKey(t.date) === monthKey)
    .reduce((a, t) => a + t.amount, 0);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <Card className="glass p-3 border-border/50">
          <div className="flex items-center gap-1.5 text-emerald-400 text-xs">
            <TrendingUp className="h-3.5 w-3.5" />
            <span className="font-semibold">Pemasukan</span>
          </div>
          <p className="text-lg font-bold mt-1">{formatCompact(totalIncome)}</p>
          <p className="text-[10px] text-muted-foreground">{formatCurrency(totalIncome)}</p>
        </Card>
        <Card className="glass p-3 border-border/50">
          <div className="flex items-center gap-1.5 text-pink-400 text-xs">
            <Wallet className="h-3.5 w-3.5" />
            <span className="font-semibold">Pengeluaran</span>
          </div>
          <p className="text-lg font-bold mt-1">{formatCompact(totalExpense)}</p>
          <p className="text-[10px] text-muted-foreground">{formatCurrency(totalExpense)}</p>
        </Card>
      </div>

      {/* Pie chart per kategori */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-1.5 mb-2">
          <PieIcon className="h-4 w-4 text-violet-400" />
          <h3 className="text-sm font-semibold">Per Kategori (Bulan Ini)</h3>
        </div>
        {pieData.length === 0 ? (
          <p className="text-xs text-muted-foreground py-6 text-center">
            Belum ada pengeluaran bulan ini.
          </p>
        ) : (
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {pieData.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(v: number) => formatCurrency(v)}
                contentStyle={{ background: "rgba(20,15,40,0.95)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8 }}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </PieChart>
          </ResponsiveContainer>
        )}
      </Card>

      {/* Bar chart 6 bulan */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-1.5 mb-2">
          <BarChart3 className="h-4 w-4 text-blue-400" />
          <h3 className="text-sm font-semibold">Tren 6 Bulan</h3>
        </div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={monthlyData}>
            <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} />
            {/* [v9.0 fix] Format axis sebagai Rupiah, bukan raw number */}
            <YAxis
              stroke="#94a3b8"
              fontSize={11}
              tickFormatter={(v: number) => formatCurrency(Number(v))}
              width={96}
            />
            <Tooltip
              formatter={(v: number) => formatCurrency(v)}
              contentStyle={{ background: "rgba(20,15,40,0.95)", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 8 }}
            />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Bar dataKey="Masuk" fill="#10b981" radius={[4, 4, 0, 0]} />
            <Bar dataKey="Keluar" fill="#ec4899" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {onAdd && (
        <button
          onClick={onAdd}
          className="w-full rounded-xl border-2 border-dashed border-border/60 py-2.5 text-xs text-muted-foreground hover:bg-accent transition-colors"
        >
          + Tambah transaksi
        </button>
      )}
    </div>
  );
}
