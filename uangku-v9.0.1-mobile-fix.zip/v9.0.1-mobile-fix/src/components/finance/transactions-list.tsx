"use client";

import { useMemo, useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
  type Transaction,
} from "@/lib/types";
import {
  formatCurrency,
  formatDate,
  getWallet,
  getCOAAccount,
} from "@/lib/finance";
import { getLeafAccounts } from "@/lib/default-data";
import {
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  Receipt,
  Filter,
  Search,
  X,
  Trash2,
  Edit2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { todayISO } from "@/lib/finance";

interface TransactionsListProps {
  data: AppData;
  onOpenTransaction: (tx: Transaction) => void;
  onAdd: () => void;
  onDeleteTransaction?: (id: string) => void;
}

type FilterType = "all" | "income" | "expense" | "transfer";
type DatePreset = "all" | "today" | "7days" | "month" | "year";

export function TransactionsList({
  data,
  onOpenTransaction,
  onAdd,
  onDeleteTransaction,
}: TransactionsListProps) {
  const [filter, setFilter] = useState<FilterType>("all");
  const [walletFilter, setWalletFilter] = useState<string>("all");
  const [search, setSearch] = useState<string>("");
  const [showFilter, setShowFilter] = useState(false);
  const [datePreset, setDatePreset] = useState<DatePreset>("all");
  const [swipedId, setSwipedId] = useState<string | null>(null);
  const [longPressId, setLongPressId] = useState<string | null>(null);
  // [v9.0 fix] Simple windowing untuk 100+ transactions; full virtualization di v9.1.
  // Default 100 transaksi terbaru ditampilkan; user klik "Tampilkan lebih banyak"
  // untuk expand +100. Mencegah render ribuan TransactionRow sekaligus (lag).
  const [visibleCount, setVisibleCount] = useState(100);

  const dateRange = useMemo(() => {
    if (datePreset === "all") return null;
    const today = todayISO();
    const now = new Date();
    if (datePreset === "today") {
      return { start: today, end: today };
    } else if (datePreset === "7days") {
      const start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      return {
        start: `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(start.getDate()).padStart(2, "0")}`,
        end: today,
      };
    } else if (datePreset === "month") {
      return {
        start: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`,
        end: today,
      };
    } else if (datePreset === "year") {
      return {
        start: `${now.getFullYear()}-01-01`,
        end: today,
      };
    }
    return null;
  }, [datePreset]);

  const filtered = useMemo(() => {
    // [v9.0 fix] T-1.2: filter soft-deleted transaksi (deletedAt < 30 hari yang lalu) dari tampilan.
    // Item tetap di data.transactions untuk propagate deletion via sync; setelah 30 hari
    // mergeCollection() di supabaseSmartSync akan purge permanen.
    const SOFT_DELETE_WINDOW_MS = 30 * 24 * 60 * 60 * 1000;
    let result = data.transactions.filter((t) => {
      if (!t.deletedAt) return true;
      return Date.now() - new Date(t.deletedAt).getTime() >= SOFT_DELETE_WINDOW_MS;
    });
    if (filter !== "all") result = result.filter((t) => t.type === filter);
    if (walletFilter !== "all")
      result = result.filter((t) => t.walletId === walletFilter);
    if (dateRange) {
      result = result.filter(
        (t) => t.date >= dateRange.start && t.date <= dateRange.end
      );
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (t) =>
          t.note?.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          (t.tags ?? []).some((tag) => tag.includes(q))
      );
    }
    return [...result].sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.createdAt.localeCompare(a.createdAt);
    });
  }, [data.transactions, filter, walletFilter, search, dateRange]);

  // [v9.0 fix] Windowing: batasi render ke `visibleCount` transaksi terbaru.
  // `totals` tetap dihitung dari `filtered` (semua) agar ringkasan tetap akurat.
  const windowed = useMemo(
    () => filtered.slice(0, visibleCount),
    [filtered, visibleCount]
  );

  const groups = useMemo(() => {
    const map: Record<string, Transaction[]> = {};
    for (const t of windowed) {
      if (!map[t.date]) map[t.date] = [];
      map[t.date].push(t);
    }
    return map;
  }, [windowed]);

  const dateKeys = Object.keys(groups);

  const totals = useMemo(() => {
    const income = filtered
      .filter((t) => t.type === "income")
      .reduce((a, t) => a + t.amount, 0);
    const expense = filtered
      .filter((t) => t.type === "expense")
      .reduce((a, t) => a + t.amount, 0);
    const transfer = filtered
      .filter((t) => t.type === "transfer")
      .reduce((a, t) => a + t.amount, 0);
    return { income, expense, transfer };
  }, [filtered]);

  const hasFilter = filter !== "all" || walletFilter !== "all" || search.trim() !== "";
  const activeWallets = data.wallets.filter((w) => !w.archived);

  return (
    <div className="space-y-4 pb-4">
      {/* Ringkasan */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="glass p-2.5 border-border/50">
          <div className="flex items-center gap-1 text-emerald-400">
            <ArrowDownLeft className="h-3 w-3" />
            <span className="text-[10px] font-medium">Masuk</span>
          </div>
          <p className="mt-0.5 text-sm font-bold text-emerald-400 truncate">
            {formatCurrency(totals.income)}
          </p>
        </Card>
        <Card className="glass p-2.5 border-border/50">
          <div className="flex items-center gap-1 text-red-400">
            <ArrowUpRight className="h-3 w-3" />
            <span className="text-[10px] font-medium">Keluar</span>
          </div>
          <p className="mt-0.5 text-sm font-bold text-red-400 truncate">
            {formatCurrency(totals.expense)}
          </p>
        </Card>
        <Card className="glass p-2.5 border-border/50">
          <div className="flex items-center gap-1 text-gold">
            <ArrowLeftRight className="h-3 w-3" />
            <span className="text-[10px] font-medium">Transfer</span>
          </div>
          <p className="mt-0.5 text-sm font-bold text-gold truncate">
            {formatCurrency(totals.transfer)}
          </p>
        </Card>
      </div>

      {/* Quick Date Filter chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">
        {(
          [
            { id: "all", label: "Semua" },
            { id: "today", label: "Hari Ini" },
            { id: "7days", label: "7 Hari" },
            { id: "month", label: "Bulan Ini" },
            { id: "year", label: "Tahun Ini" },
          ] as { id: DatePreset; label: string }[]
        ).map((p) => (
          <button
            key={p.id}
            onClick={() => setDatePreset(p.id)}
            className={cn(
              "shrink-0 rounded-full px-3 py-1 text-xs font-semibold transition-colors",
              datePreset === p.id
                ? "gradient-gold text-primary-foreground"
                : "bg-muted/40 text-muted-foreground hover:bg-accent"
            )}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Search + filter toggle */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Cari catatan, kategori, tag..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-input/50 border-border/50"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Bersihkan"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button
          variant={showFilter ? "default" : "outline"}
          size="icon"
          onClick={() => setShowFilter((s) => !s)}
          aria-label="Filter"
          className={cn(showFilter && "bg-primary text-primary-foreground")}
        >
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Filter dropdown */}
      {showFilter && (
        <Card className="glass p-3 space-y-3 border-border/50">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Tipe</label>
            <div className="grid grid-cols-4 gap-1.5">
              {(
                [
                  { id: "all", label: "Semua" },
                  { id: "income", label: "Masuk" },
                  { id: "expense", label: "Keluar" },
                  { id: "transfer", label: "Transfer" },
                ] as { id: FilterType; label: string }[]
              ).map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setFilter(opt.id)}
                  className={cn(
                    "rounded-lg px-2 py-1.5 text-xs font-semibold transition-colors",
                    filter === opt.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted/60 text-muted-foreground hover:bg-accent"
                  )}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Dompet</label>
            <Select value={walletFilter} onValueChange={setWalletFilter}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="Semua dompet" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50">
                <SelectItem value="all">Semua Dompet</SelectItem>
                {activeWallets.map((w) => (
                  <SelectItem key={w.id} value={w.id}>
                    {w.icon} {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {hasFilter && (
            <Button
              variant="ghost"
              size="sm"
              className="w-full"
              onClick={() => {
                setFilter("all");
                setWalletFilter("all");
                setSearch("");
              }}
            >
              Reset Filter
            </Button>
          )}
        </Card>
      )}

      {/* Daftar */}
      {dateKeys.length === 0 ? (
        <Card className="glass flex flex-col items-center justify-center gap-3 p-10 text-center border-border/50">
          <div className="rounded-full bg-muted/40 p-4">
            <Receipt className="h-8 w-8 text-muted-foreground" />
          </div>
          <div>
            <p className="font-medium">Tidak ada transaksi</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              {hasFilter
                ? "Tidak ada transaksi yang cocok dengan filter."
                : "Belum ada transaksi tercatat."}
            </p>
          </div>
          <Button onClick={onAdd} size="sm" className="bg-primary text-primary-foreground">
            Tambah Sekarang
          </Button>
        </Card>
      ) : (
        <div className="space-y-4">
          {dateKeys.map((date) => {
            const items = groups[date];
            const dayIncome = items
              .filter((t) => t.type === "income")
              .reduce((a, t) => a + t.amount, 0);
            const dayExpense = items
              .filter((t) => t.type === "expense")
              .reduce((a, t) => a + t.amount, 0);
            return (
              <div key={date} className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <h3 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    {formatDate(date)}
                  </h3>
                  <span className="text-[11px] font-medium tabular-nums text-muted-foreground">
                    {dayIncome > 0 && (
                      <span className="text-emerald-400">
                        +{formatCurrency(dayIncome)}
                      </span>
                    )}
                    {dayIncome > 0 && dayExpense > 0 && (
                      <span className="mx-1">·</span>
                    )}
                    {dayExpense > 0 && (
                      <span className="text-pink-400">
                        −{formatCurrency(dayExpense)}
                      </span>
                    )}
                  </span>
                </div>
                <div className="space-y-2">
                  {items.map((t) => (
                    <TransactionRow
                      key={t.id}
                      t={t}
                      data={data}
                      onClick={() => onOpenTransaction(t)}
                      onDelete={
                        onDeleteTransaction
                          ? () => {
                              if (confirm("Hapus transaksi ini?")) {
                                onDeleteTransaction(t.id);
                              }
                            }
                          : undefined
                      }
                    />
                  ))}
                </div>
              </div>
            );
          })}
          {/* [v9.0 fix] Windowing: tombol "Tampilkan lebih banyak" saat ada sisa. */}
          {filtered.length > visibleCount && (
            <div className="pt-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full border-border/50"
                onClick={() => setVisibleCount((c) => c + 100)}
              >
                Tampilkan lebih banyak
                <span className="ml-1 text-[10px] text-muted-foreground">
                  ({visibleCount}/{filtered.length})
                </span>
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function TransactionRow({
  t,
  data,
  onClick,
  onDelete,
}: {
  t: Transaction;
  data: AppData;
  onClick: () => void;
  onDelete?: () => void;
}) {
  const wallet = getWallet(data.wallets, t.walletId);
  const coa = getCOAAccount(data.coa, t.coaId);
  const isIncome = t.type === "income";
  const isTransfer = t.type === "transfer";
  const color = isIncome
    ? "text-emerald-400"
    : isTransfer
    ? "text-gold"
    : "text-red-400";
  const bg = isIncome
    ? "bg-emerald-500/10"
    : isTransfer
    ? "bg-[oklch(0.78_0.16_85/0.10)]"
    : "bg-red-500/10";
  const sign = isIncome ? "+" : isTransfer ? "↔" : "−";
  const targetWallet = isTransfer
    ? getWallet(data.wallets, t.transferToWalletId ?? "")
    : null;

  // Long-press untuk hapus cepat
  const [longPressActive, setLongPressActive] = useState(false);
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);

  function handlePointerDown() {
    longPressTimer.current = setTimeout(() => {
      setLongPressActive(true);
      // Vibrate kalau support
      if (typeof navigator !== "undefined" && "vibrate" in navigator) {
        navigator.vibrate(50);
      }
    }, 600);
  }
  function handlePointerUp() {
    if (longPressTimer.current) clearTimeout(longPressTimer.current);
    if (longPressActive && onDelete) {
      onDelete();
      setLongPressActive(false);
    } else {
      setLongPressActive(false);
    }
  }
  function handlePointerLeave() {
    if (longPressTimer.current) clearTimeout(longPressTimer.current);
  }

  return (
    <button
      onClick={onClick}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerLeave}
      className={cn(
        "flex w-full items-center gap-3 rounded-xl glass p-3 text-left hover:bg-accent transition-colors border-border/50 hover-smooth swipe-row",
        longPressActive && "long-press-active"
      )}
    >
      <div
        className={cn(
          "flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-lg",
          bg
        )}
      >
        {wallet?.icon ?? "💵"}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">
          {coa?.name ?? t.category}
          {isTransfer && targetWallet && (
            <span className="text-muted-foreground"> → {targetWallet.icon} {targetWallet.name}</span>
          )}
        </p>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="truncate">{t.note ?? (wallet?.name ?? "")}</span>
          {(t.tags ?? []).slice(0, 2).map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-primary/15 px-1.5 py-0.5 text-[10px] text-primary"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>
      <div className="text-right">
        <p className={cn("text-sm font-bold tabular-nums", color)}>
          {sign}
          {formatCurrency(t.amount)}
        </p>
        {longPressActive && (
          <p className="text-[9px] text-red-400 font-semibold">lepaskan untuk hapus</p>
        )}
      </div>
    </button>
  );
}
