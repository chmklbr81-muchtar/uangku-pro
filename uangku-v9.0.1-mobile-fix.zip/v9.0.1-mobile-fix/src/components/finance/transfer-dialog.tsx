"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
  type Transaction,
  type Wallet,
} from "@/lib/types";
import { todayISO, genId, getWalletBalance } from "@/lib/finance";
import { ArrowLeftRight, Check } from "lucide-react";
import { useState } from "react";

interface TransferDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: AppData;
  onTransfer: (fromTx: Transaction, toTx: Transaction) => void;
  defaultFromWalletId?: string;
}

export function TransferDialog({
  open,
  onOpenChange,
  data,
  onTransfer,
  defaultFromWalletId,
}: TransferDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[440px] max-h-[92vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold flex items-center gap-2">
            <ArrowLeftRight className="h-5 w-5 text-violet-400" />
            Transfer Antar-Dompet
          </DialogTitle>
          <DialogDescription>
            Pindahkan dana antar dompet tanpa menggandakan pemasukan/pengeluaran.
          </DialogDescription>
        </DialogHeader>
        <TransferForm
          key={open ? "open" : "closed"}
          data={data}
          onTransfer={onTransfer}
          onClose={() => onOpenChange(false)}
          defaultFromWalletId={defaultFromWalletId}
        />
      </DialogContent>
    </Dialog>
  );
}

interface TransferFormProps {
  data: AppData;
  onTransfer: (fromTx: Transaction, toTx: Transaction) => void;
  onClose: () => void;
  defaultFromWalletId?: string;
}

function TransferForm({
  data,
  onTransfer,
  onClose,
  defaultFromWalletId,
}: TransferFormProps) {
  const activeWallets = data.wallets.filter((w) => !w.archived);
  const [fromWalletId, setFromWalletId] = useState<string>(
    defaultFromWalletId ?? activeWallets[0]?.id ?? ""
  );
  const [toWalletId, setToWalletId] = useState<string>(
    activeWallets.find((w) => w.id !== fromWalletId)?.id ?? ""
  );
  const [amount, setAmount] = useState<string>("");
  const [date, setDate] = useState<string>(todayISO());
  const [note, setNote] = useState<string>("");
  const [error, setError] = useState<string>("");

  const fromWallet = activeWallets.find((w) => w.id === fromWalletId);
  const fromBalance = fromWallet
    ? getWalletBalance(fromWalletId, data.transactions, data.wallets)
    : 0;

  function handleAmountChange(raw: string) {
    const onlyDigits = raw.replace(/[^0-9]/g, "");
    if (!onlyDigits) {
      setAmount("");
      return;
    }
    setAmount(Number(onlyDigits).toLocaleString("id-ID"));
  }

  function handleSubmit() {
    const numAmount = Number(amount.replace(/[^0-9]/g, ""));
    if (!numAmount || numAmount <= 0) {
      setError("Jumlah harus lebih dari 0");
      return;
    }
    if (!fromWalletId || !toWalletId) {
      setError("Pilih dompet asal dan tujuan");
      return;
    }
    if (fromWalletId === toWalletId) {
      setError("Dompet asal & tujuan tidak boleh sama");
      return;
    }
    if (numAmount > fromBalance) {
      setError("Saldo dompet asal tidak cukup");
      return;
    }
    const now = new Date().toISOString();
    const pairId = genId();
    // Expense di dompet asal
    const fromTx: Transaction = {
      id: genId(),
      type: "transfer",
      amount: numAmount,
      date,
      walletId: fromWalletId,
      coaId: "coa-1-1000", // Kas & Setara Kas
      category: "Transfer Keluar",
      note: note.trim() || `Transfer ke ${data.wallets.find((w) => w.id === toWalletId)?.name}`,
      transferToWalletId: toWalletId,
      transferPairId: pairId,
      createdAt: now,
    };
    // Income di dompet tujuan
    const toTx: Transaction = {
      id: genId(),
      type: "transfer",
      amount: numAmount,
      date,
      walletId: toWalletId,
      coaId: "coa-1-1000",
      category: "Transfer Masuk",
      note: note.trim() || `Transfer dari ${data.wallets.find((w) => w.id === fromWalletId)?.name}`,
      transferToWalletId: fromWalletId,
      transferPairId: pairId,
      createdAt: now,
    };
    onTransfer(fromTx, toTx);
    onClose();
  }

  return (
    <>
      {/* Saldo dompet asal */}
      {fromWallet && (
        <div className="rounded-xl bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
          Saldo{" "}
          <span className="font-semibold text-foreground">
            {fromWallet.icon} {fromWallet.name}
          </span>
          :{" "}
          <span
            className={
              fromBalance < 0
                ? "text-red-400 font-semibold"
                : "text-emerald-400 font-semibold"
            }
          >
            {new Intl.NumberFormat("id-ID", {
              style: "currency",
              currency: "IDR",
              maximumFractionDigits: 0,
            }).format(fromBalance)}
          </span>
        </div>
      )}

      {/* Dompet asal */}
      <div className="space-y-1.5">
        <Label>Dari Dompet</Label>
        <Select value={fromWalletId} onValueChange={setFromWalletId}>
          <SelectTrigger className="bg-input/50 border-border/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="glass-strong border-border/50 max-h-72">
            {activeWallets.map((w) => (
              <SelectItem key={w.id} value={w.id}>
                <span className="mr-2">{w.icon}</span>
                {w.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Dompet tujuan */}
      <div className="space-y-1.5">
        <Label>Ke Dompet</Label>
        <Select value={toWalletId} onValueChange={setToWalletId}>
          <SelectTrigger className="bg-input/50 border-border/50">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="glass-strong border-border/50 max-h-72">
            {activeWallets
              .filter((w) => w.id !== fromWalletId)
              .map((w) => (
                <SelectItem key={w.id} value={w.id}>
                  <span className="mr-2">{w.icon}</span>
                  {w.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
      </div>

      {/* Jumlah */}
      <div className="space-y-1.5">
        <Label htmlFor="transfer-amount">Jumlah</Label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
            Rp
          </span>
          <Input
            id="transfer-amount"
            inputMode="numeric"
            placeholder="0"
            value={amount}
            onChange={(e) => handleAmountChange(e.target.value)}
            className="pl-10 text-lg font-semibold bg-input/50 border-border/50"
            autoFocus
          />
        </div>
        {error && <p className="text-xs text-red-400">{error}</p>}
      </div>

      {/* Tanggal */}
      <div className="space-y-1.5">
        <Label htmlFor="transfer-date">Tanggal</Label>
        <Input
          id="transfer-date"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="bg-input/50 border-border/50"
        />
      </div>

      {/* Catatan */}
      <div className="space-y-1.5">
        <Label htmlFor="transfer-note">Catatan (opsional)</Label>
        <Textarea
          id="transfer-note"
          placeholder="Contoh: Tarik tunai ATM"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          rows={2}
          className="bg-input/50 border-border/50"
        />
      </div>

      <DialogFooter className="flex-row gap-2 pt-2">
        <Button
          variant="outline"
          onClick={onClose}
          className="flex-1 border-border/50"
        >
          Batal
        </Button>
        <Button
          onClick={handleSubmit}
          className="flex-1 bg-violet-600 hover:bg-violet-700 text-white border-0"
        >
          <Check className="h-4 w-4 mr-1" />
          Transfer
        </Button>
      </DialogFooter>
    </>
  );
}
