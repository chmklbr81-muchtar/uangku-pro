"use client";

import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
} from "@/lib/types";
import {
  computeBalanceSheet,
  computeIncomeStatement,
  formatCurrency,
  formatDate,
  todayISO,
  getMonthKey,
  getMonthLabel,
  getYear,
} from "@/lib/finance";
import {
  FileText,
  Scale,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface FinancialReportsProps {
  data: AppData;
}

type ReportType = "balance" | "income";
type PeriodType = "ytd" | "month" | "custom";

export function FinancialReports({ data }: FinancialReportsProps) {
  const [reportType, setReportType] = useState<ReportType>("balance");
  const [period, setPeriod] = useState<PeriodType>("ytd");
  const [customMonth, setCustomMonth] = useState(getMonthKey(todayISO()));
  const [customYear, setCustomYear] = useState(getYear(todayISO()));
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  const yearsAvailable = useMemo(() => {
    const ys = new Set<number>();
    data.transactions.forEach((t) => ys.add(getYear(t.date)));
    ys.add(getYear(todayISO()));
    return Array.from(ys).sort((a, b) => b - a);
  }, [data.transactions]);

  const report = useMemo(() => {
    if (reportType === "balance") {
      const untilDate = period === "month" ? `${customMonth}-31` : `${customYear}-12-31`;
      return {
        type: "balance" as const,
        data: computeBalanceSheet(data, untilDate),
        label: period === "month" ? `s/d ${getMonthLabel(customMonth)}` : `s/d ${customYear}`,
      };
    } else {
      let start: string, end: string, label: string;
      if (period === "ytd") {
        start = `${customYear}-01-01`;
        end = `${customYear}-12-31`;
        label = `Tahun ${customYear}`;
      } else {
        start = `${customMonth}-01`;
        end = `${customMonth}-31`;
        label = getMonthLabel(customMonth);
      }
      return {
        type: "income" as const,
        data: computeIncomeStatement(data, start, end, label),
        label,
      };
    }
  }, [reportType, period, customMonth, customYear, data]);

  function toggle(key: string) {
    setExpanded((e) => ({ ...e, [key]: !e[key] }));
  }

  return (
    <div className="space-y-4 pb-4">
      {/* Header dengan pilihan tipe laporan */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-3">
          <FileText className="h-5 w-5 text-violet-400" />
          <h2 className="text-base font-semibold">Laporan Keuangan Akuntansi</h2>
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          Generate laporan akuntansi formal dari Chart of Account
        </p>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            onClick={() => setReportType("balance")}
            className={cn(
              "flex items-center justify-center gap-2 rounded-lg border-2 px-3 py-2.5 text-sm font-semibold transition-colors",
              reportType === "balance"
                ? "border-violet-500 bg-violet-500/15 text-violet-400"
                : "border-border text-muted-foreground hover:bg-accent"
            )}
          >
            <Scale className="h-4 w-4" />
            Neraca
          </button>
          <button
            onClick={() => setReportType("income")}
            className={cn(
              "flex items-center justify-center gap-2 rounded-lg border-2 px-3 py-2.5 text-sm font-semibold transition-colors",
              reportType === "income"
                ? "border-emerald-500 bg-emerald-500/15 text-emerald-400"
                : "border-border text-muted-foreground hover:bg-accent"
            )}
          >
            <TrendingUp className="h-4 w-4" />
            Laba Rugi
          </button>
        </div>
      </Card>

      {/* Pilih periode */}
      <Card className="glass p-3 border-border/50">
        <div className="flex items-center justify-between gap-2">
          <div className="flex gap-1 rounded-lg bg-muted/40 p-1">
            <button
              onClick={() => setPeriod("ytd")}
              className={cn(
                "rounded-md px-3 py-1 text-xs font-semibold transition-colors",
                period === "ytd"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground"
              )}
            >
              {reportType === "balance" ? "Per Tahun" : "YTD"}
            </button>
            <button
              onClick={() => setPeriod("month")}
              className={cn(
                "rounded-md px-3 py-1 text-xs font-semibold transition-colors",
                period === "month"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground"
              )}
            >
              Per Bulan
            </button>
          </div>
          <div className="flex gap-1.5">
            {period === "month" ? (
              <Select
                value={customMonth}
                onValueChange={setCustomMonth}
              >
                <SelectTrigger className="bg-input/50 border-border/50 h-8 w-32 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-strong border-border/50">
                  {Array.from({ length: 12 }).map((_, idx) => {
                    const y = getYear(todayISO());
                    const m = String(idx + 1).padStart(2, "0");
                    const mk = `${y}-${m}`;
                    return (
                      <SelectItem key={mk} value={mk}>
                        {getMonthLabel(mk)}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            ) : (
              <Select
                value={String(customYear)}
                onValueChange={(v) => setCustomYear(Number(v))}
              >
                <SelectTrigger className="bg-input/50 border-border/50 h-8 w-20 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-strong border-border/50">
                  {yearsAvailable.map((y) => (
                    <SelectItem key={y} value={String(y)}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
        </div>
      </Card>

      {/* Konten Laporan */}
      {report.type === "balance" ? (
        <BalanceSheetView
          sheet={report.data}
          label={report.label}
          expanded={expanded}
          onToggle={toggle}
        />
      ) : (
        <IncomeStatementView
          stmt={report.data}
          expanded={expanded}
          onToggle={toggle}
        />
      )}
    </div>
  );
}

function BalanceSheetView({
  sheet,
  label,
  expanded,
  onToggle,
}: {
  sheet: ReturnType<typeof computeBalanceSheet>;
  label: string;
  expanded: Record<string, boolean>;
  onToggle: (key: string) => void;
}) {
  return (
    <div className="space-y-3">
      <Card className="glass p-4 border-border/50">
        <div className="text-center">
          <h3 className="text-base font-bold">LAPORAN NERACA</h3>
          <p className="text-xs text-muted-foreground">Uangku Pro — Per {label}</p>
        </div>
      </Card>

      {/* ASSET */}
      <Card className="glass p-4 border-border/50">
        <button
          onClick={() => onToggle("assets")}
          className="flex w-full items-center justify-between"
        >
          <div className="flex items-center gap-2">
            {expanded.assets ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            <h3 className="text-sm font-bold text-emerald-400">ASET</h3>
          </div>
          <p className="text-sm font-bold text-emerald-400 tabular-nums">
            {formatCurrency(sheet.totalAssets)}
          </p>
        </button>
        {expanded.assets && (
          <div className="mt-2 space-y-1 border-t border-border/30 pt-2">
            {sheet.assets.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Tidak ada transaksi aset</p>
            ) : (
              sheet.assets.map((a) => (
                <div key={a.account.id} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">
                    <span className="font-mono">{a.account.code}</span> {a.account.name}
                  </span>
                  <span className="font-medium tabular-nums">
                    {formatCurrency(a.balance)}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </Card>

      {/* LIABILITAS */}
      <Card className="glass p-4 border-border/50">
        <button
          onClick={() => onToggle("liabilities")}
          className="flex w-full items-center justify-between"
        >
          <div className="flex items-center gap-2">
            {expanded.liabilities ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            <h3 className="text-sm font-bold text-red-400">KEWAJIBAN</h3>
          </div>
          <p className="text-sm font-bold text-red-400 tabular-nums">
            {formatCurrency(sheet.totalLiabilities)}
          </p>
        </button>
        {expanded.liabilities && (
          <div className="mt-2 space-y-1 border-t border-border/30 pt-2">
            {sheet.liabilities.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Tidak ada kewajiban</p>
            ) : (
              sheet.liabilities.map((l) => (
                <div key={l.account.id} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">
                    <span className="font-mono">{l.account.code}</span> {l.account.name}
                  </span>
                  <span className="font-medium tabular-nums">
                    {formatCurrency(l.balance)}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </Card>

      {/* EKUITAS */}
      <Card className="glass p-4 border-border/50">
        <button
          onClick={() => onToggle("equity")}
          className="flex w-full items-center justify-between"
        >
          <div className="flex items-center gap-2">
            {expanded.equity ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            <h3 className="text-sm font-bold text-violet-400">EKUITAS</h3>
          </div>
          <p className="text-sm font-bold text-violet-400 tabular-nums">
            {formatCurrency(sheet.totalEquity)}
          </p>
        </button>
        {expanded.equity && (
          <div className="mt-2 space-y-1 border-t border-border/30 pt-2">
            {sheet.equity.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Tidak ada ekuitas</p>
            ) : (
              sheet.equity.map((e) => (
                <div key={e.account.id} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">
                    <span className="font-mono">{e.account.code}</span> {e.account.name}
                  </span>
                  <span className="font-medium tabular-nums">
                    {formatCurrency(e.balance)}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </Card>

      {/* Laba Ditahan (Net Income) */}
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-bold text-amber-400">LABA TAHUN BERJALAN</h3>
          </div>
          <p className="text-sm font-bold text-amber-400 tabular-nums">
            {formatCurrency(sheet.netIncome)}
          </p>
        </div>
      </Card>

      {/* Pembuktian */}
      <Card
        className={cn(
          "glass p-4 border-2",
          sheet.balanced
            ? "border-emerald-500/40 bg-emerald-500/5"
            : "border-amber-500/40 bg-amber-500/5"
        )}
      >
        <div className="flex items-center gap-2 mb-2">
          {sheet.balanced ? (
            <CheckCircle2 className="h-5 w-5 text-emerald-400" />
          ) : (
            <AlertTriangle className="h-5 w-5 text-amber-400" />
          )}
          <h3 className="text-sm font-bold">
            {sheet.balanced ? "Neraca Seimbang" : "Neraca Belum Seimbang"}
          </h3>
        </div>
        <div className="space-y-1 text-xs">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Aset</span>
            <span className="font-semibold tabular-nums">{formatCurrency(sheet.totalAssets)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Total Kewajiban + Ekuitas + Laba</span>
            <span className="font-semibold tabular-nums">
              {formatCurrency(sheet.totalLiabilities + sheet.totalEquity + sheet.netIncome)}
            </span>
          </div>
          <div className="flex justify-between border-t border-border/30 pt-1 mt-1">
            <span className="text-muted-foreground">Selisih</span>
            <span
              className={cn(
                "font-bold tabular-nums",
                sheet.balanced ? "text-emerald-400" : "text-amber-400"
              )}
            >
              {formatCurrency(sheet.difference)}
            </span>
          </div>
        </div>
        <p className="text-[10px] text-muted-foreground mt-2">
          Persamaan akuntansi: Aset = Kewajiban + Ekuitas + Laba Ditahan
        </p>
      </Card>
    </div>
  );
}

function IncomeStatementView({
  stmt,
  expanded,
  onToggle,
}: {
  stmt: ReturnType<typeof computeIncomeStatement>;
  expanded: Record<string, boolean>;
  onToggle: (key: string) => void;
}) {
  return (
    <div className="space-y-3">
      <Card className="glass p-4 border-border/50">
        <div className="text-center">
          <h3 className="text-base font-bold">LAPORAN LABA RUGI</h3>
          <p className="text-xs text-muted-foreground">Uangku Pro — Periode {stmt.periodLabel}</p>
        </div>
      </Card>

      {/* Pendapatan */}
      <Card className="glass p-4 border-border/50">
        <button
          onClick={() => onToggle("income")}
          className="flex w-full items-center justify-between"
        >
          <div className="flex items-center gap-2">
            {expanded.income ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            <h3 className="text-sm font-bold text-emerald-400">PENDAPATAN</h3>
          </div>
          <p className="text-sm font-bold text-emerald-400 tabular-nums">
            {formatCurrency(stmt.totalIncome)}
          </p>
        </button>
        {expanded.income && (
          <div className="mt-2 space-y-1 border-t border-border/30 pt-2">
            {stmt.income.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Tidak ada pendapatan</p>
            ) : (
              stmt.income.map((i) => (
                <div key={i.account.id} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">
                    <span className="font-mono">{i.account.code}</span> {i.account.name}
                  </span>
                  <span className="font-medium tabular-nums">
                    {formatCurrency(i.balance)}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </Card>

      {/* Beban */}
      <Card className="glass p-4 border-border/50">
        <button
          onClick={() => onToggle("expense")}
          className="flex w-full items-center justify-between"
        >
          <div className="flex items-center gap-2">
            {expanded.expense ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            <h3 className="text-sm font-bold text-red-400">BEBAN</h3>
          </div>
          <p className="text-sm font-bold text-red-400 tabular-nums">
            {formatCurrency(stmt.totalExpense)}
          </p>
        </button>
        {expanded.expense && (
          <div className="mt-2 space-y-1 border-t border-border/30 pt-2">
            {stmt.expenses.length === 0 ? (
              <p className="text-xs text-muted-foreground italic">Tidak ada beban</p>
            ) : (
              stmt.expenses.map((e) => (
                <div key={e.account.id} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">
                    <span className="font-mono">{e.account.code}</span> {e.account.name}
                  </span>
                  <span className="font-medium tabular-nums">
                    {formatCurrency(e.balance)}
                  </span>
                </div>
              ))
            )}
          </div>
        )}
      </Card>

      {/* Laba/Rugi Bersih */}
      <Card
        className={cn(
          "glass p-4 border-2",
          stmt.netIncome >= 0
            ? "border-emerald-500/40 bg-emerald-500/5"
            : "border-red-500/40 bg-red-500/5"
        )}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {stmt.netIncome >= 0 ? (
              <TrendingUp className="h-5 w-5 text-emerald-400" />
            ) : (
              <TrendingUp className="h-5 w-5 text-red-400 rotate-180" />
            )}
            <h3
              className={cn(
                "text-sm font-bold",
                stmt.netIncome >= 0 ? "text-emerald-400" : "text-red-400"
              )}
            >
              {stmt.netIncome >= 0 ? "LABA BERSIH" : "RUGI BERSIH"}
            </h3>
          </div>
          <p
            className={cn(
              "text-lg font-bold tabular-nums",
              stmt.netIncome >= 0 ? "text-emerald-400" : "text-red-400"
            )}
          >
            {formatCurrency(stmt.netIncome)}
          </p>
        </div>
        <div className="mt-2 pt-2 border-t border-border/30 text-xs text-muted-foreground">
          Pendapatan ({formatCurrency(stmt.totalIncome)}) − Beban ({formatCurrency(stmt.totalExpense)}) = {formatCurrency(stmt.netIncome)}
        </div>
      </Card>
    </div>
  );
}
