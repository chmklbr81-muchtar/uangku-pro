"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { type AppData, type SavingsGoal } from "@/lib/types";
import {
  formatCurrency,
  formatCompact,
  getSavingsProgress,
  getMonthLabel,
  genId,
} from "@/lib/finance";
import {
  Plus,
  Trash2,
  Target,
  PiggyBank,
  Edit2,
  Trophy,
  CalendarDays,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const GOAL_COLORS = ["#a855f7", "#ec4899", "#10b981", "#f59e0b", "#06b6d4", "#ef4444"];

interface SavingsGoalManagerProps {
  data: AppData;
  onUpdate: (goals: SavingsGoal[]) => void;
  onContribute: (goalId: string, amount: number) => void;
}

export function SavingsGoalManager({
  data,
  onUpdate,
  onContribute,
}: SavingsGoalManagerProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<SavingsGoal | null>(null);
  const [contribOpen, setContribOpen] = useState<SavingsGoal | null>(null);

  const activeGoals = data.savingsGoals.filter((g) => !g.archived);

  function handleSave(goal: SavingsGoal) {
    const exists = data.savingsGoals.some((g) => g.id === goal.id);
    const updated = exists
      ? data.savingsGoals.map((g) => (g.id === goal.id ? goal : g))
      : [...data.savingsGoals, goal];
    onUpdate(updated);
    setDialogOpen(false);
    setEditing(null);
    toast.success(exists ? "Target diperbarui" : "Target dibuat");
  }

  function handleDelete(id: string) {
    onUpdate(data.savingsGoals.filter((g) => g.id !== id));
    toast.success("Target dihapus");
  }

  return (
    <div className="space-y-4 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Target Tabungan</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {activeGoals.length} target aktif
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
            size="sm"
            className="bg-primary text-primary-foreground"
          >
            <Plus className="h-4 w-4 mr-1" />
            Target Baru
          </Button>
        </div>
      </Card>

      {activeGoals.length === 0 ? (
        <Card className="glass flex flex-col items-center justify-center gap-3 p-10 text-center border-border/50">
          <div className="rounded-full bg-muted/40 p-4">
            <PiggyBank className="h-8 w-8 text-muted-foreground" />
          </div>
          <div>
            <p className="font-medium">Belum ada target tabungan</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              Tetapkan target seperti "Liburan", "DP Rumah", atau "Emergency
              Fund" untuk memantau progres tabungan Anda.
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
            className="bg-primary text-primary-foreground"
          >
            <Plus className="h-4 w-4 mr-1" />
            Buat Target Pertama
          </Button>
        </Card>
      ) : (
        <div className="space-y-3">
          {activeGoals.map((g) => {
            const prog = getSavingsProgress(
              g,
              data.transactions,
              data.wallets
            );
            const isComplete = prog.percent >= 100;
            return (
              <Card
                key={g.id}
                className={cn(
                  "glass p-4 border-border/50",
                  isComplete && "border-emerald-500/40 bg-emerald-500/5"
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-xl"
                      style={{ backgroundColor: g.color + "30" }}
                    >
                      {isComplete ? (
                        <Trophy className="h-5 w-5 text-amber-400" />
                      ) : (
                        <Target
                          className="h-5 w-5"
                          style={{ color: g.color }}
                        />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{g.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {g.deadline
                          ? `Target: ${new Intl.DateTimeFormat("id-ID", {
                              day: "numeric",
                              month: "short",
                              year: "numeric",
                            }).format(new Date(g.deadline))}`
                          : "Tanpa deadline"}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => {
                        setEditing(g);
                        setDialogOpen(true);
                      }}
                      aria-label="Edit"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-red-400 hover:text-red-500"
                      onClick={() => handleDelete(g.id)}
                      aria-label="Hapus"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {formatCurrency(g.currentAmount)} tersimpan
                    </span>
                    <span className="font-bold tabular-nums">
                      {prog.percent.toFixed(1)}%
                    </span>
                  </div>
                  <div className="mt-1.5 h-2.5 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${Math.min(100, prog.percent)}%`,
                        backgroundColor: g.color,
                      }}
                    />
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      Target: {formatCurrency(g.targetAmount)}
                    </span>
                    <span className="text-muted-foreground">
                      Sisa: {formatCurrency(g.targetAmount - g.currentAmount)}
                    </span>
                  </div>
                </div>

                {prog.monthsRemaining !== null && !isComplete && (
                  <div className="mt-3 flex items-center justify-between rounded-lg bg-muted/40 px-3 py-2 text-xs">
                    <div className="flex items-center gap-1.5">
                      <CalendarDays className="h-3.5 w-3.5 text-violet-400" />
                      <span className="text-muted-foreground">
                        Estimasi tercapai dalam{" "}
                        <span className="font-bold text-foreground">
                          {prog.monthsRemaining} bulan
                        </span>
                      </span>
                    </div>
                    <span className="text-muted-foreground">
                      @{formatCompact(prog.monthlyContribution)}/bln
                    </span>
                  </div>
                )}

                {isComplete && (
                  <div className="mt-3 rounded-lg bg-emerald-500/15 px-3 py-2 text-xs font-semibold text-emerald-400 text-center">
                    🎉 Selamat! Target tercapai!
                  </div>
                )}

                {!isComplete && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setContribOpen(g)}
                    className="w-full mt-3 border-border/50 h-9"
                  >
                    <Plus className="h-3.5 w-3.5 mr-1" />
                    Tambah Kontribusi
                  </Button>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <GoalEditDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) setEditing(null);
        }}
        editing={editing}
        data={data}
        onSave={handleSave}
      />

      {/* [v9.0 fix] Rules of Hooks: render ContributeDialog hanya saat goal non-null
          agar jumlah hook konsisten tiap render instance. */}
      {contribOpen && (
        <ContributeDialog
          goal={contribOpen}
          onOpenChange={(o) => !o && setContribOpen(null)}
          onContribute={(amount) => {
            if (contribOpen) {
              onContribute(contribOpen.id, amount);
              setContribOpen(null);
              toast.success("Kontribusi ditambahkan!");
            }
          }}
        />
      )}
    </div>
  );
}

function GoalEditDialog({
  open,
  onOpenChange,
  editing,
  data,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editing: SavingsGoal | null;
  data: AppData;
  onSave: (g: SavingsGoal) => void;
}) {
  const [name, setName] = useState(editing?.name ?? "");
  const [target, setTarget] = useState(
    editing ? String(editing.targetAmount) : ""
  );
  const [current, setCurrent] = useState(
    editing ? String(editing.currentAmount) : ""
  );
  const [deadline, setDeadline] = useState(editing?.deadline ?? "");
  const [color, setColor] = useState(editing?.color ?? GOAL_COLORS[0]);
  const [walletId, setWalletId] = useState(editing?.walletId ?? "");

  // [v9.0 fix] setState-during-render anti-pattern (lastOpen) -> useEffect
  // Sinkronisasi state lokal saat dialog dibuka atau editing berubah.
  useEffect(() => {
    if (!open) return;
    setName(editing?.name ?? "");
    setTarget(editing ? String(editing.targetAmount) : "");
    setCurrent(editing ? String(editing.currentAmount) : "");
    setDeadline(editing?.deadline ?? "");
    setColor(editing?.color ?? GOAL_COLORS[0]);
    setWalletId(editing?.walletId ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  function handleSubmit() {
    const numTarget = Number(target.replace(/[^0-9]/g, ""));
    const numCurrent = Number(current.replace(/[^0-9]/g, ""));
    if (!name.trim() || !numTarget) return;
    onSave({
      id: editing?.id ?? genId(),
      name: name.trim(),
      targetAmount: numTarget,
      currentAmount: numCurrent,
      deadline: deadline || undefined,
      walletId: walletId || undefined,
      color,
      createdAt: editing?.createdAt ?? new Date().toISOString(),
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit Target" : "Target Tabungan Baru"}</DialogTitle>
          <DialogDescription>
            Tetapkan target & pantau progres tabungan Anda.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="goal-name">Nama Target</Label>
            <Input
              id="goal-name"
              placeholder="Contoh: Liburan ke Bali"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label htmlFor="goal-target">Target</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">Rp</span>
                <Input
                  id="goal-target"
                  inputMode="numeric"
                  placeholder="0"
                  value={target}
                  onChange={(e) => {
                    const only = e.target.value.replace(/[^0-9]/g, "");
                    setTarget(only ? Number(only).toLocaleString("id-ID") : "");
                  }}
                  className="pl-9 bg-input/50 border-border/50"
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="goal-current">Sudah Tersimpan</Label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">Rp</span>
                <Input
                  id="goal-current"
                  inputMode="numeric"
                  placeholder="0"
                  value={current}
                  onChange={(e) => {
                    const only = e.target.value.replace(/[^0-9]/g, "");
                    setCurrent(only ? Number(only).toLocaleString("id-ID") : "");
                  }}
                  className="pl-9 bg-input/50 border-border/50"
                />
              </div>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="goal-deadline">Deadline (opsional)</Label>
            <Input
              id="goal-deadline"
              type="date"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Dompet Sumber (opsional)</Label>
            <Select value={walletId} onValueChange={setWalletId}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="Pilih dompet" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50">
                <SelectItem value="_none">(Tidak terikat dompet)</SelectItem>
                {data.wallets.filter((w) => !w.archived).map((w) => (
                  <SelectItem key={w.id} value={w.id}>
                    {w.icon} {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Warna</Label>
            <div className="flex gap-2">
              {GOAL_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={cn(
                    "h-7 w-7 rounded-full transition-transform",
                    color === c && "ring-2 ring-offset-2 ring-offset-background ring-white scale-110"
                  )}
                  style={{ backgroundColor: c }}
                  aria-label={`Pilih warna ${c}`}
                />
              ))}
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!name.trim() || !target}
            className="bg-primary text-primary-foreground"
          >
            Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ContributeDialog({
  goal,
  onOpenChange,
  onContribute,
}: {
  // [v9.0 fix] Rules of Hooks: goal non-null (parent hanya render saat goal non-null)
  goal: SavingsGoal;
  onOpenChange: (o: boolean) => void;
  onContribute: (amount: number) => void;
}) {
  const [amount, setAmount] = useState("");

  function handleSubmit() {
    const n = Number(amount.replace(/[^0-9]/g, ""));
    if (!n || n <= 0) return;
    onContribute(n);
    setAmount("");
  }

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[360px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle>Tambah Kontribusi</DialogTitle>
          <DialogDescription>
            Tambah dana ke target{" "}
            <span className="font-semibold text-foreground">{goal.name}</span>
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="rounded-lg bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
            Tersimpan:{" "}
            <span className="font-semibold text-foreground">
              {formatCurrency(goal.currentAmount)}
            </span>{" "}
            / {formatCurrency(goal.targetAmount)}
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="contrib-amount">Jumlah Kontribusi</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="contrib-amount"
                inputMode="numeric"
                placeholder="0"
                value={amount}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setAmount(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-9 text-base font-semibold bg-input/50 border-border/50"
                autoFocus
              />
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!amount}
            className="bg-emerald-600 hover:bg-emerald-700 text-white border-0"
          >
            Tambah
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
