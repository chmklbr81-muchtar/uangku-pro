"use client";

import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
  type Budget,
  type COAAccount,
} from "@/lib/types";
import { getLeafAccounts } from "@/lib/default-data";
import {
  formatCurrency,
  getBudgetUsage,
  getMonthKey,
  getMonthLabel,
  todayISO,
  genId,
} from "@/lib/finance";
import {
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  PieChart,
  Copy,
  Sparkles,
  Home,
  Heart,
  PiggyBank,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface BudgetManagerProps {
  data: AppData;
  onUpdate: (budgets: Budget[]) => void;
}

export function BudgetManager({ data, onUpdate }: BudgetManagerProps) {
  const [monthKey, setMonthKey] = useState(getMonthKey(todayISO()));
  const [templateOpen, setTemplateOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  // Build month options: 6 bulan ke belakang & 6 ke depan
  const monthOptions = useMemo(() => {
    const now = new Date();
    const opts: string[] = [];
    for (let i = -6; i <= 6; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
      opts.push(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
    }
    return opts;
  }, []);

  const leafExpense = getLeafAccounts(data.coa).filter(
    (c) => c.type === "expense" || c.type === "operating_expense"
  );

  const usages = getBudgetUsage(data.budgets, data.transactions, data.coa, monthKey);
  const monthBudgets = data.budgets.filter((b) => b.monthKey === monthKey);

  function goPrev() {
    const [y, m] = monthKey.split("-").map(Number);
    const d = new Date(y, m - 2, 1);
    setMonthKey(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  }
  function goNext() {
    const [y, m] = monthKey.split("-").map(Number);
    const d = new Date(y, m, 1);
    setMonthKey(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`);
  }

  function copyFromPrev() {
    const [y, m] = monthKey.split("-").map(Number);
    const d = new Date(y, m - 2, 1);
    const prev = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    const prevBudgets = data.budgets.filter((b) => b.monthKey === prev);
    if (prevBudgets.length === 0) {
      toast.error("Tidak ada anggaran bulan sebelumnya");
      return;
    }
    // Remove existing for this month, then add copied
    const otherMonths = data.budgets.filter((b) => b.monthKey !== monthKey);
    const newBudgets: Budget[] = prevBudgets.map((b) => ({
      ...b,
      id: genId(),
      monthKey,
    }));
    onUpdate([...otherMonths, ...newBudgets]);
    toast.success(`Anggaran disalin dari ${getMonthLabel(prev)}`);
  }

  function handleAdd(coaId: string, amount: number) {
    const newB: Budget = {
      id: genId(),
      coaId,
      monthKey,
      amount,
    };
    // Replace if exists
    const others = data.budgets.filter(
      (b) => !(b.monthKey === monthKey && b.coaId === coaId)
    );
    onUpdate([...others, newB]);
    setDialogOpen(false);
    toast.success("Anggaran ditambahkan");
  }

  function handleDelete(id: string) {
    onUpdate(data.budgets.filter((b) => b.id !== id));
    toast.success("Anggaran dihapus");
  }

  return (
    <div className="space-y-4 pb-4">
      {/* Month Navigation */}
      <Card className="glass flex items-center justify-between p-3 border-border/50">
        <Button variant="ghost" size="icon" onClick={goPrev} aria-label="Bulan sebelumnya">
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="text-center">
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
            Anggaran Bulan
          </p>
          <p className="text-sm font-bold">{getMonthLabel(monthKey)}</p>
        </div>
        <Button variant="ghost" size="icon" onClick={goNext} aria-label="Bulan berikutnya">
          <ChevronRight className="h-4 w-4" />
        </Button>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-2">
        <Card className="glass p-3 border-border/50">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            Total Anggaran
          </p>
          <p className="mt-0.5 text-base font-bold text-violet-400">
            {formatCurrency(
              monthBudgets.reduce((a, b) => a + b.amount, 0)
            )}
          </p>
        </Card>
        <Card className="glass p-3 border-border/50">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            Total Terpakai
          </p>
          <p className="mt-0.5 text-base font-bold text-pink-400">
            {formatCurrency(usages.reduce((a, b) => a + b.used, 0))}
          </p>
        </Card>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-3 gap-2">
        <Button
          onClick={() => setDialogOpen(true)}
          className="bg-primary text-primary-foreground h-11"
        >
          <Plus className="h-4 w-4 mr-1" />
          Set
        </Button>
        <Button variant="outline" onClick={copyFromPrev} className="border-border/50 h-11">
          <Copy className="h-4 w-4 mr-1" />
          Salin
        </Button>
        <Button
          variant="outline"
          onClick={() => setTemplateOpen(true)}
          className="border-gold text-gold hover:bg-accent h-11"
        >
          <Sparkles className="h-4 w-4 mr-1" />
          50/30/20
        </Button>
      </div>

      {/* List */}
      {usages.length === 0 ? (
        <Card className="glass flex flex-col items-center justify-center gap-3 p-10 text-center border-border/50">
          <div className="rounded-full bg-muted/40 p-4">
            <PieChart className="h-8 w-8 text-muted-foreground" />
          </div>
          <div>
            <p className="font-medium">Belum ada anggaran</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              Set anggaran per kategori untuk melacak pengeluaran Anda.
            </p>
          </div>
        </Card>
      ) : (
        <div className="space-y-2">
          {usages.map((u) => {
            const color =
              u.percent >= 100
                ? "text-red-400 bg-red-500"
                : u.percent >= 80
                ? "text-amber-400 bg-amber-500"
                : "text-emerald-400 bg-emerald-500";
            return (
              <Card key={u.budget.id} className="glass p-3 border-border/50">
                <div className="flex items-start justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{u.coaName}</p>
                    <p className="text-[11px] text-muted-foreground font-mono">
                      {u.coaCode}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-red-400 hover:text-red-500"
                    onClick={() => handleDelete(u.budget.id)}
                    aria-label="Hapus"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
                <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className={cn("h-full rounded-full transition-all", color.split(" ")[1])}
                    style={{ width: `${Math.min(100, u.percent)}%` }}
                  />
                </div>
                <div className="mt-2 flex items-center justify-between text-xs">
                  <span className="text-muted-foreground tabular-nums">
                    {formatCurrency(u.used)} / {formatCurrency(u.budget.amount)}
                  </span>
                  <span
                    className={cn(
                      "font-bold tabular-nums",
                      color.split(" ")[0]
                    )}
                  >
                    {u.percent.toFixed(0)}%
                  </span>
                </div>
                <p className="mt-0.5 text-[11px] text-muted-foreground tabular-nums">
                  Sisa: {formatCurrency(u.remaining)}
                </p>
              </Card>
            );
          })}
        </div>
      )}

      <AddBudgetDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        leafAccounts={leafExpense}
        existingForMonth={monthBudgets.map((b) => b.coaId)}
        onAdd={handleAdd}
      />

      <BudgetTemplateDialog
        open={templateOpen}
        onOpenChange={setTemplateOpen}
        monthKey={monthKey}
        existingBudgets={data.budgets}
        leafExpense={leafExpense}
        onUpdate={onUpdate}
      />
    </div>
  );
}

// === Budget Template 50/30/20 ===
// Aturan 50/30/20: 50% kebutuhan (makan, transport, tagihan, sewa), 30% gaya hidup (hiburan, belanja non-esensial), 20% tabungan/investasi
function BudgetTemplateDialog({
  open,
  onOpenChange,
  monthKey,
  existingBudgets,
  leafExpense,
  onUpdate,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  monthKey: string;
  existingBudgets: Budget[];
  leafExpense: COAAccount[];
  onUpdate: (b: Budget[]) => void;
}) {
  const [monthlyIncome, setMonthlyIncome] = useState("");

  // Peta kategori default untuk 50/30/20
  const NEEDS_COA = ["coa-8-1001", "coa-8-1002", "coa-8-1100", "coa-8-1300", "coa-8-1700", "coa-8-1301", "coa-8-1302", "coa-8-1303"];
  const WANTS_COA = ["coa-8-1200", "coa-8-1400", "coa-8-1201"];
  // 20% savings → kita tidak buat budget, savings ada di tab Savings Goals

  function applyTemplate() {
    const income = Number(monthlyIncome.replace(/[^0-9]/g, ""));
    if (!income || income <= 0) {
      toast.error("Masukkan pendapatan bulanan dulu");
      return;
    }
    const needsTotal = income * 0.5; // 50%
    const wantsTotal = income * 0.3; // 30%
    // savings 20% → user set manual via Savings Goals

    const needsPerCat = Math.round(needsTotal / NEEDS_COA.length);
    const wantsPerCat = Math.round(wantsTotal / WANTS_COA.length);

    // Buat budgets baru, ganti yang lama untuk monthKey ini
    const otherMonths = existingBudgets.filter((b) => b.monthKey !== monthKey);
    const newBudgets: Budget[] = [];

    // Budget untuk kategori "kebutuhan"
    for (const coaId of NEEDS_COA) {
      const acc = leafExpense.find((c) => c.id === coaId);
      if (acc) {
        newBudgets.push({
          id: genId(),
          coaId,
          monthKey,
          amount: needsPerCat,
        });
      }
    }
    // Budget untuk kategori "gaya hidup"
    for (const coaId of WANTS_COA) {
      const acc = leafExpense.find((c) => c.id === coaId);
      if (acc) {
        newBudgets.push({
          id: genId(),
          coaId,
          monthKey,
          amount: wantsPerCat,
        });
      }
    }

    onUpdate([...otherMonths, ...newBudgets]);
    onOpenChange(false);
    setMonthlyIncome("");
    toast.success(`Template 50/30/20 diterapkan! ${newBudgets.length} anggaran dibuat. Tabung ${formatCurrency(income * 0.2)} di tab Savings Goals.`);
  }

  const income = Number(monthlyIncome.replace(/[^0-9]/g, "")) || 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[420px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-gold" />
            Budget Template 50/30/20
          </DialogTitle>
          <DialogDescription>
            Aturan populer: 50% kebutuhan, 30% gaya hidup, 20% tabungan.
            Masukkan pendapatan bulanan Anda, kami auto-buat anggarannya.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="monthly-income">Pendapatan Bulanan</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="monthly-income"
                inputMode="numeric"
                placeholder="5000000"
                value={monthlyIncome}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setMonthlyIncome(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 text-base font-semibold bg-input/50 border-border/50"
                autoFocus
              />
            </div>
          </div>

          {income > 0 && (
            <div className="space-y-2 animate-card-in">
              {/* 50% Kebutuhan */}
              <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Home className="h-4 w-4 text-emerald-400" />
                  <span className="text-sm font-bold text-emerald-400">50% Kebutuhan</span>
                  <span className="ml-auto text-sm font-bold tabular-nums">
                    {formatCurrency(income * 0.5)}
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Makan, transport, tagihan, sewa — dibagi rata ke 8 kategori
                </p>
              </div>
              {/* 30% Gaya Hidup */}
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Heart className="h-4 w-4 text-amber-400" />
                  <span className="text-sm font-bold text-amber-400">30% Gaya Hidup</span>
                  <span className="ml-auto text-sm font-bold tabular-nums">
                    {formatCurrency(income * 0.3)}
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Belanja non-esensial, hiburan — dibagi rata ke 3 kategori
                </p>
              </div>
              {/* 20% Tabungan */}
              <div className="rounded-lg bg-[oklch(0.78_0.16_85/0.10)] border-gold p-3">
                <div className="flex items-center gap-2 mb-1">
                  <PiggyBank className="h-4 w-4 text-gold" />
                  <span className="text-sm font-bold text-gold">20% Tabungan</span>
                  <span className="ml-auto text-sm font-bold tabular-nums">
                    {formatCurrency(income * 0.2)}
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Set manual di tab Lainnya → Tabungan sebagai target tabungan
                </p>
              </div>
            </div>
          )}

          <div className="rounded-lg bg-muted/40 p-2.5 text-[11px] text-muted-foreground">
            ⚠ Template akan mengganti semua anggaran bulan {getMonthLabel(monthKey)} yang sudah ada.
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={applyTemplate}
            disabled={!income}
            className="gradient-gold text-primary-foreground border-0"
          >
            <Sparkles className="h-4 w-4 mr-1" />
            Apply Template
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AddBudgetDialog({
  open,
  onOpenChange,
  leafAccounts,
  existingForMonth,
  onAdd,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  leafAccounts: COAAccount[];
  existingForMonth: string[];
  onAdd: (coaId: string, amount: number) => void;
}) {
  const [coaId, setCoaId] = useState("");
  const [amount, setAmount] = useState("");

  function reset() {
    setCoaId("");
    setAmount("");
  }

  function handleSubmit() {
    const numAmount = Number(amount.replace(/[^0-9]/g, ""));
    if (!coaId || !numAmount || numAmount <= 0) return;
    onAdd(coaId, numAmount);
    reset();
  }

  const available = leafAccounts.filter((a) => !existingForMonth.includes(a.id));

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        onOpenChange(o);
        if (!o) reset();
      }}
    >
      <DialogContent className="sm:max-w-[400px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle>Set Anggaran Baru</DialogTitle>
          <DialogDescription>
            Tentukan batas pengeluaran untuk satu kategori bulan ini.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Kategori (COA)</Label>
            <Select value={coaId} onValueChange={setCoaId}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="Pilih kategori" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50 max-h-72">
                {available.length === 0 ? (
                  <SelectItem value="_" disabled>
                    Semua kategori sudah punya anggaran
                  </SelectItem>
                ) : (
                  available.map((a) => (
                    <SelectItem key={a.id} value={a.id}>
                      <span className="font-mono text-[11px] text-muted-foreground mr-2">
                        {a.code}
                      </span>
                      {a.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="budget-amount">Jumlah Anggaran</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
                Rp
              </span>
              <Input
                id="budget-amount"
                inputMode="numeric"
                placeholder="0"
                value={amount}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setAmount(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 text-base font-semibold bg-input/50 border-border/50"
              />
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!coaId || !amount}
            className="bg-primary text-primary-foreground"
          >
            Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
