"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { type AppData, type Wallet, type WalletType } from "@/lib/types";
import { getWalletBalance, formatCurrency, genId } from "@/lib/finance";
import { Plus, Edit2, Trash2, Wallet as WalletIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface WalletManagerProps {
  data: AppData;
  onUpdate: (wallets: Wallet[]) => void;
}

const WALLET_TYPES: { type: WalletType; label: string; icon: string; color: string }[] = [
  { type: "cash", label: "Tunai", icon: "💵", color: "#10b981" },
  { type: "bank_bca", label: "Bank BCA", icon: "🏦", color: "#0a6cf5" },
  { type: "bank_mandiri", label: "Bank Mandiri", icon: "🏦", color: "#f59e0b" },
  { type: "ewallet_gopay", label: "GoPay", icon: "📱", color: "#10b981" },
  { type: "ewallet_ovo", label: "OVO", icon: "📱", color: "#8b5cf6" },
  { type: "ewallet_dana", label: "DANA", icon: "📱", color: "#3b82f6" },
  { type: "ewallet_shopeepay", label: "ShopeePay", icon: "🛍️", color: "#ef4444" },
  { type: "qris", label: "QRIS", icon: "📱", color: "#0ea5e9" },
  { type: "investment", label: "Investasi", icon: "📈", color: "#ec4899" },
];

export function WalletManager({ data, onUpdate }: WalletManagerProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Wallet | null>(null);

  const activeWallets = data.wallets.filter((w) => !w.archived);

  function handleSave(w: Wallet) {
    const exists = data.wallets.some((x) => x.id === w.id);
    const updated = exists
      ? data.wallets.map((x) => (x.id === w.id ? w : x))
      : [...data.wallets, w];
    onUpdate(updated);
    setDialogOpen(false);
    setEditing(null);
    toast.success(exists ? "Dompet diperbarui" : "Dompet dibuat");
  }

  function handleDelete(w: Wallet) {
    const hasTx = data.transactions.some((t) => t.walletId === w.id);
    if (hasTx) {
      const updated = data.wallets.map((x) =>
        x.id === w.id ? { ...x, archived: true } : x
      );
      onUpdate(updated);
      toast.success("Dompet diarsipkan (masih ada transaksi terkait)");
      return;
    }
    onUpdate(data.wallets.filter((x) => x.id !== w.id));
    toast.success("Dompet dihapus");
  }

  return (
    <div className="space-y-3 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Dompet Saya</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {activeWallets.length} dompet aktif
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
            size="sm"
            className="bg-primary text-primary-foreground"
          >
            <Plus className="h-4 w-4 mr-1" />
            Dompet Baru
          </Button>
        </div>
      </Card>

      <div className="space-y-2">
        {activeWallets.map((w) => {
          const balance = getWalletBalance(w.id, data.transactions, data.wallets);
          return (
            <Card key={w.id} className="glass p-3 border-border/50">
              <div className="flex items-center gap-3">
                <div
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-2xl"
                  style={{ backgroundColor: w.color + "20" }}
                >
                  {w.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{w.name}</p>
                  <p className="text-[11px] text-muted-foreground">
                    {WALLET_TYPES.find((t) => t.type === w.type)?.label ?? w.type} ·{" "}
                    Saldo awal {formatCurrency(w.initialBalance)}
                  </p>
                  <p
                    className={cn(
                      "mt-0.5 text-sm font-bold tabular-nums",
                      balance < 0 ? "text-red-400" : "text-foreground"
                    )}
                  >
                    {formatCurrency(balance)}
                  </p>
                </div>
                <div className="flex gap-1 shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => {
                      setEditing(w);
                      setDialogOpen(true);
                    }}
                    aria-label="Edit"
                  >
                    <Edit2 className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-red-400 hover:text-red-500"
                    onClick={() => handleDelete(w)}
                    aria-label="Hapus"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <WalletEditDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) setEditing(null);
        }}
        editing={editing}
        onSave={handleSave}
      />
    </div>
  );
}

function WalletEditDialog({
  open,
  onOpenChange,
  editing,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editing: Wallet | null;
  onSave: (w: Wallet) => void;
}) {
  const [name, setName] = useState(editing?.name ?? "");
  const [type, setType] = useState<WalletType>(editing?.type ?? "cash");
  const [icon, setIcon] = useState(editing?.icon ?? "💵");
  const [color, setColor] = useState(editing?.color ?? "#10b981");
  const [initialBalance, setInitialBalance] = useState(
    editing ? String(editing.initialBalance) : ""
  );
  const [minAlert, setMinAlert] = useState(
    editing?.minAlert !== undefined ? String(editing.minAlert) : ""
  );

  // [v9.0 fix] setState-during-render anti-pattern (lastOpen) -> useEffect
  // Sinkronisasi state lokal saat dialog dibuka atau editing berubah.
  useEffect(() => {
    if (!open) return;
    setName(editing?.name ?? "");
    setType(editing?.type ?? "cash");
    setIcon(editing?.icon ?? "💵");
    setColor(editing?.color ?? "#10b981");
    setInitialBalance(editing ? String(editing.initialBalance) : "");
    setMinAlert(editing?.minAlert !== undefined ? String(editing.minAlert) : "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  function handleTypeChange(t: WalletType) {
    setType(t);
    const preset = WALLET_TYPES.find((w) => w.type === t);
    if (preset) {
      setIcon(preset.icon);
      setColor(preset.color);
      if (!name) setName(preset.label);
    }
  }

  function handleSubmit() {
    if (!name.trim()) return;
    onSave({
      id: editing?.id ?? `wallet-${type}-${genId().slice(0, 6)}`,
      name: name.trim(),
      type,
      icon,
      color,
      initialBalance: Number(initialBalance.replace(/[^0-9]/g, "")) || 0,
      minAlert: minAlert ? Number(minAlert.replace(/[^0-9]/g, "")) : undefined,
      createdAt: editing?.createdAt ?? new Date().toISOString(),
    });
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle>
            {editing ? "Edit Dompet" : "Dompet Baru"}
          </DialogTitle>
          <DialogDescription>
            Kelola dompet cash, bank, e-wallet, investasi.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Tipe Dompet</Label>
            <Select value={type} onValueChange={(v) => handleTypeChange(v as WalletType)}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50">
                {WALLET_TYPES.map((t) => (
                  <SelectItem key={t.type} value={t.type}>
                    {t.icon} {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="wallet-name">Nama Dompet</Label>
            <Input
              id="wallet-name"
              placeholder="Contoh: Dompet Tunai, Rekening BCA"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label htmlFor="wallet-icon">Ikon (emoji)</Label>
              <Input
                id="wallet-icon"
                placeholder="💵"
                value={icon}
                onChange={(e) => setIcon(e.target.value)}
                className="bg-input/50 border-border/50 text-center text-xl"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="wallet-color">Warna</Label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="h-9 w-12 rounded-md border border-border/50 bg-transparent"
                />
                <span className="text-xs font-mono text-muted-foreground">
                  {color}
                </span>
              </div>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="wallet-init">Saldo Awal</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="wallet-init"
                inputMode="numeric"
                placeholder="0"
                value={initialBalance}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setInitialBalance(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 bg-input/50 border-border/50"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="wallet-min">
              Alert Saldo Minimum (opsional)
            </Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="wallet-min"
                inputMode="numeric"
                placeholder="0 (tanpa alert)"
                value={minAlert}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setMinAlert(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 bg-input/50 border-border/50"
              />
            </div>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!name.trim()}
            className="bg-primary text-primary-foreground"
          >
            Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
