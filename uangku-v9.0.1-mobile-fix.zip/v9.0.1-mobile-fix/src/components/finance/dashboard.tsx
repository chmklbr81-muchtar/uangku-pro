"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  type AppData,
  type Transaction,
  type Wallet,
} from "@/lib/types";
import {
  type Summary,
  formatCurrency,
  formatCompact,
  formatDateShort,
  getWallet,
  getCOAAccount,
  getWalletBalance,
  getMonthKey,
  todayISO,
  groupByDate,
  getBudgetUsage,
  getSavingsProgress,
} from "@/lib/finance";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Wallet as WalletIcon,
  TrendingUp,
  TrendingDown,
  Plus,
  PiggyBank,
  ArrowLeftRight,
  Target,
  Bell,
  AlertTriangle,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DashboardProps {
  data: AppData;
  summary: Summary;
  monthKey: string;
  onAdd: () => void;
  onTransfer: () => void;
  onOpenTransaction: (tx: Transaction) => void;
  onSeeAll: () => void;
  onSwitchWallet: () => void;
  onOpenSavings: () => void;
  onOpenBudget: () => void;
  onOpenNotifications: () => void;
  notifCount: number;
}

export function Dashboard({
  data,
  summary,
  monthKey,
  onAdd,
  onTransfer,
  onOpenTransaction,
  onSeeAll,
  onSwitchWallet,
  onOpenSavings,
  onOpenBudget,
  onOpenNotifications,
  notifCount,
}: DashboardProps) {
  const monthLabel = new Intl.DateTimeFormat("id-ID", {
    month: "long",
    year: "numeric",
  }).format(new Date(monthKey + "-01"));

  const activeWallets = data.wallets.filter((w) => !w.archived);
  // [v9.0 fix] T-1.2: filter soft-deleted transaksi dari tampilan Dashboard.
  // Item dengan deletedAt < 30 hari tetap ada di data.transactions untuk propagate deletion via sync.
  const SOFT_DELETE_WINDOW_MS = 30 * 24 * 60 * 60 * 1000;
  const visibleTransactions = data.transactions.filter((t) => {
    if (!t.deletedAt) return true;
    return Date.now() - new Date(t.deletedAt).getTime() >= SOFT_DELETE_WINDOW_MS;
  });
  const groups = groupByDate(visibleTransactions);
  const recentDates = Object.keys(groups).slice(0, 2);
  const recent: Transaction[] = recentDates.flatMap((d) => groups[d]).slice(0, 5);

  // Budget alerts
  const budgetUsage = getBudgetUsage(data.budgets, visibleTransactions, data.coa, monthKey);
  const budgetAlerts = budgetUsage.filter((b) => b.percent >= 80);

  // Savings goals active
  const activeGoals = data.savingsGoals.filter((g) => !g.archived).slice(0, 2);
  const hasData = visibleTransactions.length > 0;

  return (
    <div className="space-y-4 pb-4">
      {/* HERO: Saldo Global — Navy-Gold Premium */}
      <Card className="relative overflow-hidden border border-gold p-0 gradient-navy-gold">
        {/* Glow effects */}
        <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full bg-[oklch(0.78_0.16_85/0.20)] blur-3xl" />
        <div className="absolute -bottom-16 -left-8 h-44 w-44 rounded-full bg-[oklch(0.55_0.18_260/0.30)] blur-3xl" />

        <div className="relative p-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-foreground/70">
              <WalletIcon className="h-4 w-4 text-gold" />
              <span className="text-xs font-medium">Total Saldo Semua Dompet</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onOpenNotifications}
              className="relative h-8 w-8 p-0"
              aria-label="Notifikasi"
            >
              <Bell className="h-4 w-4" />
              {notifCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-pink-500 px-1 text-[10px] font-bold text-white">
                  {notifCount > 9 ? "9+" : notifCount}
                </span>
              )}
            </Button>
          </div>

          <p className="mt-2 text-3xl font-bold tracking-tight text-gradient-gold">
            {formatCurrency(summary.balance)}
          </p>
          <p className="mt-1 text-xs text-foreground/60">
            {monthLabel}
          </p>

          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/20 px-3 py-2.5">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <ArrowDownLeft className="h-3.5 w-3.5" />
                <span className="text-[11px] font-semibold">Total Masuk</span>
              </div>
              <p className="mt-1 text-sm font-bold text-emerald-400 truncate">
                {formatCompact(summary.totalIncome)}
              </p>
            </div>
            <div className="rounded-xl bg-red-500/10 border border-red-500/20 px-3 py-2.5">
              <div className="flex items-center gap-1.5 text-red-400">
                <ArrowUpRight className="h-3.5 w-3.5" />
                <span className="text-[11px] font-semibold">Total Keluar</span>
              </div>
              <p className="mt-1 text-sm font-bold text-red-400 truncate">
                {formatCompact(summary.totalExpense)}
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Stat MTD Grid */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          icon={<TrendingUp className="h-4 w-4" />}
          label="Masuk Bulan Ini"
          value={formatCompact(summary.mtdIncome)}
          color="emerald"
        />
        <StatCard
          icon={<TrendingDown className="h-4 w-4" />}
          label="Keluar Bulan Ini"
          value={formatCompact(summary.mtdExpense)}
          color="red"
        />
        <StatCard
          icon={<WalletIcon className="h-4 w-4" />}
          label="Selisih MTD"
          value={formatCompact(summary.mtdBalance)}
          color={summary.mtdBalance >= 0 ? "emerald" : "red"}
        />
        <StatCard
          icon={<Target className="h-4 w-4" />}
          label="Savings Rate MTD"
          value={`${summary.mtdSavingsRate.toFixed(1)}%`}
          color={summary.mtdSavingsRate >= 20 ? "gold" : "amber"}
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-2">
        <Button
          onClick={onAdd}
          size="lg"
          className="h-14 rounded-2xl gradient-gold text-primary-foreground border-0 shadow-lg shadow-[oklch(0.78_0.16_85/0.4)] hover:opacity-90"
        >
          <Plus className="h-5 w-5 mr-2" />
          Transaksi
        </Button>
        <Button
          onClick={onTransfer}
          size="lg"
          variant="outline"
          className="h-14 rounded-2xl glass border-gold hover:bg-accent"
        >
          <ArrowLeftRight className="h-5 w-5 mr-2 text-gold" />
          Transfer
        </Button>
      </div>

      {/* Budget Alerts Preview (hanya jika ada alert) */}
      {budgetAlerts.length > 0 && (
        <Card className="border-amber-500/30 bg-amber-500/5 p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-amber-400">
              <AlertTriangle className="h-4 w-4" />
              <h3 className="text-sm font-semibold">Anggaran Hampir Habis</h3>
            </div>
            <Button variant="ghost" size="sm" onClick={onOpenBudget}>
              Kelola
            </Button>
          </div>
          <div className="space-y-2">
            {budgetAlerts.slice(0, 3).map((b) => (
              <div key={b.budget.id} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">{b.coaName}</span>
                  <span
                    className={cn(
                      "font-bold tabular-nums",
                      b.percent >= 100 ? "text-red-400" : "text-amber-400"
                    )}
                  >
                    {b.percent.toFixed(0)}%
                  </span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className={cn(
                      "h-full rounded-full",
                      b.percent >= 100 ? "bg-red-500" : "bg-amber-500"
                    )}
                    style={{ width: `${Math.min(100, b.percent)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Savings Goals Preview */}
      {activeGoals.length > 0 && (
        <Card className="glass p-4 border-border/50">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <PiggyBank className="h-4 w-4 text-violet-400" />
              <h3 className="text-sm font-semibold">Target Tabungan</h3>
            </div>
            <Button variant="ghost" size="sm" onClick={onOpenSavings}>
              Lihat
            </Button>
          </div>
          <div className="space-y-3">
            {activeGoals.map((g) => {
              // [v9.0 fix] T-1.2: pakai visibleTransactions (filter soft-deleted)
              const { percent } = getSavingsProgress(g, visibleTransactions, data.wallets);
              return (
                <div key={g.id} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium">{g.name}</span>
                    <span className="text-muted-foreground tabular-nums">
                      {formatCompact(g.currentAmount)} / {formatCompact(g.targetAmount)}
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-violet-500 to-pink-500"
                      style={{ width: `${Math.min(100, percent)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Wallets Quick View */}
      <div>
        <div className="flex items-center justify-between px-1 mb-2">
          <h2 className="text-base font-semibold">Dompet Saya</h2>
          <Button variant="ghost" size="sm" onClick={onSwitchWallet}>
            Kelola
          </Button>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
          {activeWallets.slice(0, 5).map((w) => {
            // [v9.0 fix] T-1.2: pakai visibleTransactions (filter soft-deleted) supaya saldo wallet
            // tidak terpengaruh transaksi yang baru saja di-soft-delete.
            const balance = getWalletBalance(w.id, visibleTransactions, data.wallets);
            return (
              <button
                key={w.id}
                onClick={onSwitchWallet}
                className="flex w-32 shrink-0 flex-col gap-1 rounded-2xl glass p-3 text-left hover:bg-accent transition-colors"
                style={{ borderColor: w.color + "40" }}
              >
                <div className="flex items-center gap-1.5">
                  <span className="text-lg">{w.icon}</span>
                  <span className="truncate text-xs font-medium">{w.name}</span>
                </div>
                <p
                  className={cn(
                    "text-sm font-bold tabular-nums truncate",
                    balance < 0 ? "text-red-400" : "text-foreground"
                  )}
                >
                  {formatCompact(balance)}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Transactions */}
      <div>
        <div className="flex items-center justify-between px-1 mb-2">
          <h2 className="text-base font-semibold">Transaksi Terbaru</h2>
          {hasData && (
            <Button variant="ghost" size="sm" onClick={onSeeAll}>
              Lihat semua
            </Button>
          )}
        </div>

        {recent.length === 0 ? (
          <Card className="glass flex flex-col items-center justify-center gap-3 p-8 text-center border-border/50">
            <div className="rounded-full bg-violet-500/10 p-4">
              <WalletIcon className="h-8 w-8 text-violet-400" />
            </div>
            <div>
              <p className="font-medium">Belum ada transaksi</p>
              <p className="text-sm text-muted-foreground mt-0.5">
                Mulai catat uang masuk &amp; keluar dengan menekan tombol Transaksi
                di atas.
              </p>
            </div>
          </Card>
        ) : (
          <div className="space-y-2">
            {recent.map((t) => {
              const wallet = getWallet(data.wallets, t.walletId);
              const coa = getCOAAccount(data.coa, t.coaId);
              const isIncome = t.type === "income";
              const isTransfer = t.type === "transfer";
              const color = isIncome
                ? "text-emerald-400"
                : isTransfer
                ? "text-violet-400"
                : "text-pink-400";
              const bg = isIncome
                ? "bg-emerald-500/10"
                : isTransfer
                ? "bg-violet-500/10"
                : "bg-pink-500/10";
              return (
                <button
                  key={t.id}
                  onClick={() => onOpenTransaction(t)}
                  className="flex w-full items-center gap-3 rounded-xl glass p-3 text-left hover:bg-accent transition-colors border-border/50"
                >
                  <div
                    className={cn(
                      "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
                      bg
                    )}
                  >
                    {wallet?.icon ?? "💵"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {coa?.name ?? t.category}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">
                      {t.note ?? (wallet ? wallet.name : "—")}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={cn("text-sm font-bold tabular-nums", color)}>
                      {isIncome ? "+" : isTransfer ? "↔" : "−"}
                      {formatCompact(t.amount)}
                    </p>
                    <p className="text-[11px] text-muted-foreground">
                      {formatDateShort(t.date)}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: "emerald" | "red" | "gold" | "amber";
}) {
  const colorMap = {
    emerald: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    red: "text-red-400 bg-red-500/10 border-red-500/20",
    gold: "text-gold bg-[oklch(0.78_0.16_85/0.10)] border-gold",
    amber: "text-amber-400 bg-amber-500/10 border-amber-500/20",
  };
  return (
    <Card className="glass p-3.5 border-border/50 animate-card-in">
      <div className={cn("inline-flex items-center gap-1.5 rounded-lg px-2 py-0.5", colorMap[color])}>
        {icon}
        <span className="text-[10px] font-semibold uppercase tracking-wide">
          {label}
        </span>
      </div>
      <p className="mt-2 text-base font-bold tabular-nums truncate">{value}</p>
    </Card>
  );
}
