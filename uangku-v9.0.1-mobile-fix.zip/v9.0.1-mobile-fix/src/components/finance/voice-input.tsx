"use client";

import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Mic, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface VoiceInputProps {
  onResult: (text: string) => void;
  placeholder?: string;
}

// [v9.0 fix] M-x: Typed shapes for Web Speech API (vendor-prefixed in Chrome).
// Sebelumnya `(window as any).SpeechRecognition` + `useRef<any>` + `event: any`.
// Sekarang semua punya interface eksplisit; tidak ada `as any` di file ini.
interface SpeechRecognitionAlternative {
  transcript: string;
  confidence: number;
}
interface SpeechRecognitionResultList {
  length: number;
  [index: number]: {
    0: SpeechRecognitionAlternative;
    isFinal: boolean;
  };
}
interface SpeechRecognitionEvent extends Event {
  resultIndex: number;
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message: string;
}
interface ISpeechRecognition {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start(): void;
  stop(): void;
  abort(): void;
  onstart: ((this: ISpeechRecognition, ev: Event) => unknown) | null;
  onend: ((this: ISpeechRecognition, ev: Event) => unknown) | null;
  onerror:
    | ((this: ISpeechRecognition, ev: SpeechRecognitionErrorEvent) => unknown)
    | null;
  onresult:
    | ((this: ISpeechRecognition, ev: SpeechRecognitionEvent) => unknown)
    | null;
}
interface SpeechRecognitionCtor {
  new (): ISpeechRecognition;
}
interface WindowWithSpeechRecognition extends Window {
  SpeechRecognition?: SpeechRecognitionCtor;
  webkitSpeechRecognition?: SpeechRecognitionCtor;
}

// Voice input pakai Web Speech API (available di Chrome & Android WebView)
export function VoiceInput({ onResult, placeholder }: VoiceInputProps) {
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<ISpeechRecognition | null>(null);

  function startListening() {
    // Cek support
    const w =
      typeof window !== "undefined"
        ? (window as WindowWithSpeechRecognition)
        : undefined;
    const SpeechRecognition = w?.SpeechRecognition ?? w?.webkitSpeechRecognition;

    if (!SpeechRecognition) {
      toast.error("Voice input tidak didukung di browser ini. Pakai Chrome/Android.");
      return;
    }

    const recognition: ISpeechRecognition = new SpeechRecognition();
    recognition.lang = "id-ID";
    recognition.continuous = false;
    recognition.interimResults = true;

    recognition.onstart = () => {
      setListening(true);
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let transcript = "";
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      if (event.results[0]?.isFinal) {
        onResult(transcript.trim());
        setListening(false);
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      setListening(false);
      if (event.error === "not-allowed") {
        toast.error("Izin mikrofon ditolak. Aktifkan di pengaturan.");
      } else {
        toast.error("Voice input error: " + event.error);
      }
    };

    recognition.onend = () => {
      setListening(false);
    };

    recognitionRef.current = recognition;
    recognition.start();
  }

  function stopListening() {
    recognitionRef.current?.stop();
    setListening(false);
  }

  return (
    <button
      type="button"
      onClick={listening ? stopListening : startListening}
      className={cn(
        "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs transition-colors w-full",
        listening
          ? "bg-red-500/20 text-red-400 border border-red-500/40"
          : "bg-muted/40 text-muted-foreground hover:bg-accent border border-border/50"
      )}
    >
      {listening ? (
        <>
          <Square className="h-3.5 w-3.5 animate-pulse" />
          <span>Mendengarkan... tap untuk berhenti</span>
        </>
      ) : (
        <>
          <Mic className="h-3.5 w-3.5" />
          <span>{placeholder ?? "Voice input — bicara untuk isi"}</span>
        </>
      )}
    </button>
  );
}
