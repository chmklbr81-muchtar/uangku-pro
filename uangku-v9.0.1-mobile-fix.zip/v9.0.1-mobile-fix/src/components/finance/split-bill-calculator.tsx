"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Users,
  Plus,
  Trash2,
  Divide,
  Calculator as CalcIcon,
  Copy,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { formatCurrency } from "@/lib/finance";

interface SplitBillProps {
  onAddTransaction?: (amount: number, note: string) => void;
}

interface SplitPerson {
  id: string;
  name: string;
  share: number; // berapa yang harus dibayar
  paid: boolean; // apakah sudah bayar
}

export function SplitBillCalculator({ onAddTransaction }: SplitBillProps) {
  const [totalAmount, setTotalAmount] = useState("");
  const [peopleCount, setPeopleCount] = useState(2);
  const [people, setPeople] = useState<SplitPerson[]>([
    { id: "1", name: "Saya", share: 0, paid: true },
    { id: "2", name: "Teman 1", share: 0, paid: false },
  ]);

  function addPerson() {
    if (people.length >= 20) {
      toast.error("Maksimal 20 orang");
      return;
    }
    const newId = String(people.length + 1);
    setPeople([...people, { id: newId, name: `Teman ${people.length}`, share: 0, paid: false }]);
    setPeopleCount(peopleCount + 1);
  }

  function removePerson(id: string) {
    if (people.length <= 2) {
      toast.error("Minimal 2 orang");
      return;
    }
    setPeople(people.filter((p) => p.id !== id));
    setPeopleCount(peopleCount - 1);
  }

  function calculateSplit() {
    const total = Number(totalAmount.replace(/[^0-9]/g, ""));
    if (!total || total <= 0) return;
    const perPerson = total / people.length;
    setPeople(people.map((p) => ({ ...p, share: Math.round(perPerson) })));
  }

  const total = Number(totalAmount.replace(/[^0-9]/g, "")) || 0;
  const myShare = people.find((p) => p.name === "Saya")?.share ?? 0;
  const othersOwe = people.filter((p) => p.name !== "Saya" && !p.paid).reduce((a, p) => a + p.share, 0);

  function copyResult() {
    if (!total) return;
    const perPerson = (total / people.length).toFixed(0);
    const text = `Split Bill — Total: ${formatCurrency(total)}, ${people.length} orang, masing-masing ${formatCurrency(Number(perPerson))}`;
    navigator.clipboard?.writeText(text);
    toast.success("Disalin ke clipboard!");
  }

  return (
    <Card className="glass p-4 border-border/50 space-y-3">
      <div className="flex items-center gap-2">
        <CalcIcon className="h-4 w-4 text-gold" />
        <h3 className="text-sm font-semibold">Split Bill Calculator</h3>
      </div>
      <p className="text-[11px] text-muted-foreground">
        Hitung tagihan bareng — masing-masing orang bayar berapa.
      </p>

      <div className="space-y-1.5">
        <Label htmlFor="split-total" className="text-xs">Total Tagihan</Label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
          <Input
            id="split-total"
            inputMode="numeric"
            placeholder="300000"
            value={totalAmount}
            onChange={(e) => {
              const only = e.target.value.replace(/[^0-9]/g, "");
              setTotalAmount(only ? Number(only).toLocaleString("id-ID") : "");
            }}
            className="pl-10 bg-input/50 border-border/50 text-sm font-semibold"
          />
        </div>
      </div>

      {/* People list */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <Label className="text-xs">Orang ({people.length})</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={addPerson}
            className="h-6 text-xs text-gold"
          >
            <Plus className="h-3 w-3 mr-0.5" />Tambah
          </Button>
        </div>
        <div className="space-y-1">
          {people.map((p, idx) => (
            <div key={p.id} className="flex items-center gap-2 p-1.5 rounded-lg bg-muted/30">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-muted text-xs font-bold">
                {idx + 1}
              </div>
              <Input
                value={p.name}
                onChange={(e) => {
                  setPeople(people.map((x) => (x.id === p.id ? { ...x, name: e.target.value } : x)));
                }}
                className="h-8 text-xs bg-input/50 border-border/50"
                placeholder="Nama"
              />
              <span className="text-xs font-bold tabular-nums w-20 text-right">
                {p.share > 0 ? formatCurrency(p.share) : "—"}
              </span>
              {people.length > 2 && (
                <button
                  onClick={() => removePerson(p.id)}
                  className="text-red-400 hover:text-red-500"
                  aria-label="Hapus"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-2">
        <Button
          onClick={calculateSplit}
          disabled={!totalAmount}
          size="sm"
          className="flex-1 gradient-gold text-primary-foreground border-0 h-9"
        >
          <Divide className="h-3.5 w-3.5 mr-1" />
          Hitung Split
        </Button>
        <Button
          onClick={copyResult}
          disabled={!total}
          variant="outline"
          size="sm"
          className="border-border/50 h-9"
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </div>

      {total > 0 && (
        <div className="rounded-lg bg-[oklch(0.78_0.16_85/0.05)] border border-gold p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">Per Orang ({people.length})</span>
            <span className="font-bold tabular-nums text-gold">
              {formatCurrency(Math.round(total / people.length))}
            </span>
          </div>
          {othersOwe > 0 && (
            <div className="flex items-center justify-between text-xs border-t border-border/30 pt-2">
              <span className="text-muted-foreground">Teman utang ke Anda</span>
              <span className="font-bold tabular-nums text-emerald-400">
                {formatCurrency(othersOwe)}
              </span>
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
