"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
} from "@/lib/types";
import {
  computeHealthScore,
  computeWealthPyramid,
  computeCashFlowForecast,
  simulateWhatIf,
  computeNetWorth,
  calculateLoan,
} from "@/lib/finance-analytics";
import {
  formatCurrency,
  formatCompact,
} from "@/lib/finance";
import {
  Activity,
  PieChart as PieIcon,
  TrendingUp,
  HelpCircle,
  Wallet as WalletIcon,
  Calculator,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownLeft,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface AnalyticsDashboardProps {
  data: AppData;
}

type AnalyticsTab = "health" | "pyramid" | "forecast" | "whatif" | "networth" | "loan";

export function AnalyticsDashboard({ data }: AnalyticsDashboardProps) {
  const [tab, setTab] = useState<AnalyticsTab>("health");

  const tabs: { id: AnalyticsTab; label: string; icon: typeof Activity }[] = [
    { id: "health", label: "Skor", icon: Activity },
    { id: "pyramid", label: "Pyramid", icon: PieIcon },
    { id: "forecast", label: "Proyeksi", icon: TrendingUp },
    { id: "whatif", label: "What-If", icon: HelpCircle },
    { id: "networth", label: "Net Worth", icon: WalletIcon },
    { id: "loan", label: "Kalkulator", icon: Calculator },
  ];

  return (
    <div className="space-y-3 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="h-4 w-4 text-gold" />
          <h2 className="text-sm font-semibold">Analytics Cerdas</h2>
        </div>
        <p className="text-xs text-muted-foreground">
          Analisis keuangan otomatis — skor kesehatan, proyeksi, simulator, & kalkulator.
        </p>
      </Card>

      {/* Sub-tab chips */}
      <div className="flex gap-1.5 overflow-x-auto pb-1 -mx-1 px-1">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.id;
          return (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold transition-colors",
                active
                  ? "gradient-gold text-primary-foreground"
                  : "bg-muted/40 text-muted-foreground hover:bg-accent"
              )}
            >
              <Icon className="h-3.5 w-3.5" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Active view */}
      {tab === "health" && <HealthScoreView data={data} />}
      {tab === "pyramid" && <WealthPyramidView data={data} />}
      {tab === "forecast" && <CashFlowForecastView data={data} />}
      {tab === "whatif" && <WhatIfView data={data} />}
      {tab === "networth" && <NetWorthView data={data} />}
      {tab === "loan" && <LoanCalculatorView />}
    </div>
  );
}

// === 1. HEALTH SCORE ===
function HealthScoreView({ data }: { data: AppData }) {
  const score = computeHealthScore(data);
  const gradeColor =
    score.grade === "A+" || score.grade === "A"
      ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/30"
      : score.grade === "B"
      ? "text-blue-400 bg-blue-500/10 border-blue-500/30"
      : score.grade === "C"
      ? "text-amber-400 bg-amber-500/10 border-amber-500/30"
      : "text-red-400 bg-red-500/10 border-red-500/30";

  return (
    <div className="space-y-3">
      {/* Skor utama */}
      <Card className="glass p-5 border-border/50 text-center">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">Financial Health Score</p>
        <div className={cn("inline-flex items-center justify-center mt-3 h-24 w-24 rounded-full border-4", gradeColor)}>
          <div>
            <p className="text-3xl font-bold tabular-nums">{score.score}</p>
            <p className="text-[10px] text-muted-foreground">dari 100</p>
          </div>
        </div>
        <div className={cn("inline-block mt-2 px-3 py-0.5 rounded-full text-sm font-bold border", gradeColor)}>
          Grade {score.grade}
        </div>
      </Card>

      {/* 6 Components (v9.0 — consolidated emergency, audit task 12-D) */}
      <Card className="glass p-4 border-border/50 space-y-2.5">
        <h3 className="text-sm font-semibold mb-1">Komponen Skor (v9.0 — 6 Metrik)</h3>
        {[
          { label: "Savings Rate", val: score.components.savingsRate, weight: 27, desc: "27% — persentase income yang ditabung (target ≥20%)" },
          { label: "Emergency Fund Months", val: score.components.emergencyFundMonths, weight: 20, desc: "20% — bulan tahan tanpa income (target 3-6 bln)" },
          { label: "Debt Ratio (Aset)", val: score.components.debtRatio, weight: 14, desc: "14% — rasio utang vs (aset+utang), lower is better" },
          { label: "Debt-to-Income", val: score.components.debtToIncome, weight: 10, desc: "10% — cicilan bulanan vs income (target <36%)" },
          { label: "Expense Stability", val: score.components.expenseStability, weight: 15, desc: "15% — konsistensi pengeluaran 6 bulan" },
          { label: "Consistency", val: score.components.consistency, weight: 14, desc: "14% — rutinitas catat transaksi" },
        ].map((c) => (
          <div key={c.label} className="space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium">{c.label} <span className="text-muted-foreground">({c.weight}%)</span></span>
              <span className="font-bold tabular-nums">{c.val}/100</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div
                className={cn(
                  "h-full rounded-full transition-all",
                  c.val >= 70 ? "bg-emerald-500" : c.val >= 40 ? "bg-amber-500" : "bg-red-500"
                )}
                style={{ width: `${c.val}%` }}
              />
            </div>
            <p className="text-[10px] text-muted-foreground">{c.desc}</p>
          </div>
        ))}
      </Card>

      {/* v2 Metrics detail */}
      {score.metrics && (
        <Card className="glass p-4 border-border/50 space-y-1.5">
          <h3 className="text-sm font-semibold mb-1">Metrik Detail</h3>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <p className="text-muted-foreground text-[10px]">Savings Rate</p>
              <p className="font-semibold tabular-nums">{score.metrics.savingsRatePct.toFixed(1)}%</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Emergency Fund Ratio</p>
              <p className="font-semibold tabular-nums">{score.metrics.emergencyFundRatio.toFixed(2)}x</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Emergency Fund Months</p>
              <p className="font-semibold tabular-nums">{score.metrics.emergencyFundMonths.toFixed(1)} bln</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Debt-to-Income Ratio</p>
              <p className="font-semibold tabular-nums">{score.metrics.debtToIncomePct.toFixed(0)}%</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Rata-rata Income Bulanan</p>
              <p className="font-semibold tabular-nums">{formatCurrency(score.metrics.monthlyIncome)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Rata-rata Expense Bulanan</p>
              <p className="font-semibold tabular-nums">{formatCurrency(score.metrics.monthlyExpense)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Estimasi Cicilan Utang/Bln</p>
              <p className="font-semibold tabular-nums">{formatCurrency(score.metrics.monthlyDebtService)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-[10px]">Total Utang Outstanding</p>
              <p className="font-semibold tabular-nums">{formatCurrency(score.metrics.totalDebt)}</p>
            </div>
          </div>
        </Card>
      )}

      {/* Insights */}
      <Card className="glass p-4 border-border/50 space-y-2">
        <h3 className="text-sm font-semibold mb-1">Insight</h3>
        {score.insights.map((ins, i) => (
          <p key={i} className="text-xs text-muted-foreground">{ins}</p>
        ))}
      </Card>

      {/* Recommendations */}
      {score.recommendations.length > 0 && (
        <Card className="glass p-4 border-amber-500/30 bg-amber-500/5 space-y-2">
          <h3 className="text-sm font-semibold mb-1 text-amber-400">Saran Perbaikan</h3>
          {score.recommendations.map((rec, i) => (
            <div key={i} className="flex items-start gap-2">
              <span className="text-amber-400 mt-0.5">→</span>
              <p className="text-xs text-muted-foreground">{rec}</p>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}

// === 2. WEALTH PYRAMID ===
function WealthPyramidView({ data }: { data: AppData }) {
  const pyramid = computeWealthPyramid(data);

  const quadrants = [
    { label: "Kebutuhan (Needs)", val: pyramid.needs, pct: pyramid.proportions.needs, color: "bg-emerald-500", ideal: 50 },
    { label: "Gaya Hidup (Wants)", val: pyramid.wants, pct: pyramid.proportions.wants, color: "bg-amber-500", ideal: 30 },
    { label: "Tabungan (Savings)", val: pyramid.savings, pct: pyramid.proportions.savings, color: "bg-blue-500", ideal: 20 },
    { label: "Investasi", val: pyramid.investing, pct: pyramid.proportions.investing, color: "bg-violet-500", ideal: 10 },
  ];

  return (
    <div className="space-y-3">
      <Card className="glass p-4 border-border/50">
        <h3 className="text-sm font-semibold mb-1">Wealth Pyramid Bulan Ini</h3>
        <p className="text-[11px] text-muted-foreground mb-3">
          Klasifikasi pengeluaran berdasarkan aturan 50/30/20 yang diperluas.
        </p>
        {/* Bar visualisasi */}
        <div className="flex h-8 rounded-lg overflow-hidden border border-border/30">
          {quadrants.map((q) => (
            q.pct > 0 && (
              <div
                key={q.label}
                className={q.color}
                style={{ width: `${q.pct}%` }}
                title={`${q.label}: ${q.pct.toFixed(0)}%`}
              />
            )
          ))}
        </div>
        <div className="grid grid-cols-4 gap-1 mt-2">
          {quadrants.map((q) => (
            <div key={q.label} className="text-center">
              <div className={cn("inline-block h-2.5 w-2.5 rounded-full", q.color)} />
              <p className="text-[9px] text-muted-foreground mt-0.5">{q.label.split(" ")[0]}</p>
              <p className="text-xs font-bold tabular-nums">{q.pct.toFixed(0)}%</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Detail per quadrant */}
      <div className="space-y-2">
        {quadrants.map((q) => (
          <Card key={q.label} className="glass p-3 border-border/50">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className={cn("h-8 w-8 rounded-lg flex items-center justify-center", q.color, "opacity-80")}>
                  <div className="h-2.5 w-2.5 rounded-full bg-white" />
                </div>
                <div>
                  <p className="text-sm font-medium">{q.label}</p>
                  <p className="text-[10px] text-muted-foreground">Ideal: {q.ideal}%</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold tabular-nums">{formatCurrency(q.val)}</p>
                <p className={cn(
                  "text-[10px] font-semibold",
                  q.pct > q.ideal * 1.3 ? "text-red-400" : q.pct < q.ideal * 0.5 ? "text-amber-400" : "text-emerald-400"
                )}>
                  {q.pct.toFixed(0)}% {q.pct > q.ideal * 1.3 ? "(over)" : q.pct < q.ideal * 0.5 ? "(low)" : "(ok)"}
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Recommendations */}
      <Card className="glass p-4 border-amber-500/30 bg-amber-500/5 space-y-2">
        <h3 className="text-sm font-semibold mb-1 text-amber-400">Saran</h3>
        {pyramid.recommendations.map((rec, i) => (
          <p key={i} className="text-xs text-muted-foreground">{rec}</p>
        ))}
      </Card>
    </div>
  );
}

// === 3. CASH FLOW FORECAST ===
function CashFlowForecastView({ data }: { data: AppData }) {
  const forecast = computeCashFlowForecast(data);

  return (
    <div className="space-y-3">
      {/* Current balance */}
      <Card className="glass p-4 border-border/50">
        <p className="text-xs text-muted-foreground uppercase tracking-wide">Saldo Saat Ini</p>
        <p className="text-2xl font-bold text-gradient-gold mt-1">{formatCurrency(forecast.currentBalance)}</p>
      </Card>

      {/* Avg stats */}
      <div className="grid grid-cols-2 gap-2">
        <Card className="glass p-3 border-border/50">
          <div className="flex items-center gap-1 text-emerald-400">
            <ArrowDownLeft className="h-3.5 w-3.5" />
            <span className="text-[10px] font-medium">Avg Income/Bln</span>
          </div>
          <p className="mt-1 text-sm font-bold text-emerald-400">{formatCompact(forecast.monthlyAvgIncome)}</p>
        </Card>
        <Card className="glass p-3 border-border/50">
          <div className="flex items-center gap-1 text-red-400">
            <ArrowUpRight className="h-3.5 w-3.5" />
            <span className="text-[10px] font-medium">Avg Expense/Bln</span>
          </div>
          <p className="mt-1 text-sm font-bold text-red-400">{formatCompact(forecast.monthlyAvgExpense)}</p>
        </Card>
      </div>

      {/* 6 bulan forecast */}
      <Card className="glass p-4 border-border/50 space-y-2">
        <h3 className="text-sm font-semibold">Proyeksi 6 Bulan ke Depan</h3>
        <p className="text-[11px] text-muted-foreground">
          Berdasarkan rata-rata 3 bulan terakhir.
        </p>
        <div className="space-y-1.5 mt-2">
          {forecast.months.map((m) => (
            <div key={m.monthKey} className="flex items-center justify-between text-xs p-2 rounded-lg border border-border/30 bg-muted/20">
              <div className="flex-1">
                <p className="font-semibold">{m.label}</p>
                <p className="text-[10px] text-muted-foreground">
                  +{formatCompact(m.projectedIncome)} / -{formatCompact(m.projectedExpense)}
                </p>
              </div>
              <div className="text-right">
                <p className={cn(
                  "font-bold tabular-nums",
                  m.projectedBalance < 0 ? "text-red-400" : "text-foreground"
                )}>
                  {formatCurrency(m.projectedBalance)}
                </p>
                {m.warning && (
                  <p className="text-[9px] text-red-400 font-medium">{m.warning}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="glass p-3 border-blue-500/30 bg-blue-500/5">
        <p className="text-[11px] text-muted-foreground">
          💡 Proyeksi ini asumsi pengeluaran & pemasukan stabil. Untuk hasil lebih akurat,
          catat transaksi rutin setiap hari.
        </p>
      </Card>
    </div>
  );
}

// === 4. WHAT-IF SIMULATOR ===
function WhatIfView({ data }: { data: AppData }) {
  const [itemName, setItemName] = useState("");
  const [itemCost, setItemCost] = useState("");
  const [result, setResult] = useState<ReturnType<typeof simulateWhatIf> | null>(null);

  function simulate() {
    const cost = Number(itemCost.replace(/[^0-9]/g, ""));
    if (!itemName.trim() || cost <= 0) {
      toast.error("Isi nama & harga item");
      return;
    }
    const r = simulateWhatIf(data, itemName.trim(), cost);
    setResult(r);
  }

  return (
    <div className="space-y-3">
      <Card className="glass p-4 border-border/50">
        <h3 className="text-sm font-semibold mb-1">What-If Simulator</h3>
        <p className="text-[11px] text-muted-foreground mb-3">
          "Apakah saya bisa beli X bulan depan?" — cek kelayakan pembelian berdasarkan cash flow.
        </p>
        <div className="space-y-2">
          <div className="space-y-1">
            <Label htmlFor="whatif-name" className="text-xs">Nama Item</Label>
            <Input
              id="whatif-name"
              placeholder="Contoh: iPhone 15, Motor, Liburan Bali"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
              className="bg-input/50 border-border/50 text-sm"
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="whatif-cost" className="text-xs">Harga</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="whatif-cost"
                inputMode="numeric"
                placeholder="15000000"
                value={itemCost}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setItemCost(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 bg-input/50 border-border/50 text-sm font-semibold"
              />
            </div>
          </div>
          <Button
            onClick={simulate}
            disabled={!itemName || !itemCost}
            className="w-full gradient-gold text-primary-foreground border-0"
          >
            <HelpCircle className="h-4 w-4 mr-1" />
            Simulasi Sekarang
          </Button>
        </div>
      </Card>

      {result && (
        <Card className={cn(
          "glass p-4 border-2 space-y-3",
          result.canAfford && result.monthsToAfford === 0
            ? "border-emerald-500/40 bg-emerald-500/5"
            : result.canAfford
            ? "border-blue-500/40 bg-blue-500/5"
            : "border-red-500/40 bg-red-500/5"
        )}>
          <div className="flex items-center gap-2">
            {result.canAfford ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-400" />
            ) : (
              <AlertTriangle className="h-5 w-5 text-red-400" />
            )}
            <h3 className={cn(
              "text-sm font-bold",
              result.canAfford ? "text-emerald-400" : "text-red-400"
            )}>
              {result.canAfford ? "Bisa!" : "Belum Bisa"}
            </h3>
          </div>
          <p className="text-sm font-medium">{result.recommendation}</p>
          {result.breakdown && (
            <div className="rounded-lg bg-muted/30 p-2.5 text-[11px] font-mono text-muted-foreground">
              {result.breakdown}
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-lg bg-muted/40 p-2">
              <p className="text-[10px] text-muted-foreground">Saldo Baru</p>
              <p className="text-sm font-bold tabular-nums">{formatCurrency(result.newBalance)}</p>
            </div>
            <div className="rounded-lg bg-muted/40 p-2">
              <p className="text-[10px] text-muted-foreground">Bulan Menabung</p>
              <p className="text-sm font-bold tabular-nums">
                {result.monthsToAfford === null ? "—" : result.monthsToAfford === 0 ? "Sekarang" : `${result.monthsToAfford} bln`}
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

// === 5. NET WORTH TRACKER ===
function NetWorthView({ data }: { data: AppData }) {
  const netWorth = computeNetWorth(data);

  return (
    <div className="space-y-3">
      {/* Net Worth Big Number */}
      <Card className="glass p-5 border-border/50 text-center">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">Net Worth</p>
        <p className={cn(
          "text-3xl font-bold mt-1 tabular-nums",
          netWorth.netWorth >= 0 ? "text-gradient-gold" : "text-red-400"
        )}>
          {formatCurrency(netWorth.netWorth)}
        </p>
        <p className="text-[11px] text-muted-foreground mt-1">
          Total Aset − Total Kewajiban
        </p>
      </Card>

      {/* Aset vs Kewajiban */}
      <div className="grid grid-cols-2 gap-2">
        <Card className="glass p-3 border-emerald-500/30">
          <p className="text-[10px] uppercase text-emerald-400 font-semibold">Aset</p>
          <p className="text-base font-bold text-emerald-400 tabular-nums mt-0.5">
            {formatCurrency(netWorth.aset.totalAset)}
          </p>
        </Card>
        <Card className="glass p-3 border-red-500/30">
          <p className="text-[10px] uppercase text-red-400 font-semibold">Kewajiban</p>
          <p className="text-base font-bold text-red-400 tabular-nums mt-0.5">
            {formatCurrency(netWorth.kewajiban.totalKewajiban)}
          </p>
        </Card>
      </div>

      {/* Breakdown Aset */}
      <Card className="glass p-4 border-border/50 space-y-2">
        <h3 className="text-sm font-semibold mb-1">Rincian Aset</h3>
        {[
          { label: "Saldo Dompet", val: netWorth.aset.wallets, icon: "💵" },
          { label: "Tabungan", val: netWorth.aset.savings, icon: "🐷" },
          { label: "Investasi", val: netWorth.aset.investments, icon: "📈" },
          { label: "Piutang (Utang ke Saya)", val: netWorth.aset.receivables, icon: "🤝" },
        ].map((a) => (
          <div key={a.label} className="flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              <span className="mr-1.5">{a.icon}</span>{a.label}
            </span>
            <span className="font-semibold tabular-nums">{formatCurrency(a.val)}</span>
          </div>
        ))}
      </Card>

      {/* History 6 bulan */}
      <Card className="glass p-4 border-border/50 space-y-2">
        <h3 className="text-sm font-semibold mb-1">Tren 6 Bulan</h3>
        <div className="space-y-1">
          {netWorth.history.map((h) => (
            <div key={h.monthKey} className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">{h.label}</span>
              <div className="flex items-center gap-2">
                <div className="w-24 h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-gold rounded-full"
                    style={{
                      width: `${Math.min(100, Math.abs(h.netWorth) / Math.max(1, Math.max(...netWorth.history.map(x => Math.abs(x.netWorth)))) * 100)}%`,
                    }}
                  />
                </div>
                <span className="font-semibold tabular-nums w-20 text-right">
                  {formatCompact(h.netWorth)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// === 6. LOAN CALCULATOR ===
function LoanCalculatorView() {
  const [principal, setPrincipal] = useState("");
  const [rate, setRate] = useState("");
  const [years, setYears] = useState("5");
  const [result, setResult] = useState<ReturnType<typeof calculateLoan> | null>(null);

  function calculate() {
    const p = Number(principal.replace(/[^0-9]/g, ""));
    const r = Number(rate.replace(/[^0-9.]/g, ""));
    const y = Number(years);
    if (!p || r < 0 || !y) {
      toast.error("Isi semua field");
      return;
    }
    setResult(calculateLoan(p, r, y));
  }

  return (
    <div className="space-y-3">
      <Card className="glass p-4 border-border/50">
        <h3 className="text-sm font-semibold mb-1">Loan Calculator</h3>
        <p className="text-[11px] text-muted-foreground mb-3">
          Hitung angsuran bulanan kredit/utang. Cocok untuk KPA, cicilan mobil, KTA.
        </p>
        <div className="space-y-2">
          <div className="space-y-1">
            <Label htmlFor="loan-principal" className="text-xs">Jumlah Pinjaman</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                id="loan-principal"
                inputMode="numeric"
                placeholder="100000000"
                value={principal}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setPrincipal(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 bg-input/50 border-border/50 text-sm font-semibold"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label htmlFor="loan-rate" className="text-xs">Bunga/Tahun (%)</Label>
              <Input
                id="loan-rate"
                inputMode="numeric"
                placeholder="8.5"
                value={rate}
                onChange={(e) => setRate(e.target.value.replace(/[^0-9.]/g, ""))}
                className="bg-input/50 border-border/50 text-sm"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="loan-years" className="text-xs">Tenor (Tahun)</Label>
              <Select value={years} onValueChange={setYears}>
                <SelectTrigger className="bg-input/50 border-border/50 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-strong border-border/50">
                  {[1, 2, 3, 5, 10, 15, 20, 25, 30].map((y) => (
                    <SelectItem key={y} value={String(y)}>{y} tahun</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button
            onClick={calculate}
            disabled={!principal || !rate}
            className="w-full gradient-gold text-primary-foreground border-0"
          >
            <Calculator className="h-4 w-4 mr-1" />
            Hitung Angsuran
          </Button>
        </div>
      </Card>

      {result && (
        <>
          {/* Main result */}
          <Card className="glass p-4 border-gold bg-[oklch(0.78_0.16_85/0.05)] text-center">
            <p className="text-xs text-muted-foreground uppercase tracking-wider">Angsuran/Bulan</p>
            <p className="text-3xl font-bold text-gradient-gold mt-1 tabular-nums">
              {formatCurrency(result.monthlyPayment)}
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">
              {result.years} tahun · Bunga {result.annualRate}%/tahun
            </p>
          </Card>

          {/* Detail */}
          <div className="grid grid-cols-2 gap-2">
            <Card className="glass p-3 border-border/50">
              <p className="text-[10px] text-muted-foreground uppercase">Total Bayar</p>
              <p className="text-sm font-bold tabular-nums mt-0.5">
                {formatCurrency(result.totalPayment)}
              </p>
            </Card>
            <Card className="glass p-3 border-red-500/30">
              <p className="text-[10px] text-red-400 uppercase">Total Bunga</p>
              <p className="text-sm font-bold text-red-400 tabular-nums mt-0.5">
                {formatCurrency(result.totalInterest)}
              </p>
            </Card>
          </div>

          {/* Amortization Schedule */}
          {result.amortizationSchedule.length > 0 && (
            <Card className="glass p-3 border-border/50">
              <p className="text-xs font-semibold mb-1.5">Jadwal 12 Bulan Pertama</p>
              <div className="space-y-1">
                {result.amortizationSchedule.map((s) => (
                  <div key={s.month} className="flex items-center justify-between text-[11px] py-1 border-b border-border/20 last:border-0">
                    <span className="text-muted-foreground">Bln {s.month}</span>
                    <div className="flex gap-3">
                      <span className="text-red-400 tabular-nums">+{formatCompact(s.interest)}</span>
                      <span className="text-emerald-400 tabular-nums">-{formatCompact(s.principal)}</span>
                      <span className="font-semibold tabular-nums w-16 text-right">
                        {formatCompact(s.balance)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground mt-2">
                <span className="text-red-400">+</span> bunga · <span className="text-emerald-400">−</span> pokok · sisanya saldo
              </p>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
