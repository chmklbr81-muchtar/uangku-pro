"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Palette } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ThemeChoice } from "@/lib/types";
import { toast } from "sonner";

interface ThemePickerProps {
  currentTheme: ThemeChoice;
  onChange: (theme: ThemeChoice) => void;
}

const THEMES: { id: ThemeChoice; label: string; description: string; preview: { bg: string; accent: string; text: string } }[] = [
  {
    id: "navy-gold",
    label: "Navy-Gold",
    description: "Default — Navy gelap + gold mewah",
    preview: { bg: "oklch(0.14 0.04 260)", accent: "oklch(0.78 0.16 85)", text: "oklch(0.94 0.02 70)" },
  },
  {
    id: "bank-pro",
    label: "Bank Pro",
    description: "Biru gelap + kuning emas (BCA Black)",
    preview: { bg: "oklch(0.10 0.03 250)", accent: "oklch(0.85 0.18 95)", text: "oklch(0.95 0.01 240)" },
  },
  {
    id: "green-eco",
    label: "Green Eco",
    description: "Hijau zaitun + coklat kayu (Lunch Money)",
    preview: { bg: "oklch(0.16 0.04 145)", accent: "oklch(0.70 0.16 145)", text: "oklch(0.93 0.02 90)" },
  },
  {
    id: "pink-pastel",
    label: "Pink Pastel",
    description: "Pink lembut + ungu (feminin)",
    preview: { bg: "oklch(0.18 0.04 350)", accent: "oklch(0.80 0.16 350)", text: "oklch(0.94 0.02 350)" },
  },
  {
    id: "black-cyan",
    label: "Black Cyan",
    description: "Hitam + cyan neon (crypto dashboard)",
    preview: { bg: "oklch(0.08 0.02 200)", accent: "oklch(0.78 0.18 200)", text: "oklch(0.92 0.04 200)" },
  },
];

export function ThemePicker({ currentTheme, onChange }: ThemePickerProps) {
  function applyTheme(theme: ThemeChoice) {
    // Hapus semua class tema dari <html>
    const html = document.documentElement;
    html.classList.remove("theme-bank-pro", "theme-green-eco", "theme-pink-pastel", "theme-black-cyan");
    if (theme !== "navy-gold") {
      html.classList.add(`theme-${theme}`);
    }
    onChange(theme);
    toast.success(`Tema ${THEMES.find((t) => t.id === theme)?.label} diterapkan`);
  }

  return (
    <Card className="glass p-4 border-border/50 space-y-3">
      <div className="flex items-center gap-2">
        <Palette className="h-4 w-4 text-gold" />
        <h3 className="text-sm font-semibold">Tema Aplikasi</h3>
      </div>
      <p className="text-[11px] text-muted-foreground">
        Pilih tema warna sesuai selera. Tema diterapkan langsung.
      </p>
      <div className="grid grid-cols-2 gap-2">
        {THEMES.map((theme) => {
          const active = currentTheme === theme.id;
          return (
            <button
              key={theme.id}
              onClick={() => applyTheme(theme.id)}
              className={cn(
                "relative rounded-xl border-2 p-3 text-left transition-all hover-smooth",
                active
                  ? "border-gold bg-[oklch(0.78_0.16_85/0.05)]"
                  : "border-border/50 hover:bg-accent"
              )}
              style={{ background: theme.preview.bg, color: theme.preview.text }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div
                    className="h-4 w-4 rounded-full"
                    style={{ background: theme.preview.accent }}
                  />
                  <span className="text-sm font-semibold">{theme.label}</span>
                </div>
                {active && <Check className="h-4 w-4" style={{ color: theme.preview.accent }} />}
              </div>
              <p className="text-[10px] opacity-70 mt-1">{theme.description}</p>
            </button>
          );
        })}
      </div>
    </Card>
  );
}
