"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import {
  type AppData,
  type Transaction,
  type TransactionType,
  type Wallet,
  type COAAccount,
} from "@/lib/types";
import {
  getLeafAccounts,
  getWallet,
  getCOAAccount,
  POPULAR_TAGS,
} from "@/lib/default-data";
import { todayISO, genId, formatCurrency } from "@/lib/finance";
import { suggestCOA } from "@/lib/auto-categorize";
import {
  ArrowDownLeft,
  ArrowUpRight,
  Check,
  Trash2,
  X,
  Plus,
  Sparkles,
} from "lucide-react";
import { useState } from "react";
import { CalculatorInput } from "./calculator-input";
import { VoiceInput } from "./voice-input";
import { ReceiptScanner } from "./receipt-scanner";
import type { OCRResult } from "@/hooks/use-ocr";

interface AddTransactionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: AppData;
  onSave: (tx: Transaction) => void;
  onDelete?: (id: string) => void;
  editing?: Transaction | null;
  defaultWalletId?: string;
}

export function AddTransactionDialog({
  open,
  onOpenChange,
  data,
  onSave,
  onDelete,
  editing,
  defaultWalletId,
}: AddTransactionDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px] max-h-[92vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold tracking-tight">
            {editing ? "Edit Transaksi" : "Tambah Transaksi"}
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            Catat uang masuk atau keluar dengan dompet & akun COA.
          </DialogDescription>
        </DialogHeader>
        <TransactionForm
          key={editing?.id ?? "new"}
          editing={editing}
          data={data}
          onSave={onSave}
          onDelete={onDelete}
          onClose={() => onOpenChange(false)}
          defaultWalletId={defaultWalletId}
        />
      </DialogContent>
    </Dialog>
  );
}

interface TransactionFormProps {
  editing?: Transaction | null;
  data: AppData;
  onSave: (tx: Transaction) => void;
  onDelete?: (id: string) => void;
  onClose: () => void;
  defaultWalletId?: string;
}

function TransactionForm({
  editing,
  data,
  onSave,
  onDelete,
  onClose,
  defaultWalletId,
}: TransactionFormProps) {
  const [type, setType] = useState<TransactionType>(
    editing?.type ?? "expense"
  );
  const [amount, setAmount] = useState<string>(
    editing ? String(editing.amount) : ""
  );
  const [walletId, setWalletId] = useState<string>(
    editing?.walletId ?? defaultWalletId ?? data.wallets[0]?.id ?? ""
  );
  const [coaId, setCoaId] = useState<string>(
    editing?.coaId ?? ""
  );
  const [date, setDate] = useState<string>(editing?.date ?? todayISO());
  const [note, setNote] = useState<string>(editing?.note ?? "");
  const [tags, setTags] = useState<string[]>(editing?.tags ?? []);
  const [customTag, setCustomTag] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [autoSuggest, setAutoSuggest] = useState<{ coaId: string; coaName: string } | null>(null);

  // === Receipt Scanner handler ===
  // Menerima OCRResult dari ReceiptScanner, lalu apply ke form.
  function handleScanResult(scan: OCRResult) {
    if (scan.total !== undefined && scan.total > 0) {
      setAmount(scan.total.toLocaleString("id-ID"));
    }
    if (scan.date) {
      // Validasi format YYYY-MM-DD
      const m = scan.date.match(/^(\d{4})-(\d{2})-(\d{2})$/);
      if (m) setDate(scan.date);
    }
    let noteParts: string[] = [];
    if (scan.merchant) noteParts.push(scan.merchant);
    if (scan.items && scan.items.length > 0) {
      const itemsText = scan.items
        .slice(0, 5) // batasi 5 item agar note tidak terlalu panjang
        .map((it) => `${it.name}${it.qty && it.qty > 1 ? ` x${it.qty}` : ""}`)
        .join(", ");
      noteParts.push(itemsText);
      if (scan.items.length > 5) noteParts.push(`+${scan.items.length - 5} item lainnya`);
    }
    if (noteParts.length > 0) {
      const newNote = noteParts.join(" · ");
      setNote(newNote);
      // Trigger auto-categorize based on note + merchant (only for income/expense, not transfer)
      if (type !== "transfer") {
        const suggested = suggestCOA(newNote, data.coa, type);
        if (suggested) {
          setAutoSuggest({ coaId: suggested.id, coaName: suggested.name });
        }
      }
    }
  }

  // Auto-categorize: suggest COA berdasarkan note
  function handleNoteChange(value: string) {
    setNote(value);
    if (value.trim().length >= 3 && type !== "transfer") {
      const suggested = suggestCOA(value, data.coa, type);
      if (suggested) {
        setAutoSuggest({ coaId: suggested.id, coaName: suggested.name });
      } else {
        setAutoSuggest(null);
      }
    } else {
      setAutoSuggest(null);
    }
  }

  function applyAutoSuggest() {
    if (autoSuggest) {
      setCoaId(autoSuggest.coaId);
      setAutoSuggest(null);
    }
  }

  // Filter COA berdasarkan tipe transaksi
  const typeToCOAFilter = (t: TransactionType) => {
    if (t === "income") return ["income", "other_income"];
    return ["expense", "operating_expense"];
  };

  const leafAccounts = getLeafAccounts(data.coa).filter((c) =>
    typeToCOAFilter(type).includes(c.type)
  );

  // Set COA default saat pertama kali
  useState(() => {
    if (!coaId && leafAccounts.length > 0) {
      setCoaId(leafAccounts[0].id);
    }
  });

  function switchType(newType: TransactionType) {
    setType(newType);
    const filter = typeToCOAFilter(newType);
    const newLeaf = getLeafAccounts(data.coa).filter((c) =>
      filter.includes(c.type)
    );
    // Reset coaId jika tidak valid untuk tipe baru
    const current = data.coa.find((c) => c.id === coaId);
    if (!current || !filter.includes(current.type)) {
      setCoaId(newLeaf[0]?.id ?? "");
    }
  }

  function handleAmountChange(raw: string) {
    const onlyDigits = raw.replace(/[^0-9]/g, "");
    if (!onlyDigits) {
      setAmount("");
      return;
    }
    const formatted = Number(onlyDigits).toLocaleString("id-ID");
    setAmount(formatted);
  }

  function toggleTag(tag: string) {
    setTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  }

  function addCustomTag() {
    const t = customTag.trim().toLowerCase();
    if (!t || tags.includes(t)) {
      setCustomTag("");
      return;
    }
    setTags([...tags, t]);
    setCustomTag("");
  }

  function handleSubmit() {
    const numAmount = Number(amount.replace(/[^0-9]/g, ""));
    if (!numAmount || numAmount <= 0) {
      setError("Jumlah harus lebih dari 0");
      return;
    }
    if (!walletId) {
      setError("Pilih dompet terlebih dahulu");
      return;
    }
    if (!coaId) {
      setError("Pilih akun COA");
      return;
    }
    const coa = getCOAAccount(data.coa, coaId);
    const tx: Transaction = {
      id: editing?.id ?? genId(),
      type,
      amount: numAmount,
      date,
      walletId,
      coaId,
      category: coa?.name ?? "",
      note: note.trim() || undefined,
      tags: tags.length > 0 ? tags : undefined,
      createdAt: editing?.createdAt ?? new Date().toISOString(),
    };
    onSave(tx);
    onClose();
  }

  function handleDelete() {
    if (editing && onDelete) {
      onDelete(editing.id);
      onClose();
    }
  }

  const activeWallet = getWallet(data.wallets, walletId);
  // Kelompokkan COA per induk untuk dropdown yang lebih enak
  const groupedCOA = (() => {
    const map: Record<string, COAAccount[]> = {};
    for (const acc of leafAccounts) {
      const parent = data.coa.find((c) => c.id === acc.parentId);
      const grandparent = parent?.parentId
        ? data.coa.find((c) => c.id === parent.parentId)
        : parent;
      const rootName = grandparent?.name ?? parent?.name ?? "Lainnya";
      if (!map[rootName]) map[rootName] = [];
      map[rootName].push(acc);
    }
    return map;
  })();

  return (
    <>
      {/* Toggle Income / Expense */}
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => switchType("expense")}
          className={cn(
            "flex items-center justify-center gap-2 rounded-xl border-2 px-3 py-3 text-sm font-semibold transition-all",
            type === "expense"
              ? "border-pink-500 bg-pink-500/15 text-pink-400"
              : "border-border bg-transparent text-muted-foreground hover:bg-accent"
          )}
        >
          <ArrowUpRight className="h-4 w-4" />
          Uang Keluar
        </button>
        <button
          type="button"
          onClick={() => switchType("income")}
          className={cn(
            "flex items-center justify-center gap-2 rounded-xl border-2 px-3 py-3 text-sm font-semibold transition-all",
            type === "income"
              ? "border-emerald-500 bg-emerald-500/15 text-emerald-400"
              : "border-border bg-transparent text-muted-foreground hover:bg-accent"
          )}
        >
          <ArrowDownLeft className="h-4 w-4" />
          Uang Masuk
        </button>
      </div>

      {/* Jumlah */}
      <div className="space-y-1.5">
        <Label htmlFor="amount">Jumlah</Label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground font-medium">
            Rp
          </span>
          <Input
            id="amount"
            inputMode="numeric"
            placeholder="0"
            value={amount}
            onChange={(e) => handleAmountChange(e.target.value)}
            className="pl-10 text-lg font-semibold bg-input/50 border-border/50"
            autoFocus
          />
        </div>
        {error && <p className="text-xs text-red-400">{error}</p>}
      </div>

      {/* Kalkulator cepat untuk split bill */}
      <CalculatorInput
        onResult={(total) => setAmount(total.toLocaleString("id-ID"))}
      />

      {/* Receipt Scanner — v8.1: pakai z-ai-web-dev-sdk VLM (glm-4.6v) */}
      {!editing && (
        <ReceiptScanner onScanResult={handleScanResult} />
      )}

      {/* Dompet */}
      <div className="space-y-1.5">
        <Label>Dompet</Label>
        <Select value={walletId} onValueChange={setWalletId}>
          <SelectTrigger className="bg-input/50 border-border/50">
            <SelectValue placeholder="Pilih dompet" />
          </SelectTrigger>
          <SelectContent className="glass-strong border-border/50 max-h-72">
            {data.wallets
              .filter((w) => !w.archived)
              .map((w) => (
                <SelectItem key={w.id} value={w.id}>
                  <span className="mr-2">{w.icon}</span>
                  {w.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
        {activeWallet && (
          <p className="text-[11px] text-muted-foreground">
            {activeWallet.icon} {activeWallet.name}
          </p>
        )}
      </div>

      {/* Akun COA */}
      <div className="space-y-1.5">
        <Label>Akun COA (Kategori)</Label>
        <Select value={coaId} onValueChange={setCoaId}>
          <SelectTrigger className="bg-input/50 border-border/50">
            <SelectValue placeholder="Pilih akun" />
          </SelectTrigger>
          <SelectContent className="glass-strong border-border/50 max-h-72">
            {Object.entries(groupedCOA).map(([rootName, accounts]) => (
              <div key={rootName}>
                <div className="px-2 py-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground/80">
                  {rootName}
                </div>
                {accounts.map((acc) => (
                  <SelectItem key={acc.id} value={acc.id}>
                    <span className="font-mono text-[11px] text-muted-foreground mr-2">
                      {acc.code}
                    </span>
                    {acc.name}
                  </SelectItem>
                ))}
              </div>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Tanggal */}
      <div className="space-y-1.5">
        <Label htmlFor="date">Tanggal</Label>
        <Input
          id="date"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="bg-input/50 border-border/50"
        />
      </div>

      {/* Voice Input */}
      <VoiceInput
        onResult={(text) => {
          setNote(text);
          handleNoteChange(text);
        }}
        placeholder="Voice input catatan (bicara: 'beli bensin 50 ribu')"
      />

      {/* Catatan */}
      <div className="space-y-1.5">
        <Label htmlFor="note">Catatan (opsional)</Label>
        <Textarea
          id="note"
          placeholder="Contoh: Makan siang di kantin"
          value={note}
          onChange={(e) => handleNoteChange(e.target.value)}
          rows={2}
          className="bg-input/50 border-border/50"
        />
        {autoSuggest && (
          <button
            type="button"
            onClick={applyAutoSuggest}
            className="flex items-center gap-1.5 rounded-lg bg-[oklch(0.78_0.16_85/0.10)] border border-gold px-2.5 py-1.5 text-xs text-gold hover:bg-[oklch(0.78_0.16_85/0.20)] transition-colors w-full"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span>Saran kategori: <strong>{autoSuggest.coaName}</strong></span>
            <span className="ml-auto text-[10px]">Tap untuk apply →</span>
          </button>
        )}
      </div>

      {/* Tag */}
      <div className="space-y-1.5">
        <Label>Tag (opsional)</Label>
        <div className="flex flex-wrap gap-1.5">
          {POPULAR_TAGS.map((tag) => {
            const active = tags.includes(tag);
            return (
              <button
                key={tag}
                type="button"
                onClick={() => toggleTag(tag)}
                className={cn(
                  "rounded-full px-2.5 py-1 text-xs font-medium transition-colors",
                  active
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted/60 text-muted-foreground hover:bg-accent"
                )}
              >
                {tag}
              </button>
            );
          })}
          {tags
            .filter((t) => !POPULAR_TAGS.includes(t))
            .map((tag) => (
              <span
                key={tag}
                className="flex items-center gap-1 rounded-full bg-primary text-primary-foreground px-2.5 py-1 text-xs font-medium"
              >
                {tag}
                <button
                  type="button"
                  onClick={() => toggleTag(tag)}
                  aria-label="Hapus tag"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="Tambah tag custom..."
            value={customTag}
            onChange={(e) => setCustomTag(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                addCustomTag();
              }
            }}
            className="bg-input/50 border-border/50 text-sm"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={addCustomTag}
            aria-label="Tambah tag"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <DialogFooter className="flex-row gap-2 sm:gap-2 pt-2">
        {editing && onDelete && (
          <Button
            variant="outline"
            size="icon"
            onClick={handleDelete}
            className="text-red-400 hover:text-red-500 border-border/50"
            aria-label="Hapus"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
        <Button
          variant="outline"
          onClick={onClose}
          className="flex-1 border-border/50"
        >
          Batal
        </Button>
        <Button
          onClick={handleSubmit}
          className={cn(
            "flex-1 border-0",
            type === "income"
              ? "bg-emerald-600 hover:bg-emerald-700 text-white"
              : "bg-pink-600 hover:bg-pink-700 text-white"
          )}
        >
          <Check className="h-4 w-4 mr-1" />
          Simpan
        </Button>
      </DialogFooter>
    </>
  );
}
