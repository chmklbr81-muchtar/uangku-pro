"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  type AppData,
  type RecurringTransaction,
  type RecurringFrequency,
  type Transaction,
} from "@/lib/types";
import { getLeafAccounts, getWallet } from "@/lib/default-data";
import {
  formatCurrency,
  formatDate,
  getMonthLabel,
  genId,
  todayISO,
} from "@/lib/finance";
import {
  Plus,
  Trash2,
  Edit2,
  Repeat,
  Play,
  Calendar,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface RecurringManagerProps {
  data: AppData;
  onUpdate: (recurring: RecurringTransaction[]) => void;
  onExecute: (tx: Transaction) => void;
}

const FREQ_LABELS: Record<RecurringFrequency, string> = {
  weekly: "Mingguan",
  monthly: "Bulanan",
  yearly: "Tahunan",
};

export function RecurringManager({
  data,
  onUpdate,
  onExecute,
}: RecurringManagerProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<RecurringTransaction | null>(null);

  const active = data.recurring.filter((r) => !r.archived);

  function handleSave(r: RecurringTransaction) {
    const exists = data.recurring.some((x) => x.id === r.id);
    const updated = exists
      ? data.recurring.map((x) => (x.id === r.id ? r : x))
      : [...data.recurring, r];
    onUpdate(updated);
    setDialogOpen(false);
    setEditing(null);
    toast.success(exists ? "Template diperbarui" : "Template dibuat");
  }

  function handleDelete(id: string) {
    onUpdate(data.recurring.filter((r) => r.id !== id));
    toast.success("Template dihapus");
  }

  function handleExecute(r: RecurringTransaction) {
    const tx: Transaction = {
      id: genId(),
      type: r.type,
      amount: r.amount,
      date: todayISO(),
      walletId: r.walletId,
      coaId: r.coaId,
      category: data.coa.find((c) => c.id === r.coaId)?.name ?? "",
      note: `${r.name} (berulang)`,
      tags: ["recurring"],
      createdAt: new Date().toISOString(),
      fromRecurringId: r.id,
    };
    onExecute(tx);
    // Update nextRunDate
    const next = computeNextRun(r);
    const updated = data.recurring.map((x) =>
      x.id === r.id ? { ...x, nextRunDate: next } : x
    );
    onUpdate(updated);
    toast.success(`Transaksi "${r.name}" dicatat`);
  }

  return (
    <div className="space-y-4 pb-4">
      <Card className="glass p-4 border-border/50">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold">Transaksi Berulang</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {active.length} template aktif — catat sekali klik
            </p>
          </div>
          <Button
            onClick={() => {
              setEditing(null);
              setDialogOpen(true);
            }}
            size="sm"
            className="bg-primary text-primary-foreground"
          >
            <Plus className="h-4 w-4 mr-1" />
            Template Baru
          </Button>
        </div>
      </Card>

      {active.length === 0 ? (
        <Card className="glass flex flex-col items-center justify-center gap-3 p-10 text-center border-border/50">
          <div className="rounded-full bg-muted/40 p-4">
            <Repeat className="h-8 w-8 text-muted-foreground" />
          </div>
          <div>
            <p className="font-medium">Belum ada template berulang</p>
            <p className="text-sm text-muted-foreground mt-0.5">
              Buat template untuk transaksi rutin seperti gaji, sewa, langganan,
              atau cicilan. Cukup sekali klik untuk catat ulang tiap bulan.
            </p>
          </div>
        </Card>
      ) : (
        <div className="space-y-2">
          {active.map((r) => {
            const wallet = getWallet(data.wallets, r.walletId);
            const coa = data.coa.find((c) => c.id === r.coaId);
            const isIncome = r.type === "income";
            return (
              <Card key={r.id} className="glass p-4 border-border/50">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-xl",
                        isIncome ? "bg-emerald-500/10" : "bg-pink-500/10"
                      )}
                    >
                      <Repeat
                        className={cn(
                          "h-5 w-5",
                          isIncome ? "text-emerald-400" : "text-pink-400"
                        )}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{r.name}</p>
                      <p className="text-[11px] text-muted-foreground truncate">
                        {coa?.name} · {wallet?.icon} {wallet?.name}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      onClick={() => {
                        setEditing(r);
                        setDialogOpen(true);
                      }}
                      aria-label="Edit"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7 text-red-400 hover:text-red-500"
                      onClick={() => handleDelete(r.id)}
                      aria-label="Hapus"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div>
                    <p
                      className={cn(
                        "text-base font-bold tabular-nums",
                        isIncome ? "text-emerald-400" : "text-pink-400"
                      )}
                    >
                      {isIncome ? "+" : "−"}
                      {formatCurrency(r.amount)}
                    </p>
                    <div className="flex items-center gap-1.5 mt-0.5 text-[11px] text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      <span>
                        {FREQ_LABELS[r.frequency]} · Jadwal berikutnya:{" "}
                        <span className="font-medium text-foreground">
                          {formatDate(r.nextRunDate)}
                        </span>
                      </span>
                    </div>
                  </div>
                  <Button
                    onClick={() => handleExecute(r)}
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white border-0"
                  >
                    <Play className="h-3.5 w-3.5 mr-1" />
                    Catat
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <RecurringEditDialog
        open={dialogOpen}
        onOpenChange={(o) => {
          setDialogOpen(o);
          if (!o) setEditing(null);
        }}
        editing={editing}
        data={data}
        onSave={handleSave}
      />
    </div>
  );
}

function computeNextRun(r: RecurringTransaction): string {
  const now = new Date();
  if (r.frequency === "weekly") {
    const d = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return dateToISO(d);
  } else if (r.frequency === "monthly") {
    const d = new Date(now.getFullYear(), now.getMonth() + 1, r.dayOfMonth);
    return dateToISO(d);
  } else {
    const d = new Date(now.getFullYear() + 1, now.getMonth(), r.dayOfMonth);
    return dateToISO(d);
  }
}

function dateToISO(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
}

function RecurringEditDialog({
  open,
  onOpenChange,
  editing,
  data,
  onSave,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editing: RecurringTransaction | null;
  data: AppData;
  onSave: (r: RecurringTransaction) => void;
}) {
  const [name, setName] = useState(editing?.name ?? "");
  const [type, setType] = useState<"income" | "expense">(
    editing?.type ?? "expense"
  );
  const [amount, setAmount] = useState(editing ? String(editing.amount) : "");
  const [walletId, setWalletId] = useState(
    editing?.walletId ?? data.wallets[0]?.id ?? ""
  );
  const [coaId, setCoaId] = useState(editing?.coaId ?? "");
  const [frequency, setFrequency] = useState<RecurringFrequency>(
    editing?.frequency ?? "monthly"
  );
  const [dayOfMonth, setDayOfMonth] = useState(editing?.dayOfMonth ?? 1);
  const [startDate, setStartDate] = useState(editing?.startDate ?? todayISO());
  const [note, setNote] = useState(editing?.note ?? "");

  // [v9.0 fix] setState-during-render anti-pattern (lastOpen) -> useEffect
  // Sinkronisasi state lokal saat dialog dibuka atau editing berubah.
  useEffect(() => {
    if (!open) return;
    setName(editing?.name ?? "");
    setType(editing?.type ?? "expense");
    setAmount(editing ? String(editing.amount) : "");
    setWalletId(editing?.walletId ?? data.wallets[0]?.id ?? "");
    setCoaId(editing?.coaId ?? "");
    setFrequency(editing?.frequency ?? "monthly");
    setDayOfMonth(editing?.dayOfMonth ?? 1);
    setStartDate(editing?.startDate ?? todayISO());
    setNote(editing?.note ?? "");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  const leafAccounts = getLeafAccounts(data.coa).filter((c) =>
    type === "income"
      ? ["income", "other_income"].includes(c.type)
      : ["expense", "operating_expense"].includes(c.type)
  );

  function handleSubmit() {
    const numAmount = Number(amount.replace(/[^0-9]/g, ""));
    if (!name.trim() || !numAmount || !coaId) return;
    const id = editing?.id ?? genId();
    const r: RecurringTransaction = {
      id,
      name: name.trim(),
      type,
      amount: numAmount,
      walletId,
      coaId,
      frequency,
      dayOfMonth: frequency === "weekly" ? 0 : dayOfMonth,
      startDate,
      nextRunDate: editing?.nextRunDate ?? startDate,
      note: note.trim() || undefined,
    };
    onSave(r);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[420px] max-h-[92vh] overflow-y-auto glass-strong border-0">
        <DialogHeader>
          <DialogTitle>
            {editing ? "Edit Template Berulang" : "Template Berulang Baru"}
          </DialogTitle>
          <DialogDescription>
            Buat template untuk transaksi rutin (gaji, sewa, langganan).
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="recur-name">Nama</Label>
            <Input
              id="recur-name"
              placeholder="Contoh: Gaji Bulanan, Netflix, Cicilan"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setType("expense")}
              className={cn(
                "rounded-lg border-2 py-2 text-sm font-semibold transition-colors",
                type === "expense"
                  ? "border-pink-500 bg-pink-500/15 text-pink-400"
                  : "border-border text-muted-foreground"
              )}
            >
              Keluar
            </button>
            <button
              type="button"
              onClick={() => setType("income")}
              className={cn(
                "rounded-lg border-2 py-2 text-sm font-semibold transition-colors",
                type === "income"
                  ? "border-emerald-500 bg-emerald-500/15 text-emerald-400"
                  : "border-border text-muted-foreground"
              )}
            >
              Masuk
            </button>
          </div>
          <div className="space-y-1.5">
            <Label>Jumlah</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">Rp</span>
              <Input
                inputMode="numeric"
                placeholder="0"
                value={amount}
                onChange={(e) => {
                  const only = e.target.value.replace(/[^0-9]/g, "");
                  setAmount(only ? Number(only).toLocaleString("id-ID") : "");
                }}
                className="pl-10 bg-input/50 border-border/50"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Dompet</Label>
            <Select value={walletId} onValueChange={setWalletId}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="Pilih dompet" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50">
                {data.wallets.filter((w) => !w.archived).map((w) => (
                  <SelectItem key={w.id} value={w.id}>
                    {w.icon} {w.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Kategori (COA)</Label>
            <Select value={coaId} onValueChange={setCoaId}>
              <SelectTrigger className="bg-input/50 border-border/50">
                <SelectValue placeholder="Pilih kategori" />
              </SelectTrigger>
              <SelectContent className="glass-strong border-border/50 max-h-72">
                {leafAccounts.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.code} — {a.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label>Frekuensi</Label>
              <Select value={frequency} onValueChange={(v) => setFrequency(v as RecurringFrequency)}>
                <SelectTrigger className="bg-input/50 border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-strong border-border/50">
                  <SelectItem value="weekly">Mingguan</SelectItem>
                  <SelectItem value="monthly">Bulanan</SelectItem>
                  <SelectItem value="yearly">Tahunan</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="recur-day">
                {frequency === "weekly" ? "Hari" : "Tanggal"}
              </Label>
              <Input
                id="recur-day"
                type="number"
                min={frequency === "weekly" ? 0 : 1}
                max={frequency === "weekly" ? 6 : 31}
                value={dayOfMonth}
                onChange={(e) => setDayOfMonth(Number(e.target.value))}
                className="bg-input/50 border-border/50"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="recur-start">Tanggal Mulai</Label>
            <Input
              id="recur-start"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-input/50 border-border/50"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="recur-note">Catatan (opsional)</Label>
            <Textarea
              id="recur-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={2}
              className="bg-input/50 border-border/50"
            />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="border-border/50">
            Batal
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!name.trim() || !amount || !coaId}
            className="bg-primary text-primary-foreground"
          >
            Simpan
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
