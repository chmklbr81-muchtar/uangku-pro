"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Wallet,
  Plus,
  ArrowLeftRight,
  PieChart,
  ShieldCheck,
  X,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface OnboardingProps {
  onFinish: () => void;
}

const SLIDES = [
  {
    icon: Wallet,
    title: "Selamat Datang di Uangku Pro",
    description:
      "Aplikasi pencatat keuangan terlengkap untuk Anda. Multi-dompet, COA akuntansi, dan laporan profesional dalam satu aplikasi.",
    color: "from-amber-500 to-yellow-500",
  },
  {
    icon: Plus,
    title: "Catat Transaksi dengan Mudah",
    description:
      "Tap tombol + di bawah untuk tambah transaksi. Pilih dompet, kategori COA, jumlah, dan selesai! Anda juga bisa scan struk untuk auto-isi.",
    color: "from-emerald-500 to-teal-500",
  },
  {
    icon: ArrowLeftRight,
    title: "Transfer Antar-Dompet Tanpa Bingung",
    description:
      "Pindahkan uang dari Cash ke BCA, dari GoPay ke OVO, atau dompet mana pun — tanpa menggandakan pemasukan/pengeluaran.",
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: PieChart,
    title: "Pantau Keuangan dengan Grafik MTD/YTD",
    description:
      "Lihat tren 12 bulan, klik bulan untuk detail transaksi. Generate Neraca & Laba Rugi otomatis dari Chart of Account.",
    color: "from-purple-500 to-pink-500",
  },
  {
    icon: ShieldCheck,
    title: "Amankan dengan Biometrik & Backup",
    description:
      "Aktifkan fingerprint/Face Unlock di Pengaturan → Keamanan. Backup berkala ke Google Drive supaya data aman saat pindah HP.",
    color: "from-rose-500 to-red-500",
  },
];

export function Onboarding({ onFinish }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const slide = SLIDES[step];
  const isLast = step === SLIDES.length - 1;
  const Icon = slide.icon;

  function next() {
    if (isLast) {
      onFinish();
    } else {
      setStep((s) => s + 1);
    }
  }

  function skip() {
    onFinish();
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Skip button */}
      <div className="absolute top-4 right-4 z-10">
        <Button
          variant="ghost"
          size="sm"
          onClick={skip}
          className="text-muted-foreground hover:text-foreground"
        >
          Lewati <X className="h-3.5 w-3.5 ml-1" />
        </Button>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col items-center justify-center px-6">
        {/* Icon dengan gradient */}
        <div
          className={cn(
            "flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br text-white shadow-2xl mb-8 animate-card-in",
            slide.color
          )}
          key={step}
        >
          <Icon className="h-12 w-12" />
        </div>

        {/* Title & description */}
        <div key={`text-${step}`} className="text-center animate-page-in">
          <h2 className="text-2xl font-bold mb-3 text-foreground">
            {slide.title}
          </h2>
          <p className="text-sm text-muted-foreground leading-relaxed max-w-xs mx-auto">
            {slide.description}
          </p>
        </div>
      </div>

      {/* Progress dots */}
      <div className="flex justify-center gap-1.5 pb-8">
        {SLIDES.map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-1.5 rounded-full transition-all",
              i === step
                ? "w-6 bg-gradient-gold"
                : i < step
                ? "w-1.5 bg-gold/40"
                : "w-1.5 bg-muted"
            )}
          />
        ))}
      </div>

      {/* CTA */}
      <div className="px-6 pb-10">
        <Button
          onClick={next}
          size="lg"
          className="w-full h-14 rounded-2xl gradient-gold text-primary-foreground shadow-lg shadow-[oklch(0.78_0.16_85/0.4)]"
        >
          {isLast ? (
            <>
              Mulai Pakai Uangku Pro
              <Sparkles className="h-5 w-5 ml-2" />
            </>
          ) : (
            <>
              Lanjut
              <ChevronRight className="h-5 w-5 ml-2" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
