"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Trash2,
  LogIn,
  LogOut,
  Plus,
  Edit2,
  RefreshCw,
  Download,
  Upload,
  Settings as SettingsIcon,
  Eye,
  EyeOff,
  Fingerprint,
} from "lucide-react";
import type { ActivityLog, ActivityType } from "@/lib/types";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface ActivityLogViewerProps {
  logs: ActivityLog[];
  onClear: () => void;
}

const ICONS: Record<ActivityType, { icon: typeof LogIn; color: string }> = {
  app_open: { icon: Eye, color: "text-blue-400" },
  app_close: { icon: EyeOff, color: "text-muted-foreground" },
  login_biometric: { icon: Fingerprint, color: "text-emerald-400" },
  login_pin: { icon: LogIn, color: "text-emerald-400" },
  login_failed: { icon: LogIn, color: "text-red-400" },
  tx_add: { icon: Plus, color: "text-emerald-400" },
  tx_edit: { icon: Edit2, color: "text-amber-400" },
  tx_delete: { icon: Trash2, color: "text-red-400" },
  sync_push: { icon: RefreshCw, color: "text-blue-400" },
  sync_pull: { icon: RefreshCw, color: "text-cyan-400" },
  backup_create: { icon: Download, color: "text-emerald-400" },
  backup_restore: { icon: Upload, color: "text-amber-400" },
  settings_change: { icon: SettingsIcon, color: "text-violet-400" },
};

export function ActivityLogViewer({ logs, onClear }: ActivityLogViewerProps) {
  if (logs.length === 0) {
    return (
      <Card className="glass p-6 text-center border-border/50">
        <p className="text-sm text-muted-foreground">Belum ada aktivitas tercatat.</p>
        <p className="text-[11px] text-muted-foreground mt-1">
          Log aktivitas akan muncul di sini setiap kali Anda buka app, login, sync, dll.
        </p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between px-1">
        <p className="text-[11px] text-muted-foreground">
          {logs.length} aktivitas tercatat (maks 200)
        </p>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            if (confirm("Hapus semua log aktivitas? Tidak bisa dibatalkan.")) {
              onClear();
              toast.success("Log aktivitas dihapus");
            }
          }}
          className="text-red-400 hover:text-red-500 h-7 text-xs"
        >
          <Trash2 className="h-3 w-3 mr-1" />
          Hapus Log
        </Button>
      </div>
      <div className="space-y-1.5 max-h-96 overflow-y-auto">
        {logs.map((log) => {
          const IconConfig = ICONS[log.type] ?? { icon: Eye, color: "text-muted-foreground" };
          const Icon = IconConfig.icon;
          return (
            <Card key={log.id} className="glass p-2.5 border-border/50 flex items-start gap-2">
              <Icon className={cn("h-3.5 w-3.5 mt-0.5 shrink-0", IconConfig.color)} />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate">{log.description}</p>
                <p className="text-[10px] text-muted-foreground">
                  {new Date(log.timestamp).toLocaleString("id-ID")}
                </p>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
