"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  type Settings,
} from "@/lib/types";
import {
  supabaseSignUp,
  supabaseSignIn,
  supabaseTestConnection,
  supabaseSmartSync,
  supabaseSignOut,
  supabaseDeleteAccount,
  getStoredSession,
  type SupabaseConfig,
  type SupabaseSession,
} from "@/lib/supabase-sync";
import type { AppData } from "@/lib/types";
import {
  Cloud,
  Mail,
  Lock,
  LogIn,
  UserPlus,
  LogOut,
  Loader2,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  X,
  Trash2,
  ShieldAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface SupabaseAuthProps {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  settings: Settings;
  data: AppData;
  onUpdateSettings: (s: Settings) => void;
  onSyncComplete: (mergedData: AppData) => void;
}

export function SupabaseAuthDialog({
  open,
  onOpenChange,
  settings,
  data,
  onUpdateSettings,
  onSyncComplete,
}: SupabaseAuthProps) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState(settings.syncEmail ?? "");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState("");
  // [v9.0 fix] T-1.3: getStoredSession sekarang async (auto-refresh access_token) — track via state.
  const [session, setSession] = useState<SupabaseSession | null>(null);
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const s = await getStoredSession();
        if (mounted) setSession(s);
      } catch {
        if (mounted) setSession(null);
      }
    })();
    return () => { mounted = false; };
  }, [open]);

  const config: SupabaseConfig = {
    url: settings.supabaseUrl ?? "",
    anonKey: settings.supabaseAnonKey ?? "",
  };
  const isLoggedIn = !!session;

  async function handleAuth(action: "login" | "signup") {
    if (!config.url || !config.anonKey) {
      setError("Isi Supabase URL & Anon Key dulu di Cloud settings");
      return;
    }
    if (!email || !password) {
      setError("Email & password wajib diisi");
      return;
    }
    if (password.length < 6) {
      setError("Password minimal 6 karakter");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result =
        action === "login"
          ? await supabaseSignIn(config, email, password)
          : await supabaseSignUp(config, email, password);

      if (result.error) {
        setError(result.error);
        return;
      }
      if (result.session) {
        // [v9.0 fix] T-1.3: update local state langsung supaya UI langsung switch ke logged-in view,
        // tanpa harus toggle open/close dialog untuk re-trigger useEffect getStoredSession.
        setSession(result.session);
        // Save settings
        onUpdateSettings({
          ...settings,
          syncEnabled: true,
          syncEmail: email,
          lastSyncAt: new Date().toISOString(),
        });
        toast.success(
          action === "login"
            ? "Berhasil login! Sync aktif."
            : "Akun dibuat! Sync aktif."
        );
        // Auto-sync pertama kali
        await handleSync();
      }
    } catch (e: any) {
      setError(e?.message ?? "Gagal");
    } finally {
      setLoading(false);
    }
  }

  async function handleSync() {
    if (!isLoggedIn) return;
    setSyncing(true);
    setError("");
    try {
      const result = await supabaseSmartSync(config, data);
      if (!result.success) {
        setError(result.error ?? "Sync gagal");
        toast.error("Sync gagal");
        return;
      }
      if (result.mergedData) {
        onSyncComplete(result.mergedData);
      }
      onUpdateSettings({
        ...settings,
        lastSyncAt: new Date().toISOString(),
      });
      toast.success("Sync berhasil! Data terbaru.");
    } catch (e: any) {
      setError(e?.message ?? "Sync gagal");
    } finally {
      setSyncing(false);
    }
  }

  async function handleLogout() {
    // v8.1: konfirmasi sebelum logout
    // [v9.0 fix] H3: wrap confirm() dalam try/catch untuk WebView Capacitor / browser yang block dialog.
    let confirmed = true;
    try {
      confirmed = confirm("Logout dari sync? Data lokal tetap aman, tapi sync dimatikan.");
    } catch {
      confirmed = true; // default lanjut kalau confirm() diblokir
    }
    if (!confirmed) return;
    await supabaseSignOut(config);
    // [v9.0 fix] T-1.3: clear local session state supaya UI switch ke login view
    setSession(null);
    onUpdateSettings({
      ...settings,
      syncEnabled: false,
      syncEmail: undefined,
      lastSyncAt: undefined,
    });
    toast.success("Logout berhasil. Sync dimatikan.");
  }

  async function handleDeleteAccount() {
    // [v9.0 fix] H3: wrap confirm() untuk WebView/Capacitor compat.
    let confirmed = false;
    try {
      confirmed = confirm(
        "⚠️ PERHATIAN!\n\nAnda akan menghapus AKUN & SEMUA DATA di cloud Supabase permanen.\n\nData lokal di HP ini TIDAK akan dihapus.\n\nTindakan ini TIDAK BISA DIBATALKAN.\n\nLanjutkan?"
      );
    } catch {
      confirmed = false;
    }
    if (!confirmed) {
      return;
    }
    setLoading(true);
    try {
      const result = await supabaseDeleteAccount(config);
      if (!result.success) {
        toast.error(result.error ?? "Gagal hapus akun");
        return;
      }
      // [v9.0 fix] T-1.7: clear local session state (supabaseDeleteAccount juga sudah panggil /auth/v1/logout + clearSession)
      setSession(null);
      onUpdateSettings({
        ...settings,
        syncEnabled: false,
        syncEmail: undefined,
        lastSyncAt: undefined,
      });
      toast.success("Akun & data cloud berhasil dihapus permanen.");
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message ?? "Gagal");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px] glass-strong border-0">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Cloud className="h-5 w-5 text-gold" />
            {isLoggedIn ? "Sync Aktif" : "Login Sync Supabase"}
          </DialogTitle>
          <DialogDescription>
            {isLoggedIn
              ? `Login sebagai ${session?.user?.email ?? "user"}`
              : "Buat akun atau login untuk sync data antar HP"}
          </DialogDescription>
        </DialogHeader>

        {isLoggedIn ? (
          // === Logged in view ===
          <div className="space-y-3">
            <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/30 p-3">
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span className="text-sm font-semibold text-emerald-400">
                  Sync Aktif
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                Email: <span className="font-medium text-foreground">{session?.user?.email}</span>
              </p>
              {settings.lastSyncAt && (
                <p className="text-xs text-muted-foreground mt-0.5">
                  Last sync:{" "}
                  <span className="font-medium text-foreground">
                    {new Date(settings.lastSyncAt).toLocaleString("id-ID")}
                  </span>
                </p>
              )}
            </div>

            <Button
              onClick={handleSync}
              disabled={syncing}
              className="w-full h-11 gradient-gold text-primary-foreground border-0"
            >
              {syncing ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-1" />
              )}
              {syncing ? "Syncing..." : "Sync Sekarang"}
            </Button>

            <Button
              variant="outline"
              onClick={handleLogout}
              className="w-full h-10 border-border/50 text-red-400 hover:text-red-500"
            >
              <LogOut className="h-4 w-4 mr-1" />
              Logout
            </Button>

            {/* Tombol Hapus Akun & Data - WAJIB untuk Google Play compliance */}
            <div className="border-t border-border/30 pt-2 mt-2 space-y-2">
              <p className="text-[10px] text-muted-foreground">
                <ShieldAlert className="h-3 w-3 inline mr-1" />
                Zona Berbahaya
              </p>
              <Button
                onClick={handleDeleteAccount}
                disabled={loading}
                variant="outline"
                className="w-full h-9 border-red-500/40 text-red-400 hover:text-red-500 hover:bg-red-500/10 text-xs"
              >
                <Trash2 className="h-3.5 w-3.5 mr-1" />
                Hapus Akun & Data Cloud
              </Button>
              <p className="text-[10px] text-muted-foreground text-center">
                Menghapus akun & seluruh data di Supabase permanen. Data di HP tetap aman.
              </p>
            </div>

            <p className="text-[11px] text-muted-foreground text-center">
              💡 Sync otomatis terjadi tiap kali ada perubahan data (auto-push).
            </p>
          </div>
        ) : (
          // === Login/Signup view ===
          <div className="space-y-3">
            {error && (
              <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-2.5 text-xs text-red-400">
                <AlertCircle className="h-3.5 w-3.5 inline mr-1" />
                {error}
              </div>
            )}

            {/* Mode toggle */}
            <div className="flex gap-1 rounded-lg bg-muted/40 p-1">
              <button
                onClick={() => {
                  setMode("login");
                  setError("");
                }}
                className={cn(
                  "flex-1 rounded-md py-1.5 text-xs font-semibold transition-colors",
                  mode === "login"
                    ? "gradient-gold text-primary-foreground"
                    : "text-muted-foreground"
                )}
              >
                <LogIn className="h-3.5 w-3.5 inline mr-1" />
                Login
              </button>
              <button
                onClick={() => {
                  setMode("signup");
                  setError("");
                }}
                className={cn(
                  "flex-1 rounded-md py-1.5 text-xs font-semibold transition-colors",
                  mode === "signup"
                    ? "gradient-gold text-primary-foreground"
                    : "text-muted-foreground"
                )}
              >
                <UserPlus className="h-3.5 w-3.5 inline mr-1" />
                Daftar Baru
              </button>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="sync-email" className="text-xs">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="sync-email"
                  type="email"
                  placeholder="email@contoh.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-9 bg-input/50 border-border/50"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="sync-password" className="text-xs">Password (min 6 karakter)</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  id="sync-password"
                  type="password"
                  placeholder="••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleAuth(mode);
                  }}
                  className="pl-9 bg-input/50 border-border/50"
                />
              </div>
            </div>

            <Button
              onClick={() => handleAuth(mode)}
              disabled={loading || !email || !password}
              className="w-full h-11 gradient-gold text-primary-foreground border-0"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 mr-1 animate-spin" />
              ) : mode === "login" ? (
                <LogIn className="h-4 w-4 mr-1" />
              ) : (
                <UserPlus className="h-4 w-4 mr-1" />
              )}
              {loading
                ? "Memproses..."
                : mode === "login"
                ? "Login & Sync"
                : "Daftar & Sync"}
            </Button>

            <p className="text-[11px] text-muted-foreground text-center">
              {mode === "signup"
                ? "💡 Akun baru dibuat di Supabase. Gunakan email yang sama di HP lain untuk sync."
                : "💡 Belum punya akun? Tap 'Daftar Baru' untuk membuat."}
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
