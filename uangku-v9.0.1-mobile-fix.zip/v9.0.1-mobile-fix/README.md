# UangkuPro v8.1

Aplikasi pencatat keuangan personal **offline-first** untuk pengguna Indonesia.
Dibangun dengan Next.js 16 + React 19 + Tailwind CSS 4 + shadcn/ui + Capacitor 8 (Android APK).

## Apa yang baru di v8.1

Versi v8.1 menyelesaikan **7 fitur setengah jadi** dari v8.0 + upgrade algoritma + sync Supabase granular. Lihat [CHANGELOG.md](./CHANGELOG.md) untuk detail lengkap.

### Fitur yang baru selesai (sebelumnya setengah jadi)

1. **Theme Picker (5 tema)** — Navy-Gold, Bank Pro, Green Eco, Pink Pastel, Black Cyan. Aktif di Settings → Cloud & Sync → bawah.
2. **Activity Log / Audit Trail** — semua aksi (buka app, tambah/edit/hapus transaksi, sync, backup, settings change) tercatat otomatis. Lihat di Settings → Keamanan.
3. **Encrypted Backup (AES-GCM)** — ganti XOR cipher dengan Web Crypto AES-GCM 256-bit + PBKDF2-SHA256 (150.000 iterasi). UI: Settings → Cloud → "Buat Backup .enc".
4. **Privacy Blur Mode** — sembunyikan nominal saat screenshot/screen recording. Toggle: Settings → Keamanan → "Mode Privacy".
5. **Large Tx Confirmation** — konfirmasi 2× untuk transaksi ≥ Rp 1jt (threshold dapat diatur). Toggle: Settings → Keamanan.
6. **Receipt Scanner OCR** — foto struk → AI ekstrak merchant, tanggal, total, items, kategori. Pakai z-ai-web-dev-sdk VLM (glm-4.6v). Tersedia di form Tambah Transaksi.
7. **Google Drive Backup** — OAuth flow + upload otomatis ke folder "Uangku Pro" di Drive. Aktif: Settings → Cloud → "Aktifkan & Backup Sekarang".

### Upgrade algoritma & infrastruktur

- **PIN Aplikasi**: hash 32-bit (`simpleHash`) diganti dengan PBKDF2-SHA256 (150.000 iterasi).
- **Auto-Categorize v2**: Bayesian-flavored keyword matching + learning dari koreksi user (cache localStorage, rebuild dari history saat import).
- **Multi-Currency Live Rate**: fetch rate dari `open.er-api.com` setiap 24 jam (cache localStorage), fallback ke rate statik default.
- **Health Score v2**: 7 komponen (5 lama + 2 baru: Debt-to-Income + Emergency Fund Months). Bobot di-rerata supaya tetap 0–100.
- **Supabase Sync Granular**: per-collection merge dengan last-write-wins per item + soft-delete (30 hari) + backward-compat dengan schema v1.
- **Storage Capacitor Preferences**: migrasi dari localStorage ke `@capacitor/preferences` bila tersedia (lebih stabil di Android WebView), dengan fallback ke localStorage untuk PWA.
- **Bug fix Neraca**: `computeBalanceSheet` sekarang memetakan wallet type ke sub-akun aset yang benar (cash → 1-1001, bank → 1-1002, e-wallet → 1-1003, investment → 1-1400). Sebelumnya keduanya lookup `1-1000`.

## Quick Start

### Development

```bash
npm install
npm run dev
# buka http://localhost:3000
```

### Build Capacitor APK

```bash
npm run build          # static export ke folder ./out
npx cap sync android   # sync web assets ke android project
cd android && ./gradlew assembleDebug
# APK ada di android/app/build/outputs/apk/debug/
```

Untuk build release (signed APK / AAB untuk Play Store), set env vars berikut sebelum `./gradlew assembleRelease`:

```bash
export RELEASE_STORE_FILE=/path/to/keystore.jks
export RELEASE_STORE_PASSWORD=********
export RELEASE_KEY_ALIAS=uangkupro
export RELEASE_KEY_PASSWORD=********
cd android && ./gradlew assembleRelease
# APK ada di android/app/build/outputs/apk/release/
```

[v9.0 fix] `android/app/build.gradle` sekarang secara kondisional menambahkan `signingConfigs.release` hanya jika keempat env vars di atas terisi. Tanpa env vars, release build akan unsigned (debug-signed fallback) — berguna untuk CI build test tetapi tidak publishable ke Play Store.

### Android Maintenance (LOW)

[v9.0] Folder `android/app/src/main/res/` saat ini berisi banyak file aset splash & launcher hasil scaffolding `npx cap add android` yang belum diverifikasi apakah benar-benar dipakai:

- `drawable-land-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/splash.png` — splash lanskap (jarang dipakai di app portrait-only UangkuPro).
- `drawable-port-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/splash.png` — splash portrait.
- `drawable/splash.png` + `drawable/ic_launcher_background.xml` — fallback default.
- `mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/{ic_launcher.png,ic_launcher_round.png,ic_launcher_foreground.png}` — launcher icons per-density.
- `mipmap-anydpi-v26/{ic_launcher.xml,ic_launcher_round.xml}` — adaptive icon definitions.

**Cleanup recommended (LOW priority)**:

1. Verifikasi splash mana yang benar-benar dipakai oleh `Theme.SplashScreen` di `styles.xml` (lihat `android:background="@drawable/splash"`). Hapus folder density yang tidak ter-render di target device.
2. Replace launcher icon dengan asset UangkuPro brand (lihat `ic_launcher_background.xml` — saat ini default Capacitor blue). Gunakan Android Studio Image Asset wizard (`res` → right-click → New → Image Asset) untuk generate ulang semua density dari satu SVG/PNG.
3. Setelah cleanup, jalankan `./gradlew assembleDebug` untuk memastikan tidak ada broken resource reference.

**Catatan**: Jangan hapus `values/colors.xml`, `values/styles.xml`, `values/strings.xml`, atau `values/ic_launcher_background.xml` — semua direferensikan oleh manifest/styles.

### Enable OCR (opsional, butuh Next.js server)

OCR membutuhkan `z-ai-web-dev-sdk` yang hanya jalan di server-side. Karena project ini pakai `output: "export"` (static export untuk Capacitor), API route tidak di-build.

Untuk enable OCR:

1. Copy file `ocr-server/route.ts` ke `src/app/api/ocr-receipt/route.ts`
2. Hapus `output: "export"` dari `next.config.ts`
3. Set env var wajib sebelum `npm run build` / `npm run start`:
   - `ZAI_API_KEY` — kunci z-ai-web-dev-sdk (sudah ada di v8.x)
   - `UANGKU_OCR_TOKEN` — **[v9.0 fix]** shared secret untuk header `x-uangku-token` pada setiap request ke `/api/ocr-receipt`. Client (hook `useOCRReceipt`) harus mengirim header yang sama nilainya, jika tidak endpoint merespons **401 Unauthorized**. Tanpa token ini, endpoint publik dapat diakses siapa pun dan menguras tagihan ZAI (audit OCR-01).
4. Build dengan `npm run build` lalu jalankan dengan `npm run start`
5. Hook `useOCRReceipt` otomatis akan memanggil `/api/ocr-receipt` dan dapat response

> **Rate limit (v9.0):** endpoint membatasi 1 request per 5 detik per IP (audit OCR-02). Untuk production disarankan migrasi ke Redis-backed ratelimit (`@upstash/ratelimit`).

Tanpa langkah di atas, hook akan menampilkan pesan informatif "OCR tidak tersedia di hosting ini" — form tetap berfungsi normal dengan input manual.

> **Catatan APK (v9.0):** Pengguna APK Capacitor akan melihat pesan "OCR belum tersedia di APK. Hubungi developer untuk setup server OCR." karena APK tidak menyertakan server Next.js (audit OCR-04). Untuk mengaktifkan OCR di APK, deploy server publik terpisah dan set base URL fetch ke server tersebut.

## Setup Eksternal (opsional)

### Supabase Sync (gratis)

1. Buat akun di https://supabase.com (free tier 500MB cukup)
2. Buat project baru, catat **Project URL** dan **anon key**
3. Jalankan SQL berikut di SQL Editor:

```sql
-- Legacy single-row table (v8.0 schema)
CREATE TABLE IF NOT EXISTS user_data (
  id text PRIMARY KEY,
  user_id text NOT NULL,
  data jsonb NOT NULL,
  updated_at timestamptz DEFAULT now()
);

-- v8.1 granular tables (otomatis dipakai bila ada)
CREATE TABLE IF NOT EXISTS user_data_meta (
  id text PRIMARY KEY,
  user_id text NOT NULL,
  settings jsonb NOT NULL,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_data_items (
  user_id text NOT NULL,
  collection text NOT NULL,
  items jsonb NOT NULL,
  updated_at timestamptz DEFAULT now(),
  PRIMARY KEY (user_id, collection)
);

-- RLS policies (per-user only)
ALTER TABLE user_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_data_meta ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_data_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user_data_self" ON user_data
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);
CREATE POLICY "user_data_meta_self" ON user_data_meta
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);
CREATE POLICY "user_data_items_self" ON user_data_items
  FOR ALL USING (auth.uid()::text = user_id) WITH CHECK (auth.uid()::text = user_id);
```

4. Di aplikasi: Settings → Cloud → isi URL + anon key → Test → Login/Daftar

### Google Drive Backup

1. Buka https://console.cloud.google.com/apis/credentials
2. Buat OAuth 2.0 Client ID (type: Web application)
3. Authorized JavaScript origins: domain aplikasi (mis. `http://localhost:3000` untuk dev)
4. Authorized redirect URIs: `http://localhost:3000/` (root)
5. Copy Client ID, paste di Settings → Cloud → Google OAuth Client ID

## Stack Teknologi

- **Frontend**: Next.js 16 (App Router, Turbopack), React 19, TypeScript 5
- **UI**: Tailwind CSS 4, shadcn/ui (Radix UI), lucide-react icons, Recharts, framer-motion
- **Mobile**: Capacitor 8 (Android), @capacitor/preferences, @capacitor/filesystem
- **Data**: localStorage (fallback) / Capacitor Preferences (native)
- **Cloud**: Supabase (REST API langsung, no SDK), Google Drive (OAuth 2.0 implicit)
- **Excel/PDF**: ExcelJS, jsPDF, jspdf-autotable, file-saver
- **AI**: z-ai-web-dev-sdk VLM (glm-4.6v) untuk OCR struk
- **Security**: Web Crypto API (AES-GCM, PBKDF2, SHA-256), WebAuthn (Platform Authenticator)

## Lisensi

Personal use. Lihat file LICENSE jika ada.
