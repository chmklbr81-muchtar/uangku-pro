package com.uangkupro.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
