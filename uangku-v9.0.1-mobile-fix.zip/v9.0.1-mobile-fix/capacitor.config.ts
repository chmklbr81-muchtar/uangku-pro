import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.uangkupro.app",
  appName: "Uangku Pro",
  webDir: "out",
  // Server config: pakai https scheme supaya localStorage & Service Worker jalan
  server: {
    androidScheme: "https",
    cleartext: false,
  },
  android: {
    allowMixedContent: false,
    // Enable web contents debugging saat development (matikan untuk production)
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    // Preferences: untuk simpan data persisten (lebih stabil dari localStorage di WebView)
    Preferences: {
      group: "uangku-pro",
    },
  },
  // Tidak pakai static server - aset ter-bundle di dalam APK (offline)
};

export default config;
