// [v9.0] File ini adalah reference implementation. Untuk enable OCR:
// copy ke src/app/api/ocr-receipt/route.ts dan hapus output: "export" dari next.config.ts.
// Lihat README bagian "Enable OCR".
//
// API route OCR struk menggunakan z-ai-web-dev-sdk VLM (glm-4.6v)
// POST /api/ocr-receipt
// Body: { image: "data:image/...;base64,...." }
// Response: { data: OCRResult }
//
// OCRResult format sama dengan src/hooks/use-ocr.ts:
//   { date?, merchant?, total?, items?, category?, confidence?, notes? }
//
// VLM approach: kirim gambar struk + prompt terstruktur, minta JSON-only response.
// Parsing dilakukan dengan regex/JSON.parse, dengan fallback heuristic jika model tidak kembalikan JSON valid.

import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// [v9.0 fix] Simple IP-based rate limit 5s/request (untuk production pakai Redis)
const rateLimit = new Map<string, number>();

interface OCRResult {
  date?: string;
  merchant?: string;
  total?: number;
  items?: { name: string; price: number; qty?: number }[];
  category?: string;
  confidence?: "high" | "medium" | "low";
  notes?: string;
}

const PROMPT = `Anda adalah parser struk belanja. Analisis gambar struk/nota ini dan ekstrak informasi berikut.
Kembalikan HANYA JSON valid tanpa markdown, tanpa teks tambahan, dengan format persis:

{
  "merchant": "nama toko/merchant",
  "date": "YYYY-MM-DD",
  "total": 12345,
  "items": [{"name": "nama item", "price": 5000, "qty": 2}],
  "category": "makanan|transportasi|belanja|tagihan|hiburan|kesehatan|pendidikan|sewa|asuransi|donasi|admin|lainnya",
  "confidence": "high|medium|low",
  "notes": "catatan tambahan jika ada"
}

Aturan:
1. "date": format YYYY-MM-DD. Jika tidak ada tanggal, hilangkan field.
2. "total": angka bulat tanpa pemisah ribuan, tanpa "Rp" atau ".00". Jika tidak ada total, hilangkan.
3. "items": array dari item, masing-masing dengan name, price (angka), dan qty (opsional). Jika tidak terbaca, kembalikan array kosong.
4. "category": pilih satu dari daftar di atas yang paling sesuai dengan merchant/item.
5. "confidence": "high" jika struk jelas terbaca, "medium" jika sebagian kabur, "low" jika sangat sulit.
6. Jika bukan struk/nota (misal foto landscape atau dokumen lain), kembalikan {"confidence":"low","notes":"Gambar bukan struk"}.
7. JANGAN sertakan markdown atau teks di luar JSON.`;

export async function POST(req: NextRequest) {
  try {
    // [v9.0 fix] Require shared secret token UANGKU_OCR_TOKEN untuk akses endpoint
    const authHeader = req.headers.get("x-uangku-token");
    if (!authHeader || authHeader !== process.env.UANGKU_OCR_TOKEN) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // [v9.0 fix] Simple IP-based rate limit 5s/request (untuk production pakai Redis)
    const ip = req.headers.get("x-forwarded-for") ?? "unknown";
    const last = rateLimit.get(ip) ?? 0;
    if (Date.now() - last < 5000) {
      return NextResponse.json(
        { error: "Rate limit: 1 request per 5 seconds" },
        { status: 429 }
      );
    }
    rateLimit.set(ip, Date.now());

    const body = await req.json();
    const image = body?.image as string | undefined;
    if (!image || !image.startsWith("data:image/")) {
      return NextResponse.json(
        { error: "Image base64 data URL required" },
        { status: 400 }
      );
    }

    const zai = await ZAI.create();
    const messages = [
      {
        role: "user" as const,
        content: [
          { type: "text" as const, text: PROMPT },
          { type: "image_url" as const, image_url: { url: image } },
        ],
      },
    ];

    const response = await zai.chat.completions.createVision({
      model: "glm-4.6v",
      messages: messages as any,
      thinking: { type: "disabled" as const },
    });

    const reply = response.choices?.[0]?.message?.content ?? "";

    // Try to extract JSON from reply (model might wrap in ```json or not)
    let parsed: OCRResult = {};
    const jsonMatch = reply.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      try {
        parsed = JSON.parse(jsonMatch[0]);
      } catch {
        // If parse fails, fall through to heuristic
      }
    }
    // [v9.0 fix] OCR-15: Dead-code branch — gunakan validasi field konkret, bukan Object.keys
    if (!parsed || (!parsed.merchant && !parsed.total && !parsed.items)) {
      // Heuristic fallback: try to extract date, total, merchant from raw text
      parsed = heuristicParse(reply);
    }

    return NextResponse.json({ data: parsed });
  } catch (err: any) {
    console.error("OCR API error:", err?.message ?? err);
    return NextResponse.json(
      { error: err?.message ?? "OCR failed" },
      { status: 500 }
    );
  }
}

// Heuristic fallback parser (jika model tidak kembalikan JSON)
function heuristicParse(text: string): OCRResult {
  const result: OCRResult = { confidence: "low" };
  // Try date
  const dateMatch = text.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
  if (dateMatch) {
    const [, d, m, y] = dateMatch;
    const year = y.length === 2 ? `20${y}` : y;
    const mm = m.padStart(2, "0");
    const dd = d.padStart(2, "0");
    result.date = `${year}-${mm}-${dd}`;
  }
  // Try total (look for "TOTAL Rp 12.345" or "TOTAL 12.345")
  const totalMatch = text.match(/(?:total|grand total|jumlah)[^0-9]*([\d.,]+)/i);
  if (totalMatch) {
    const cleaned = totalMatch[1].replace(/[.,]/g, "");
    const num = parseInt(cleaned, 10);
    if (!isNaN(num)) result.total = num;
  }
  return result;
}
