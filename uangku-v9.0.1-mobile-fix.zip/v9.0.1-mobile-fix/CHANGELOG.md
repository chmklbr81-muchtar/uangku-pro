# Changelog

Semua perubahan penting di project UangkuPro didokumentasikan di file ini.

Format berbasis [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
versi mengikuti [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v8.1] — 2026-11-04

Versi ini fokus pada **penyelesaian 7 fitur setengah jadi** dari v8.0 + **upgrade algoritma** + **sync Supabase granular** + **migrasi storage**. Total ~2.000+ baris kode ditulis ulang atau dimodifikasi. Build lolos type-check (`tsc --noEmit`) dan `next build` sukses dengan static export.

### Added — Fitur Setengah Jadi yang Diselesaikan

#### 1. Theme Picker (5 Tema Visual)
- Komponen `ThemePicker` sebelumnya tidak dirender di mana pun. Sekarang di-wire ke `CloudSettingsPanel`.
- 5 tema dengan CSS variables: `navy-gold` (default), `bank-pro`, `green-eco`, `pink-pastel`, `black-cyan`.
- Class `theme-{id}` diaplikasikan ke `<html>` lewat useEffect saat `settings.themeChoice` berubah.
- File: `src/app/globals.css` (CSS theme variants), `src/components/finance/theme-picker.tsx`, `src/components/finance/settings-panels.tsx`, `src/app/page.tsx`.

#### 2. Activity Log / Audit Trail
- Helper `addActivityLog()` dan `logActivity()` sebelumnya tidak pernah dipanggil. Sekarang di-wire ke semua aksi:
  - `app_open` — saat aplikasi dibuka
  - `tx_add`, `tx_edit`, `tx_delete` — saat transaksi disimpan/dihapus
  - `backup_restore` — saat restore dari JSON/encrypted backup atau import eksternal
  - `settings_change` — saat user ubah setting yang ter-track
- `ActivityLogViewer` di-render di `SecuritySettingsPanel`.
- Maks 200 entry, FIFO.
- File: `src/lib/security-utils.ts`, `src/app/page.tsx`, `src/components/finance/settings-panels.tsx`, `src/components/finance/activity-log-viewer.tsx`.

#### 3. Encrypted Backup (AES-GCM)
- Sebelumnya XOR cipher 1-byte keystream (lemah). Sekarang **AES-GCM 256-bit** via Web Crypto API.
- Format V2: `UANGKU-ENC-V2\n<salt_hex>:<iv_hex>:<base64_ciphertext>`.
- Key derivation: PBKDF2-SHA256, 150.000 iterasi, 16-byte salt random per backup.
- Backward-compat: tetap bisa restore backup V1 (XOR) lama.
- UI: 2 dialog baru di CloudSettingsPanel — "Buat Backup .enc" dan "Restore .enc".
- File: `src/lib/security-utils.ts` (full rewrite), `src/components/finance/settings-panels.tsx`.

#### 4. Privacy Blur Mode
- Helper `togglePrivacyBlur()` sebelumnya tidak dipanggil. Sekarang:
  - Toggle UI di SecuritySettingsPanel.
  - useEffect di `page.tsx` apply class `privacy-blur` ke `<body>` saat `settings.privacyBlurMode === true`.
  - CSS rule `.privacy-blur [data-amount]` apply `filter: blur(7px)` ke nominal. Hover (desktop) untuk reveal.
- File: `src/app/globals.css`, `src/lib/security-utils.ts`, `src/components/finance/settings-panels.tsx`, `src/app/page.tsx`.

#### 5. Large Transaction Confirmation
- Helper `shouldConfirmLargeTx()` sebelumnya tidak dipanggil. Sekarang:
  - Toggle UI di SecuritySettingsPanel dengan threshold default Rp 1.000.000 (dapat diubah).
  - Di `handleSaveTx` page.tsx: cek dulu, kalau lewat threshold tampilkan `confirm()` dialog sebelum simpan.
- File: `src/lib/security-utils.ts`, `src/components/finance/settings-panels.tsx`, `src/app/page.tsx`.

#### 6. Receipt Scanner OCR (VLM)
- Sebelumnya: hook `use-ocr.ts` memanggil `/api/ocr-receipt` yang tidak ada → selalu fallback error.
- Sekarang: API route baru pakai `z-ai-web-dev-sdk` VLM model `glm-4.6v`.
- Prompt terstruktur minta JSON-only response dengan field: `merchant, date, total, items[], category, confidence, notes`.
- Heuristic fallback parser bila model tidak kembalikan JSON valid.
- Hook `useOCRReceipt` di-rewrite dengan error handling yang lebih informatif.
- `ReceiptScanner` komponen di-render di `AddTransactionDialog` (form tambah transaksi).
- Handler `handleScanResult` apply hasil scan ke form (amount, date, note + trigger auto-categorize).
- **Catatan deployment**: API route tidak bisa di-build dengan `output: "export"` (Capacitor static). File route dipindah ke `ocr-server/route.ts` sebagai reference; user perlu mode `next start` untuk enable. Lihat README.
- File: `ocr-server/route.ts`, `src/hooks/use-ocr.ts`, `src/components/finance/receipt-scanner.tsx`, `src/components/finance/add-transaction-dialog.tsx`.

#### 7. Google Drive Backup (end-to-end)
- Sebelumnya: `setupGDrive()` hanya redirect ke OAuth, tapi `parseTokenFromUrl()` dan `backupToGDrive()` tidak pernah dipanggil.
- Sekarang: `useEffect` di `CloudSettingsPanel` auto-capture token dari URL hash setelah redirect, lalu panggil `backupToGDrive(data, token)` yang sudah lengkap (search-or-create folder, multipart upload, update existing file).
- Tombol berubah dari "Aktifkan & Login Google" → "Aktifkan & Backup Sekarang" (label lebih akurat).
- `lastBackupAt` di-settings di-update setelah sukses.
- File: `src/components/finance/settings-panels.tsx`, `src/lib/gdrive.ts` (tidak berubah, sudah benar).

### Added — Upgrade Algoritma

#### Auto-Categorize v2 (Bayesian + Learning)
- v8.0: pure keyword length scoring.
- v8.1: weighted keyword scoring (multi-word/brand terms dapat bobot 1.5×) + learned prior dari history transaksi user.
- 2 fungsi baru:
  - `learnFromTransaction(tx)` — panggil setiap kali transaksi disimpan, update stats.
  - `rebuildLearningFromHistory(transactions)` — rebuild stats dari seluruh history (dipanggil saat import).
- Storage: localStorage key `uangku.autoCat.learn`, cap 1000 entries.
- Threshold suggestion: score ≥ 3 (sebelumnya bebas).
- Pure-learned fallback: bila tidak ada keyword match tapi ada learned prior untuk prefix note, pakai prior.
- File: `src/lib/auto-categorize.ts` (full rewrite).

#### Multi-Currency Live Rate
- v8.0: rate statik di-hardcode (`DEFAULT_RATES`).
- v8.1: tambah `fetchLiveRates()` yang ambil dari `https://open.er-api.com/v6/latest/IDR` (gratis, no API key).
- Cache di localStorage 24 jam (key `uangku.rates.cache.v2`).
- Fallback otomatis ke `DEFAULT_RATES` bila fetch gagal/cache stale.
- Helper baru: `getEffectiveRate(currency)` — custom rate > live cache > default.
- Helper baru: `getRateCacheInfo()` — info timestamp + stale status.
- File: `src/lib/multi-currency.ts` (full rewrite).

#### Health Score v2 (7 Komponen)
- v8.0: 5 komponen (savingsRate, emergencyFund, debtRatio, expenseStability, consistency). Bobot: 30/25/20/15/10.
- v8.1: 7 komponen. Bobot baru (sum=100):
  - savingsRate 22% (was 30%)
  - emergencyFund 20% (was 25%)
  - debtRatio 14% (was 20%) — asset-debt ratio
  - **debtToIncome 10% (NEW)** — monthly debt service / monthly income, target <36% per Bank Indonesia
  - expenseStability 13% (was 15%)
  - consistency 11% (was 10%)
  - **emergencyMonths 10% (NEW)** — emergency fund dalam bulan pengeluaran, target 3–6 bulan
- Interface `HealthScore` extend dengan field `metrics` berisi 8 metrik detail (savingsRatePct, emergencyFundRatio, emergencyFundMonths, debtToIncomePct, monthlyDebtService, monthlyIncome, monthlyExpense, totalDebt).
- Insight messages baru untuk emergency months & debt-to-income.
- UI `HealthScoreView` di-update untuk render 7 bars + grid 8 metrik.
- File: `src/lib/finance-analytics.ts` (rewrite computeHealthScore), `src/components/finance/analytics-dashboard.tsx`.

#### PIN Hashing Upgrade (PBKDF2-SHA256)
- v8.0: `simpleHash()` 32-bit non-cryptographic.
- v8.1: `hashPin()` pakai PBKDF2-SHA256, 150.000 iterasi, 16-byte salt random per PIN.
- Format stored: `pbkdf2$<iterations>$<salt_hex>$<hash_hex>` (self-describing).
- `verifyPin()` async, backward-compat dengan `simpleHash()` lama (bisa unlock session lama).
- `unlockWithPin()` di `useBiometric` jadi async.
- `LockScreen.submitPin()` jadi async.
- File: `src/lib/security-utils.ts`, `src/hooks/use-biometric.ts`, `src/components/finance/lock-screen.tsx`, `src/components/finance/settings-panels.tsx`.

### Added — Supabase Sync Granular

- v8.0: single-row `user_data` table, "cloud wins" untuk konflik.
- v8.1: strategi per-collection merge dengan **last-write-wins per item** + **soft-delete 30 hari**.
- 2 tabel baru direkomendasikan (lihat README SQL):
  - `user_data_meta(id, user_id, settings jsonb, updated_at)`
  - `user_data_items(user_id, collection, items jsonb, updated_at)` dengan PK (user_id, collection)
- Sync flow:
  1. Pull tiap collection (`transactions, wallets, coa, budgets, savingsGoals, recurring, debts`).
  2. Merge per-item dengan LWW berdasarkan `updatedAt`.
  3. Soft-delete: item dengan `deletedAt` tetap di-sync untuk propagate deletion, di-purge setelah 30 hari.
  4. Push merged collections + settings.
  5. Return `conflictsResolved` count.
- Backward-compat: bila tabel granular belum ada (404), fallback ke `supabaseSmartSyncLegacy` (single-row).
- File: `src/lib/supabase-sync.ts` (full rewrite, +400 lines).

### Added — Storage Migration ke Capacitor Preferences

- v8.0: 100% localStorage.
- v8.1: prefer `@capacitor/preferences` bila tersedia (lebih stabil di Android WebView), fallback ke localStorage.
- API tetap sync (`loadData/saveData`) — Capacitor Preferences async di-cache in-memory + fire-and-forget persist.
- Auto-migrasi: saat Capacitor Preferences kosong tapi localStorage ada data, auto-move + clear localStorage.
- Custom event `uangku-storage-ready` di-dispatch setelah init async selesai, supaya UI bisa reload data fresh.
- File: `src/lib/storage.ts` (full rewrite).

### Fixed — Bug & Dead Code

#### Bug: `computeBalanceSheet` Cash vs Bank Lookup
- **Masalah**: baris 498-499 di `finance.ts` keduanya lookup `code === "1-1000"` (Kas & Setara Kas — parent account). `cashAccount` dan `bankAccount` jadi variabel yang sama.
- **Akibat**: saldo bank tidak terpetakan ke akun aset yang berbeda dari cash, neraca tidak balanced.
- **Fix**: sekarang pakai helper `resolveWalletAssetAccount(wallet.type)` yang memetakan:
  - `cash` → `1-1001` Kas Tunai
  - `bank_*` → `1-1002` Saldo Bank
  - `ewallet_*`, `qris` → `1-1003` E-Wallet
  - `investment` → `1-1400` Investasi
  - fallback → `1-1000` (legacy)
- File: `src/lib/finance.ts`.

#### Dead Code: `statistics.tsx` Imports Tidak Ada
- **Masalah**: komponen `statistics.tsx` mengimpor `getCategory`, `sumByCategory`, `sumByMonth`, `CHART_COLORS` dari `@/lib/finance` — semua tidak ada. Komponen orphaned (tidak dirender).
- **Fix**: rewrite komponen pakai helper yang ADA (`sumByCOA`, `getMonthlySeries`, `formatCompact`, dst). Tambah `CHART_COLORS` lokal. Komponen tetap optional (tidak dirender di app utama) tapi type-check lolos.
- File: `src/components/finance/statistics.tsx` (full rewrite).

#### Pre-existing Type Errors
- `calculator-input.tsx`: import `Multiply`, `Divide` dari lucide-react yang tidak ada → dihapus (tidak dipakai di JSX).
- `transactions-list.tsx`: import `getLeafAccounts` dari `@/lib/finance` yang tidak ada → pindah ke `@/lib/default-data` (lokasi sebenarnya).
- `dashboard.tsx`: import `type Summary` dari `@/lib/types` yang tidak ada → pindah ke `@/lib/finance` (lokasi sebenarnya).
- `debt-tracker.tsx`: line 593 passing `DebtLoan | null` ke fungsi yang expect `DebtLoan` → tambah null check.
- `excel-export.ts`: `interface ExportOptions` tidak di-export → tambah `export`.
- `page.tsx`: baris 85 `const [moreView, setMoreView] = useState<MoreView>("budget")` (syntax OK, render tool yang aneh).
- `page.tsx`: `setMoreView("x") || setTab("y")` pattern — `setMoreView` returns void, `||` test invalid → ubah ke block body `{ setMoreView("x"); setTab("y"); }`.

### Changed

- Footer `Uangku Pro v2.0` → `Uangku Pro v8.1 · PWA · Offline-first · AES-GCM + PBKDF2`.
- `SecuritySettingsPanel` label PIN: dari "Aktif — buka aplikasi dengan PIN 4-6 digit" → "Aktif — PBKDF2-SHA256 (150k iterasi)".
- `CloudSettingsPanel` tombol GDrive: dari "Aktifkan & Login Google" → "Aktifkan & Backup Sekarang" + loading spinner.

### Migration Guide (v8.0 → v8.1)

- **PIN**: PIN lama (simpleHash) tetap bisa unlock (backward-compat via `verifyPin`). Untuk upgrade ke PBKDF2, user perlu reset PIN di Settings → Keamanan → Matikan → Aktifkan kembali.
- **Encrypted backup**: Backup V1 (.enc hasil XOR) tetap bisa di-restore. Backup baru otomatis pakai V2 (AES-GCM).
- **Supabase**: Tidak perlu migrate schema. v8.1 backward-compat — akan pakai legacy single-row bila tabel granular belum dibuat. Untuk dapat fitur LWW + soft-delete, jalankan SQL tambahan di README (3 tabel baru).
- **Storage**: Tidak perlu action. Saat user pertama kali buka v8.1, Capacitor Preferences akan auto-migrate data dari localStorage (jika di Android).
- **Activity Log**: Mulai dari kosong. Entry baru akan terisi otomatis saat user melakukan aksi.

### Files Modified

**Library (8 files):**
- `src/lib/security-utils.ts` — full rewrite (AES-GCM, PBKDF2, hashPin, verifyPin)
- `src/lib/storage.ts` — full rewrite (Capacitor Preferences + fallback)
- `src/lib/supabase-sync.ts` — full rewrite (granular sync)
- `src/lib/auto-categorize.ts` — full rewrite (Bayesian + learning)
- `src/lib/multi-currency.ts` — full rewrite (live rate + cache)
- `src/lib/finance-analytics.ts` — Health Score v2 (7 komponen)
- `src/lib/finance.ts` — fix bug `computeBalanceSheet`
- `src/lib/excel-export.ts` — export `ExportOptions` interface

**Hooks (2 files):**
- `src/hooks/use-biometric.ts` — `unlockWithPin` jadi async (PBKDF2)
- `src/hooks/use-ocr.ts` — rewrite (better error handling, pakai API route)

**Components (5 files):**
- `src/components/finance/settings-panels.tsx` — full rewrite (ThemePicker, ActivityLog, PrivacyBlur, LargeTx, EncryptedBackup, GDriveBackup)
- `src/components/finance/lock-screen.tsx` — async PIN unlock
- `src/components/finance/add-transaction-dialog.tsx` — wire ReceiptScanner + handleScanResult
- `src/components/finance/analytics-dashboard.tsx` — HealthScoreView v2 (7 bars + 8 metrics)
- `src/components/finance/statistics.tsx` — rewrite dari dead code
- `src/components/finance/calculator-input.tsx` — fix import
- `src/components/finance/dashboard.tsx` — fix import
- `src/components/finance/transactions-list.tsx` — fix import
- `src/components/finance/debt-tracker.tsx` — fix null check

**App (2 files):**
- `src/app/page.tsx` — wire activity log, theme apply, privacy blur, encrypted restore, large tx confirm, storage-ready listener
- `src/app/globals.css` — tambah CSS theme variants + privacy blur rule

**New files:**
- `ocr-server/route.ts` — API route reference implementation (VLM OCR via z-ai-web-dev-sdk)
- `README.md` — setup guide lengkap (Supabase SQL, GDrive OAuth, OCR enable)
- `CHANGELOG.md` — file ini

### Build Verification

```bash
$ npx tsc --noEmit --skipLibCheck
# 0 errors

$ npx next build
# ✓ Compiled successfully in 12.2s
# ✓ Generating static pages (3/3) in 690ms
# Route (app)
# ┌ ○ /
# └ ○ /_not-found
```

## [v8.0] — 2026-11-03

Versi awal yang dianalisis. Memiliki 7 fitur setengah jadi (lihat laporan analisis sebelumnya).
