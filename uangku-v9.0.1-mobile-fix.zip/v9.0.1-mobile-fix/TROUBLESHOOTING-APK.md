# Troubleshooting APK — "This page couldn't load"

> Khusus untuk masalah APK tidak terbuka di Android, menampilkan error WebView "This page couldn't load".

## Root Cause (v9.0 → v9.0.1)

Setelah audit mendalam APK `UangkuPro_v9.0.apk` yang Anda kirim, ditemukan **3 konflik konfigurasi** yang menyebabkan WebView gagal load:

### 1. `trailingSlash: true` di `next.config.ts`

Next.js dengan `trailingSlash: true` generate struktur folder `/about/index.html` (bukan `/about.html`). **Capacitor WebView bermasalah** dengan URL ber-format `/xxx/` (folder) karena WebViewLocalServer tidak redirect dengan benar.

**Fix v9.0.1**: Hapus `trailingSlash: true`.

### 2. `assetPrefix: "./"` konflik dengan Capacitor scheme

`assetPrefix: "./"` mengubah URL asset menjadi relatif (`./_next/...`). Secara teori ini benar, tapi praktiknya di Capacitor WebView dengan `androidScheme: "https"`, kombinasi `./_next/...` + URL `https://localhost/` kadang resolve ke path yang salah.

**Fix v9.0.1**: Hapus `assetPrefix: "./"`. Capacitor WebViewLocalServer sudah intercept absolute path `/_next/...` dari `https://localhost/_next/...` dan serve dari `assets/public/_next/...` dengan benar.

### 3. Next.js 16 Turbopack runtime tidak kompatibel dengan WebView

Turbopack (default bundler Next.js 16) pakai `document.currentScript.getAttribute("src")` untuk derive asset suffix. Di Capacitor WebView, `currentScript` bisa `null` pada saat inline script di body dieksekusi, menyebabkan chunk loading gagal silently.

**Fix v9.0.1**: Force webpack via `next build --webpack` (lihat `package.json` script `build`). Turbopack tetap tersedia via `npm run build:turbo` untuk development.

---

## Build Ulang dengan v9.0.1

### Langkah Cepat (1 command)

```bash
cd uangku-v9.0.1-mobile-fix
npm install          # jika belum
npm run build:apk    # clean + build + cap sync + gradle assembleDebug
```

APK hasil ada di: `android/app/build/outputs/apk/debug/app-debug.apk`

### Langkah Manual (verbose, untuk debug)

```bash
# 1. Clean semua artifact lama
npm run clean
# atau manual: rm -rf out .next android/app/src/main/assets/public android/app/build

# 2. Build Next.js pakai webpack (BUKAN Turbopack)
npm run build
# verifikasi:
ls out/index.html   # harus ada
ls out/_next/static/chunks/  # harus ada file .js

# 3. Sync ke Android (WAJIB, jangan dilewati!)
npx cap sync android
# verifikasi:
ls android/app/src/main/assets/public/index.html  # harus ada

# 4. Build APK
cd android
./gradlew clean assembleDebug

# 5. Install ke HP
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## Verifikasi Build Sukses

Cek 4 hal ini setelah `npm run build:apk` selesai:

```bash
# 1. out/ folder ada isinya
ls out/ | wc -l     # harus > 10 file

# 2. _next/static/chunks/ pakai webpack (BUKAN turbopack)
ls out/_next/static/chunks/ | grep -E "webpack|main"
# harus ada file seperti: webpack-xxx.js, main-xxx.js, polyfills-xxx.js
# (Turbopack pakai nama file seperti: turbopack-xxx.js, 0xa--xxx.js — TIDAK ADA setelah fix)

# 3. index.html punya absolute paths (BUKAN ./relative)
head -1 out/index.html | grep -oE 'src="[^"]*"' | head -3
# harus: src="/_next/static/chunks/xxx.js" (diawali / bukan ./)

# 4. APK assets/public ter-copy
unzip -l android/app/build/outputs/apk/debug/app-debug.apk | grep "assets/public/index.html"
# harus: assets/public/index.html
```

---

## Kalau Masih Gagal Setelah v9.0.1

### Debug Step 1: Aktifkan WebView Debugging

Edit `capacitor.config.ts`, ubah `webContentsDebuggingEnabled` jadi `true`:

```ts
android: {
  allowMixedContent: false,
  webContentsDebuggingEnabled: true,  // ← ubah ke true
},
```

Build ulang APK, install, lalu di Chrome desktop buka:
```
chrome://inspect
```

Klik "Inspect" di bawah perangkat Anda. Lihat tab **Console** untuk error JavaScript yang sebenarnya.

### Debug Step 2: Coba scheme alternatif

Edit `capacitor.config.ts`, ganti scheme:

```ts
server: {
  // androidScheme: "https",  // default
  androidScheme: "capacitor",  // coba ini kalau https gagal
  cleartext: false,
},
```

`capacitor://` scheme adalah alternatif yang pakai protocol khusus Capacitor (tidak butuh HTTPS localhost server).

### Debug Step 3: Cek versi WebView Android

Beberapa HP lama punya WebView versi rendah yang tidak support ES2022 (yang dipakai Next.js 16).

Di HP: Settings → Apps → Android System WebView → cek versi. Minimal **Chromium 107+** (Oktober 2022).

Update WebView via Play Store kalau versinya lama.

### Debug Step 4: Test page di browser biasa dulu

```bash
cd out
python3 -m http.server 8080
# buka http://localhost:8080 di Chrome desktop
```

Kalau page blank/error di Chrome juga → masalahnya di kode Next.js, bukan Capacitor.
Kalau page jalan di Chrome tapi blank di APK → masalahnya di Capacitor config.

---

## Yang Berubah dari v9.0 → v9.0.1

| File | v9.0 | v9.0.1 |
|------|------|--------|
| `next.config.ts` | `trailingSlash: true, assetPrefix: "./"` | (dihapus) + `basePath: ""` |
| `package.json` build script | `next build` (Turbopack default) | `next build --webpack` |
| `package.json` build:apk script | (tidak ada) | `npm run clean && build && cap sync && gradle` |
| `package.json` clean script | (tidak ada) | hapus out/, .next/, assets/public, app/build |
| Version | 9.0.0 | 9.0.1 |

Semua fix v9.0 lainnya (security, sync, storage, analytics, export, UI, OCR, Android colors.xml, network_security_config) **tetap utuh** di v9.0.1. Hanya 3 konflik mobile yang diperbaiki.

---

## Pertanyaan Umum

**Q: Kenapa `trailingSlash: true` jadi masalah sekarang? v8.1 juga pakai setting ini dan jalan.**

A: v8.1 dipakai dengan Next.js yang lebih lama (mungkin webpack), dan `trailingSlash` tidak banyak efek. v9.0 pakai Next.js 16 + Turbopack default, di mana `trailingSlash` + Turbopack generate struktur yang tidak kompatibel dengan WebView.

**Q: Apa efek samping hapus `trailingSlash: true`?**

A: URL menjadi `/about` bukan `/about/`. Untuk APK statis tidak ada efek (tidak ada routing dinamis). Untuk PWA web mungkin perlu redirect, tapi UangkuPro targetnya APK jadi tidak masalah.

**Q: Apa efek samping pakai webpack bukan Turbopack?**

A: Build lebih lambat (~2-3× untuk project besar). Tapi hasil bundle lebih stabil dan kompatibel dengan semua browser/WebView. Untuk development, Anda masih bisa pakai `npm run dev` (Turbopack aktif untuk dev server). Hanya `npm run build` yang pakai webpack.

**Q: Kalau saya mau kembali ke Turbopack di masa depan?**

A: Tunggu Capacitor 9 (atau Next.js 17) yang expected fix compatibility issues. Sementara itu, `npm run build:turbo` tersedia untuk eksperimen.
