import type { NextConfig } from "next";

// [v9.0.1 mobile fix] Konfigurasi khusus untuk Capacitor WebView Android.
// History:
//   v8.1 → v9.0: pakai trailingSlash:true + assetPrefix:"./" → WebView "page couldn't load"
//   v9.0.1: hapus trailingSlash (generate folder /xxx/index.html yang bikin WebView bingung)
//           hapus assetPrefix:"./" (Capacitor WebViewLocalServer sudah intercept absolute path /_next/... dengan benar)
//           add basePath:"" eksplisit untuk jaga-jaga
//   v9.0.1: force --webpack (bukan Turbopack default) karena Turbopack runtime
//           pakai document.currentScript.src yang resolve berbeda di Capacitor WebView.
//           Lihat package.json: "build": "next build --webpack"
const nextConfig: NextConfig = {
  output: "export",
  images: { unoptimized: true },
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
  // trailingSlash DIHAPUS — Capacitor WebView bermasalah dengan URL /xxx/ (folder)
  // trailingSlash: true,
  // assetPrefix DIHAPUS — Capacitor WebViewLocalServer sudah serve /_next/... dengan benar dari assets/public/
  // assetPrefix: "./",
  // basePath eksplisit kosong — root server
  basePath: "",
  // distDir default ".next" — jangan diubah
};

export default nextConfig;
